"""
    Plugin for ResolveURL
    Copyright (C) 2026 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
from six.moves import urllib_parse
from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.resolver import ResolveUrl, ResolverError


class StreamixResolver(ResolveUrl):
    name = 'Streamix'
    domains = [
        'streamix.so', 'stmix.io', 'vidara.so', 'vidara.to', 'vidaraa.cc', 'vidmatrixa.com',
        'kinoger.pw', 'viewdara.com', 'thebesthosterv.com'
    ]
    pattern = (
        r'(?://|\.)((?:st(?:rea)?mix|vid(?:ar|matrix)a*|viewdara|thebesthosterv|kinoger)'
        r'\.(?:so|io|to|cc|com|pw))/(?:e|v)/([0-9a-zA-Z]+)'
    )

    def get_media_url(self, host, media_id, subs=False):
        web_url = self.get_url(host, media_id)
        ref = urllib_parse.urljoin(web_url, '/')
        headers = {'User-Agent': common.RAND_UA,
                   'Referer': ref}
        pdata = {'filecode': media_id,
                 'device': 'web'}
        html = self.net.http_POST(web_url, form_data=pdata, headers=headers, jdata=True).content
        r = json.loads(html)
        if 'streaming_url' in r.keys():
            headers.update({'Referer': ref, 'Origin': ref[:-1]})
            url = r.get('streaming_url') + helpers.append_headers(headers)
            if subs:
                subtitles = {}
                s = r.get('subtitles')
                if s:
                    subtitles = {x.get('language'): x.get('file_path') for x in s}
                return url, subtitles
            return url

        raise ResolverError("Unable to locate stream URL.")

    def get_url(self, host, media_id):
        if host in ['streamix.so', 'stmix.io']:
            host = 'vidara.to'
        return self._default_get_url(host, media_id, template='https://{host}/api/stream')
