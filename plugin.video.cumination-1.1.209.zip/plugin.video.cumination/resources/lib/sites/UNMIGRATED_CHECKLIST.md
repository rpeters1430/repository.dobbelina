# BeautifulSoup Migration Checklist

This checklist groups regex-heavy site modules under `resources/lib/sites/` by modernization phase.

## Phase 5 – Hentai/Anime
- [x] `hentaidude.py` – migrated to BeautifulSoup listings/episodes (this update)
- [x] `hentaihavenco.py` – migrated listings, categories, series, playback (this update)
- [ ] `animeidhentai.py`
- [ ] `hanime.py`
- [ ] `hentai-moon.py` (partial soup usage, needs soup_videos_list alignment)
- [ ] `hentaistream.py`
- [ ] `heroero.py`
- [ ] `erogarga.py`
- [ ] `rule34video.py`
- [ ] `taboofantazy.py`

## Phase 6 – International
- [x] `mrsexe.py`
- [x] `porno1hu.py`
- [x] `porno365.py`
- [x] `nltubes.py`
- [x] `vaginanl.py`
- [x] `perverzija.py`
- [x] `viralvideosporno.py`
- [x] `netfapx.py`
- [x] `porntn.py`
- [x] `yrprno.py`
- [x] `watchmdh.py`
- [ ] `americass.py`
- [ ] `trannyteca.py`
- [ ] `tubxporn.py`
- [ ] `xxdbx.py`
