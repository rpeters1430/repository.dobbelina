"""
Cumination
Copyright (C) 2023 Team Cumination

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import re
import xbmc
import xbmcgui
from resources.lib import utils
from resources.lib.adultsite import AdultSite
from six.moves import urllib_parse

site = AdultSite(
    "eroticmv",
    "[COLOR hotpink]EroticMV[/COLOR]",
    "http://eroticmv.com/",
    "eroticmv.png",
    "eroticmv",
    category="Specialty",
)


@site.register(default_mode=True)
def Main():
    site.add_dir(
        "[COLOR hotpink]Categories[/COLOR]", site.url, "Categories", site.img_cat
    )
    site.add_dir(
        "[COLOR hotpink]Search[/COLOR]", site.url + "search/", "Search", site.img_search
    )
    List(site.url + "category/decades/?archive_query=latest")
    utils.eod()


@site.register()
def List(url):
    html = utils.getHtml(url, site.url)
    if '<h1 class="archive-title h2 extra-bold">' in html:
        html = html.split('<h1 class="archive-title h2 extra-bold">')[-1]
    else:
        html = html.split('">Related videos</h3>')[-1]
    if "nothing matched your search terms" in html:
        utils.notify(msg="Nothing found")
        utils.eod()
        return

    soup = utils.parse_html(html)
    for item in soup.select("article, .video-item, .post"):
        videopage = utils.safe_get_attr(item, "data-hyperlink", default="")
        link = item.select_one("a[href]")
        if not videopage and link:
            videopage = utils.safe_get_attr(link, "href", default="")
        if not videopage:
            continue
        name = utils.cleantext(
            utils.safe_get_attr(link, "title", default=utils.safe_get_text(link))
        )
        img_tag = item.select_one("img")
        img = utils.safe_get_attr(img_tag, "src", ["data-src", "data-original"])
        site.add_download_link(
            name,
            videopage,
            "Playvid",
            img,
            name,
            contextm="eroticmv.Related",
        )

    next_link = soup.select_one("a[rel='next'], a.next, .pagination a.next")
    if next_link:
        next_url = utils.safe_get_attr(next_link, "href", default="")
        if next_url:
            site.add_dir(
                "Next Page",
                next_url,
                "eroticmv.List",
                site.img_next,
                contextm="eroticmv.GotoPage",
            )
    utils.eod()


@site.register()
def GotoPage(list_mode, url, np, lp):
    dialog = xbmcgui.Dialog()
    pg = dialog.numeric(0, "Enter Page number")
    if pg:
        url = url.replace("/page/{}/".format(np), "/page/{}/".format(pg))
        if int(lp) > 0 and int(pg) > int(lp):
            utils.notify(msg="Out of range!")
            return
        contexturl = (
            utils.addon_sys
            + "?mode="
            + str(list_mode)
            + "&url="
            + urllib_parse.quote_plus(url)
        )
        xbmc.executebuiltin("Container.Update(" + contexturl + ")")


@site.register()
def Related(url):
    contexturl = (
        utils.addon_sys
        + "?mode="
        + str("eroticmv.List")
        + "&url="
        + urllib_parse.quote_plus(url)
    )
    xbmc.executebuiltin("Container.Update(" + contexturl + ")")


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, "Search")
    else:
        url = "{0}{1}/".format(url, keyword.replace(" ", "%20"))
        List(url)


@site.register()
def Categories(url):
    cathtml = utils.getHtml(url)
    soup = utils.parse_html(cathtml)
    for link in soup.select('a[href*="/category/genre/"]'):
        caturl = utils.safe_get_attr(link, "href", default="")
        name = utils.cleantext(utils.safe_get_text(link, default=""))
        if not caturl or not name:
            continue
        site.add_dir(name, caturl, "List", "")
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    videohtml = utils.getHtml(url)
    match = re.compile(
        r'og:video:url"\s*content="([^"]+)"', re.IGNORECASE | re.DOTALL
    ).findall(videohtml)
    if match:
        videourl = match[0]
        b64_m = re.search(r"https?://([A-Za-z0-9+/=]+)\.m3u8", videourl)
        if b64_m:
            try:
                decoded = base64.b64decode(b64_m.group(1)).decode("utf-8")
                if decoded.startswith("http"):
                    videourl = decoded
            except Exception:
                pass

        if "embed" in videourl:
            vp.play_from_site_link(videourl)
        else:
            vp.play_from_direct_link(videourl)
