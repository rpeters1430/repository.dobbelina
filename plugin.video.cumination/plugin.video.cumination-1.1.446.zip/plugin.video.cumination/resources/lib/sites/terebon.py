"""
Cumination
Copyright (C) 2025 Team Cumination

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import xbmc
import xbmcgui
import time
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite(
    "terebon",
    "[COLOR hotpink]Terebon[/COLOR]",
    "https://b.terebon.net/",
    "terebon.png",
    "terebon",
    category="JAV & Asian",
)


@site.register(default_mode=True)
def Main():
    site.add_dir(
        "[COLOR hotpink]Sites[/COLOR]",
        site.url
        + "sites/?mode=async&function=get_block&block_id=list_content_sources_sponsors_list&sort_by=title&_="
        + str(int(time.time() * 1000)),
        "Sites",
        site.img_cat,
    )
    site.add_dir(
        "[COLOR hotpink]Tags[/COLOR]", site.url + "tags/", "Tags", site.img_cat
    )
    site.add_dir(
        "[COLOR hotpink]Categories[/COLOR]",
        site.url + "categories/",
        "Cat",
        site.img_cat,
    )
    site.add_dir(
        "[COLOR hotpink]Search[/COLOR]",
        site.url + "search/?q=",
        "Search",
        site.img_search,
    )
    List(site.url)
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, "")
    if "There is no data in this list" in listhtml:
        utils.notify(msg="No data found")
        return

    soup = utils.parse_html(listhtml)

    # Find all video items
    items = soup.select("div.col-lg-4, div.col-md-6")

    cm = []
    cm_lookupinfo = utils.addon_sys + "?mode=terebon.Lookupinfo&url="
    cm.append(
        ("[COLOR deeppink]Lookup info[/COLOR]", "RunPlugin(" + cm_lookupinfo + ")")
    )
    cm_related = utils.addon_sys + "?mode=terebon.Related&url="
    cm.append(
        ("[COLOR deeppink]Related videos[/COLOR]", "RunPlugin(" + cm_related + ")")
    )

    for item in items:
        # Skip captcha items
        if "Captcha" in str(item):
            continue

        link = item.select_one("a")
        if not link:
            continue

        videourl = utils.safe_get_attr(link, "href")
        if not videourl:
            continue

        img_tag = item.select_one("img")
        name = utils.safe_get_attr(img_tag, "alt")
        img = utils.safe_get_attr(img_tag, "src", ["data-original", "data-src"])

        duration_tag = item.select_one("div.video-preview__duration")
        duration = utils.safe_get_text(duration_tag, "")

        quality_tag = item.select_one("div.video-preview__quality")
        quality = utils.safe_get_text(quality_tag, "")

        # Build name with quality and duration
        if quality:
            name = "[COLOR yellow]" + quality + "[/COLOR] " + name
        if duration:
            name = name + " [COLOR deeppink]" + duration + "[/COLOR]"

        site.add_download_link(name, videourl, "Playvid", img, name, contextm=cm)

    # Pagination
    page_current = soup.select_one("span.page-current span")
    next_link = soup.select_one("a.next")

    if page_current and next_link:
        current_page = utils.safe_get_text(page_current)
        if current_page:
            try:
                npage = int(current_page) + 1
                block_id = utils.safe_get_attr(next_link, "data-block-id")
                params = utils.safe_get_attr(next_link, "data-parameters")

                if block_id and params:
                    params = params.replace(";", "&").replace(":", "=")
                    ts = int(time.time() * 1000)
                    nurl = url.split("?")[
                        0
                    ] + "?mode=async&function=get_block&block_id={0}&{1}&_={2}".format(
                        block_id, params, ts
                    )

                    lpnr, lastp = 0, ""
                    last_link = soup.select_one('a[href*="Last"]')
                    if last_link:
                        last_text = utils.safe_get_text(last_link)
                        match = re.search(r"(\d+)", last_text)
                        if match:
                            lpnr = match.group(1)
                            lastp = "/{}".format(lpnr)

                    nurl = nurl.replace("+from_albums", "")
                    nurl = re.sub(
                        r"&from([^=]*)=\d+", r"&from\1={}".format(npage), nurl
                    )

                    cm_page = (
                        utils.addon_sys
                        + "?mode=terebon.GotoPage"
                        + "&url="
                        + urllib_parse.quote_plus(nurl)
                        + "&np="
                        + str(npage)
                        + "&lp="
                        + str(lpnr)
                    )
                    cm = [
                        (
                            "[COLOR violet]Goto Page #[/COLOR]",
                            "RunPlugin(" + cm_page + ")",
                        )
                    ]

                    site.add_dir(
                        "[COLOR hotpink]Next Page...[/COLOR] ("
                        + str(npage)
                        + lastp
                        + ")",
                        nurl,
                        "List",
                        site.img_next,
                        contextm=cm,
                    )
            except (ValueError, AttributeError):
                pass

    utils.eod()


@site.register()
def GotoPage(url, np, lp=0):
    dialog = xbmcgui.Dialog()
    pg = dialog.numeric(0, "Enter Page number")
    if pg:
        if int(lp) > 0 and int(pg) > int(lp):
            utils.notify(msg="Out of range!")
            return
        url = re.sub(r"&from([^=]*)=\d+", r"&from\1={}".format(pg), url, re.IGNORECASE)
        contexturl = (
            utils.addon_sys
            + "?mode="
            + "terebon.List&url="
            + urllib_parse.quote_plus(url)
        )
        xbmc.executebuiltin("Container.Update(" + contexturl + ")")


@site.register()
def Related(url):
    contexturl = (
        utils.addon_sys
        + "?mode="
        + str("terebon.List")
        + "&url="
        + urllib_parse.quote_plus(url)
    )
    xbmc.executebuiltin("Container.Update(" + contexturl + ")")


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    vpage = utils.getHtml(url, site.url)
    if "kt_player('kt_player'" in vpage:
        vp.progress.update(60, "[CR]{0}[CR]".format("kt_player detected"))
        vp.play_from_kt_player(vpage, url)


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, "Search")
    else:
        List(url + keyword.replace(" ", "+"))


@site.register()
def Cat(url):
    listhtml = utils.getHtml(url)
    soup = utils.parse_html(listhtml)

    # Find all category items
    items = soup.select("div.col-xxl-2, div.col-xl-3, div.col-lg-4")

    for item in items:
        link = item.select_one("a")
        if not link:
            continue

        page = utils.safe_get_attr(link, "href")
        name = utils.safe_get_attr(link, "title")

        if not page or not name:
            continue

        img_tag = item.select_one("img")
        img = utils.safe_get_attr(img_tag, "data-original", ["src", "data-src"])

        name = utils.cleantext(name)
        site.add_dir(name, page, "List", img)

    utils.eod()


@site.register()
def Tags(url):
    listhtml = utils.getHtml(url)
    soup = utils.parse_html(listhtml)

    # Find all tag links
    tag_links = soup.select("a.video-specs__tag")

    for link in tag_links:
        page = utils.safe_get_attr(link, "href")
        tag = utils.safe_get_text(link)

        if not page or not tag:
            continue

        tag = utils.cleantext(tag.strip())
        site.add_dir(tag, page, "List", "")

    utils.eod()


@site.register()
def Sites(url):
    listhtml = utils.getHtml(url)
    soup = utils.parse_html(listhtml)

    # Find all site items
    items = soup.select("a.item")

    for item in items:
        page = utils.safe_get_attr(item, "href")
        name = utils.safe_get_attr(item, "title")

        if not page or not name:
            continue

        # Get video count
        videos_tag = item.select_one("span.videos, div.videos")
        videos = utils.safe_get_text(videos_tag, "")

        if videos:
            name = utils.cleantext(name.strip()) + " (" + videos.strip() + ")"
        else:
            name = utils.cleantext(name.strip())

        site.add_dir(name, page, "List", "")

    # Pagination
    page_current = soup.select_one("span.page-current span")
    next_link = soup.select_one("a.next")

    if page_current and next_link:
        current_page = utils.safe_get_text(page_current)
        if current_page:
            try:
                npage = int(current_page) + 1
                block_id = utils.safe_get_attr(next_link, "data-block-id")
                params = utils.safe_get_attr(next_link, "data-parameters")

                if block_id and params:
                    params = params.replace(";", "&").replace(":", "=")
                    ts = int(time.time() * 1000)
                    nurl = url.split("?")[
                        0
                    ] + "?mode=async&function=get_block&block_id={0}&{1}&_={2}".format(
                        block_id, params, ts
                    )
                    nurl = nurl.replace("+from_albums", "")
                    nurl = re.sub(
                        r"&from([^=]*)=\d+", r"&from\1={}".format(npage), nurl
                    )
                    site.add_dir(
                        "[COLOR hotpink]Next Page...[/COLOR] (" + str(npage) + ")",
                        nurl,
                        "Sites",
                        site.img_next,
                    )
            except (ValueError, AttributeError):
                pass

    utils.eod()


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Category", '/(categories/[^"]+)">([^<]+)<', ""),
        ("Tags", '/(tags/[^"]+)">([^<]+)<', ""),
    ]
    lookupinfo = utils.LookupInfo(site.url, url, "terebon.List", lookup_list)
    lookupinfo.getinfo()
