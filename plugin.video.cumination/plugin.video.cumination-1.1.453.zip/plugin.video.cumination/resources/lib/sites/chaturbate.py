"""
Cumination
Copyright (C) 2015 Whitecream

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import os
import sqlite3
from six.moves import urllib_parse
import six
import json
import random
import time
import xbmc
from resources.lib import utils
from resources.lib.adultsite import AdultSite

bu = "https://chaturbate.com/"
rapi = "https://chaturbate.com/api/ts/roomlist/room-list/"
tapi = "https://chaturbate.com/api/ts/hashtags/tag-table-data/"
site = AdultSite(
    "chaturbate",
    "[COLOR hotpink]Chaturbate[/COLOR]",
    bu,
    "chaturbate.png",
    "chaturbate",
    webcam=True,
    category="Cams & Live",
)

addon = utils.addon
_cb_proxies = {}
HTTP_HEADERS_IPAD = {
    "User-Agent": "Mozilla/5.0 (iPad; CPU OS 8_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B410 Safari/600.1.4"
}


def _cb_media_name(media_url):
    return media_url.rsplit("/", 1)[-1].split("?")[0]


def _cb_remember_media_url(proxy_state, media_url, type_key=None):
    if not media_url or ".m4s" not in media_url:
        return
    media_name = _cb_media_name(media_url)
    proxy_state["seg_cdn_urls"][media_name] = media_url
    if type_key and re.search(r"^(seg|part)_", media_name):
        proxy_state["latest_seg"][type_key] = media_url


def _cb_remember_playlist_media_urls(proxy_state, playlist, type_key=None):
    for line in playlist.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and ".m4s" in line:
            _cb_remember_media_url(proxy_state, line, type_key)
    for match in re.finditer(r'URI="(https?://[^"]+\.m4s[^"]*)"', playlist, re.I):
        _cb_remember_media_url(proxy_state, match.group(1), type_key)


@site.register(default_mode=True)
def Main():
    site.add_dir(
        "[COLOR red]Refresh Chaturbate images[/COLOR]",
        "",
        "clean_database",
        "",
        Folder=False,
    )
    site.add_dir(
        "[COLOR hotpink]Look for Online Models[/COLOR]",
        site.url + "ax/search/?keywords=",
        "Search",
        site.img_search,
    )
    site.add_dir(
        "[COLOR hotpink]Featured[/COLOR]", rapi + "?limit=100&offset=0", "List", "", ""
    )
    site.add_dir(
        "[COLOR yellow]Current Hour's Top Cams[/COLOR]",
        bu + "api/ts/contest/leaderboard/",
        "topCams",
        "",
        "",
    )
    site.add_dir("[COLOR yellow]Online Favorites[/COLOR]", bu, "onlineFav", "", "")
    site.add_dir(
        "[COLOR yellow]Followed Cams[/COLOR]",
        rapi
        + "?enable_recommendations=true&follow=true&limit=100&offline=false&offset=0",
        "List",
        "",
        "",
    )

    genders = []
    if addon.getSetting("chatfemale") == "true":
        genders.append(("f", "Female", "violet"))
    if addon.getSetting("chatcouple") == "true":
        genders.append(("c", "Couple", "violet"))
    if addon.getSetting("chatmale") == "true":
        genders.append(("m", "Male", "violet"))
    if addon.getSetting("chattrans") == "true":
        genders.append(("t", "TransSexual", "violet"))

    for code, label, color in genders:
        site.add_dir(
            "[COLOR {}]{}[/COLOR]".format(color, label),
            rapi + "?genders={}&limit=100&offset=0".format(code),
            "List",
            "",
            "",
        )
        site.add_dir(
            "[COLOR hotpink]Tags - {}[/COLOR]".format(label),
            tapi + "?sort=ht&page=1&g={}&limit=100".format(code),
            "Tags",
            "",
            "",
        )
        site.add_dir(
            "[COLOR hotpink]New Cams - {}[/COLOR]".format(label),
            rapi + "?genders={}&new_cams=true&limit=100&offset=0".format(code),
            "List",
            "",
            "",
        )

        # Age-based and region-based submenus
        age_ranges = [
            ("Teen Cams (18+)", 18, 19),
            ("20 to 30 Cams", 20, 30),
            ("30 to 50 Cams", 30, 50),
            ("Mature Cams (50+)", 50, 200),
        ]
        for age_label, start, end in age_ranges:
            site.add_dir(
                "[COLOR hotpink] {} - {}[/COLOR]".format(age_label, label),
                rapi
                + "?genders={}&limit=100&from_age={}&to_age={}&offset=0".format(
                    code, start, end
                ),
                "List",
                "",
                "",
            )

        regions = [
            ("North American", "NA"),
            ("South American", "SA"),
            ("Euro Russian", "ER"),
            ("Asian", "AS"),
            ("Other Region", "O"),
        ]
        for reg_label, reg_code in regions:
            site.add_dir(
                "[COLOR hotpink]{} Cams - {}[/COLOR]".format(reg_label, label),
                rapi
                + "?genders={}&limit=100&regions={}&offset=0".format(code, reg_code),
                "List",
                "",
                "",
            )

    utils.eod()


# TODO: Consider moving m3u8 proxy logic to a centralized utils helper
# to handle single-use tokens and absolute URL redirection across sites.


def Online(stamp):
    days, weeks, years = None, None, None
    mins, secs = divmod(int(time.time()) - stamp, 60)
    hours, mins = divmod(mins, 60)
    if hours > 23:
        days, hours = divmod(hours, 24)
    if days and days > 6:
        weeks, days = divmod(days, 7)
    if weeks and weeks > 51:
        years, weeks = divmod(weeks, 52)
    if years:
        ret = "{:2d} years {:2d} weeks".format(years, weeks)
    elif weeks:
        ret = "{:2d} weeks {:2d} days".format(weeks, days)
    elif days:
        ret = "{:2d} days {:2d} hours".format(days, hours)
    else:
        ret = "{:2d} hours {:2d} minutes".format(hours, mins)
    ret = re.sub(r"(\s0\s\S+)", "", ret)
    ret = re.sub(r"(\s1\s\S+)s", r"\1", ret)
    return ret


@site.register()
def List(url, page=1):
    if "follow=true" in url and "offline=false" in url:
        site.add_dir(
            "[COLOR yellow]Offline Rooms[/COLOR]",
            rapi
            + "?enable_recommendations=true&follow=true&limit=100&offline=true&offset=0",
            "List",
            "",
            "",
        )
    if "follow=true" in url:
        login()
    if addon.getSetting("chaturbate") == "true":
        clean_database(False)
    if not isinstance(page, int):
        page = 1

    conn = sqlite3.connect(utils.favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("SELECT url FROM favorites WHERE mode='chaturbate.Playvid'")
    favorite = [row[0] for row in c.fetchall()]
    c.close()

    headers = {"X-Requested-With": "XMLHttpRequest"}
    listhtml, _ = utils.get_html_with_cloudflare_retry(url, headers=headers)
    listhtml = json.loads(listhtml)
    models = listhtml.get("rooms")
    for model in models:
        if model.get('is_following'):
            name = '[COLOR hotpink]♥[/COLOR]'
            fav = 'del'
        else:
            name = ''
            fav = 'add'
        if any(model['username'] in username for username in favorite):
            name += '[COLOR yellow]★[/COLOR]'
            fav = 'del'
        else:
            name += ''
            fav = 'add'
        name += model.get('username')
        videopage = "{0}{1}/".format(bu, model.get('username'))
        age = model.get("display_age")
        age = "Unknown" if age is None else age
        location = model.get("location")
        if location:
            location = location.encode("utf8") if six.PY2 else location
            location = utils.cleantext(location)
        else:
            location = ""

        subject = model.get("subject")
        subject = subject.encode("utf8") if six.PY2 else subject
        subject = re.sub(r"<a.+", "", subject).strip()
        if "offline=true" not in url:
            subject = (
                utils.cleantext(subject)
                + "[CR][CR][COLOR deeppink]Location: [/COLOR]"
                + location
                + "[CR]"
                + "[COLOR deeppink]Duration: [/COLOR]{0}[CR]".format(
                    Online(model.get("start_timestamp"))
                )
                + "[COLOR deeppink]Watching: [/COLOR]{0}[CR]".format(
                    model.get("num_users")
                )
                + "[COLOR deeppink]Followers: [/COLOR]{0}".format(
                    model.get("num_followers")
                )
            )
            name = "{0} [COLOR deeppink][{1}][/COLOR] {2}".format(
                name, age, model.get("current_show")
            )
        else:
            subject = utils.cleantext(subject)
            if model.get("start_timestamp"):
                ago = re.sub(
                    r"^\s*(\d+\s+\S+).*$", r"\1", Online(model.get("start_timestamp"))
                )
                name = "{0} [COLOR deeppink][{1}][/COLOR] [COLOR blue]{2} ago[/COLOR]".format(
                    name, age, ago
                )
            else:
                name = "{0} [COLOR deeppink][{1}][/COLOR]".format(name, age)
        tags = model.get("tags")
        if tags:
            tags = "[COLOR deeppink]#[/COLOR]" + ", [COLOR deeppink]#[/COLOR]".join(
                tags
            )
            tags = tags.encode("utf-8") if six.PY2 else tags
            subject += "[CR][CR]" + tags
        img = model.get("img")

        id = model.get("username")
        follow = model.get("is_following")
        contextfollow = (
            utils.addon_sys
            + "?mode=chaturbate.Follow&id="
            + urllib_parse.quote_plus(id)
        )
        contextunfollow = (
            utils.addon_sys
            + "?mode=chaturbate.Unfollow&id="
            + urllib_parse.quote_plus(id)
        )
        contextmenu = (
            [
                (
                    "[COLOR violet]Follow [/COLOR]{}".format(name),
                    "RunPlugin(" + contextfollow + ")",
                )
            ]
            if not follow
            else [
                (
                    "[COLOR violet]Unfollow [/COLOR]{}".format(name),
                    "RunPlugin(" + contextunfollow + ")",
                )
            ]
        )
        contextrecord = (
            utils.addon_sys
            + "?mode=chaturbate.Record&id="
            + urllib_parse.quote_plus(id)
        )
        contextmenu.append(
            (
                "[COLOR violet]Find recordings featuring [/COLOR]{}[COLOR violet] on Cloudbate[/COLOR]".format(
                    id
                ),
                "RunPlugin(" + contextrecord + ")",
            )
        )

        site.add_download_link(
            name,
            videopage,
            "Playvid",
            img,
            subject,
            contextm=contextmenu,
            fav=fav,
            noDownload=True,
        )

    total_items = listhtml.get("total_count")
    nextp = (page * 100) < total_items
    if nextp:
        next = (page * 100) + 1
        lastpg = -1 * (-total_items // 100)
        page = page + 1
        nurl = re.sub(r"offset=\d+", "offset={0}".format(next), url)
        site.add_dir(
            "Next Page.. (Currently in Page {0} of {1})".format(page - 1, lastpg),
            nurl,
            "List",
            site.img_next,
            page,
        )

    utils.eod()


@site.register()
def SList(url):
    hdr = utils.base_hdrs.copy()
    hdr.update({"X-Requested-With": "XMLHttpRequest"})
    listhtml, _ = utils.get_html_with_cloudflare_retry(url, site.url, headers=hdr)
    jlist = json.loads(listhtml)
    for model in jlist.get("online", []):
        img = "https://thumb.live.mmcdn.com/riw/{}.jpg".format(model)
        contextfollow = (
            utils.addon_sys
            + "?mode=chaturbate.Follow&id="
            + urllib_parse.quote_plus(model)
        )
        contextunfollow = (
            utils.addon_sys
            + "?mode=chaturbate.Unfollow&id="
            + urllib_parse.quote_plus(model)
        )
        contextmenu = [
            (
                "[COLOR violet]Follow [/COLOR]{}".format(model),
                "RunPlugin(" + contextfollow + ")",
            ),
            (
                "[COLOR violet]Unfollow [/COLOR]{}".format(model),
                "RunPlugin(" + contextunfollow + ")",
            ),
        ]
        videopage = "{0}{1}/".format(bu, model)
        site.add_download_link(
            model, videopage, "Playvid", img, contextm=contextmenu, noDownload=True
        )
    utils.eod()


@site.register(clean_mode=True)
def clean_database(showdialog=True):
    conn = sqlite3.connect(utils.TRANSLATEPATH("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute(
                "SELECT id, cachedurl FROM texture WHERE url LIKE ?;",
                ("%" + ".live.mmcdn.com" + "%",),
            )
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture = ?;", (row[0],))
                try:
                    os.remove(utils.TRANSLATEPATH("special://thumbnails/" + row[1]))
                except Exception as e:
                    utils.kodilog(
                        "@@@@Cumination: Silent failure in chaturbate: " + str(e)
                    )
            conn.execute(
                "DELETE FROM texture WHERE url LIKE ?;",
                ("%" + ".live.mmcdn.com" + "%",),
            )
            if showdialog:
                utils.notify("Finished", "Chaturbate images cleared")
    except Exception as e:
        utils.kodilog("@@@@Cumination: Silent failure in chaturbate: " + str(e))


@site.register()
def Playvid(url, name):
    playmode = int(addon.getSetting("chatplay"))
    try:
        listhtml, used_fs = utils.get_html_with_cloudflare_retry(
            url,
            referer=site.url,
            headers=HTTP_HEADERS_IPAD,
            retry_on_empty=True,
        )
    except Exception as error:
        utils.kodilog("Chaturbate: Failed to load room page: {}".format(str(error)))
        utils.notify("Chaturbate", "Unable to load webcam page")
        return

    def _parse_room_data(page_html):
        if not page_html:
            return None
        soup = utils.parse_html(page_html)
        if not soup:
            return None
        scripts = soup.find_all("script")
        for script in scripts:
            script_text = script.string or script.get_text() or ""
            if "initialRoomDossier" not in script_text:
                continue
            match = re.search(
                r'initialRoomDossier\s*=\s*"((?:\\.|[^"])*)"', script_text
            )
            if not match:
                continue
            data_blob = six.b(match.group(1)).decode("unicode-escape")
            data_blob = data_blob if six.PY3 else data_blob.encode("utf8")
            try:
                return json.loads(data_blob)
            except ValueError:
                continue
        return None

    data = _parse_room_data(listhtml)

    if data:
        m3u8stream = data.get("hls_source")
    else:
        m3u8stream = False
        slug = url.rstrip("/").rsplit("/", 1)[-1]
        headers = HTTP_HEADERS_IPAD.copy()
        headers.update(
            {
                "X-Requested-With": "XMLHttpRequest",
                "Referer": url,
            }
        )
        try:
            edge = json.loads(
                utils._getHtml(
                    bu + "get_edge_hls_url_ajax/",
                    headers=headers,
                    data={"room_slug": slug, "bandwidth": "high"},
                )
            )
            if edge.get("room_status") == "public":
                m3u8stream = edge.get("url")
        except Exception as error:
            utils.kodilog("Chaturbate: HLS fallback failed: {}".format(str(error)))

    if playmode == 0:
        if m3u8stream:
            import socket, threading, gzip, zlib  # noqa: E401
            # py2 (kodi 18.x leia) doesnt have http.server / socketserver,
            # those are py3 names. fall back to py2 names so the proxy
            # imports cleanly on older builds. issue #1845
            try:
                from http.server import BaseHTTPRequestHandler
                from socketserver import TCPServer, ThreadingMixIn
            except ImportError:
                from BaseHTTPServer import BaseHTTPRequestHandler
                from SocketServer import TCPServer, ThreadingMixIn
            from six.moves import (
                urllib_request as _urllib_req,
                urllib_parse as _urllib_parse,
            )

            _Req = _urllib_req.Request
            _uopen = _urllib_req.urlopen
            _urljoin = _urllib_parse.urljoin

            def _read_body(resp):
                # mmcdn edges return gzipped bodies even without Accept-Encoding,
                # sometimes with Content-Encoding header and sometimes without.
                # decompress on either signal so downstream decode/passthrough is clean.
                raw = resp.read()
                ce = (resp.headers.get("Content-Encoding") or "").lower()
                if ce == "gzip" or raw[:2] == b"\x1f\x8b":
                    try:
                        raw = gzip.decompress(raw)
                    except Exception:
                        pass
                elif ce == "deflate":
                    try:
                        raw = zlib.decompress(raw)
                    except Exception:
                        try:
                            raw = zlib.decompress(raw, -zlib.MAX_WBITS)
                        except Exception:
                            pass
                return raw

            try:
                global _cb_proxies

                # Debug log for proxy events (toggle via Settings > enh_debug)
                _dbg_path = os.path.join(
                    utils.TRANSLATEPATH("special://temp"), "cb_proxy.log"
                )
                _dbg_on = addon.getSetting("enh_debug") == "true"

                def _dbg(msg):
                    if not _dbg_on:
                        return
                    try:
                        with open(_dbg_path, "a") as f:
                            f.write("{} {}\n".format(time.strftime("%H:%M:%S"), msg))
                    except Exception:
                        pass

                # Each stream gets its own ephemeral proxy. Do not shut down
                # existing proxies here; their monitors clean up after inactivity.

                headers = HTTP_HEADERS_IPAD.copy()
                headers["Referer"] = url
                req = _Req(m3u8stream, headers=headers)
                master_raw = _read_body(_uopen(req, timeout=10)).decode(
                    "utf-8", "replace"
                )
                base = m3u8stream.rsplit("/", 1)[0] + "/"

                master_fixed = re.sub(
                    r"^(?!https?://)(?!#)(.+)$",
                    lambda m: _urljoin(base, m.group(1)),
                    master_raw,
                    flags=re.MULTILINE,
                )
                master_fixed = re.sub(
                    r'URI="(?!https?://)(.*?)"',
                    lambda m: 'URI="' + _urljoin(base, m.group(1)) + '"',
                    master_fixed,
                    flags=re.IGNORECASE,
                )

                # Bind proxy port first so we can rewrite chunklist URLs
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.bind(("127.0.0.1", 0))
                port = sock.getsockname()[1]
                sock.close()

                # State for session reconnection
                _proxy_state = {
                    "stream_url": m3u8stream,
                    "headers": headers,
                    "url_map": {},
                    "last_refresh": 0,
                    "lock": threading.Lock(),
                    "chunklist_cache": {},
                    "seg_cdn_urls": {},
                    "latest_seg": {},
                    "request_count": 0,
                    "last_request": time.time(),
                }

                # Populate initial chunklist URL map (type_key -> cdn_url)
                for _line in master_fixed.splitlines():
                    _line = _line.strip()
                    if _line and not _line.startswith("#") and "chunklist_" in _line:
                        _km = re.search(r"(chunklist_\d+_\w+)", _line)
                        if _km:
                            _proxy_state["url_map"][_km.group(1)] = _line
                for _mi in re.finditer(
                    r'URI="(https?://[^"]*chunklist_[^"]*)"',
                    master_fixed,
                    re.IGNORECASE,
                ):
                    _km = re.search(r"(chunklist_\d+_\w+)", _mi.group(1))
                    if _km:
                        _proxy_state["url_map"][_km.group(1)] = _mi.group(1)

                _dbg(
                    "PROXY START port={} keys={}".format(
                        port, list(_proxy_state["url_map"].keys())
                    )
                )

                # Rewrite only .m3u8 chunklist URLs to go through our proxy
                master_fixed = re.sub(
                    r"^(https?://[^\s]+\.m3u8[^\s]*)$",
                    lambda m: "http://127.0.0.1:{}/chunklist?url={}".format(
                        port, urllib_parse.quote(m.group(1), safe="")
                    ),
                    master_fixed,
                    flags=re.MULTILINE,
                )
                master_fixed = re.sub(
                    r'URI="(https?://[^"]+\.m3u8[^"]*)"',
                    lambda m: 'URI="http://127.0.0.1:{}/chunklist?url={}"'.format(
                        port, urllib_parse.quote(m.group(1), safe="")
                    ),
                    master_fixed,
                    flags=re.IGNORECASE,
                )
                master_bytes = master_fixed.encode("utf-8")

                def _refresh_session():
                    """Re-fetch master playlist to get fresh session tokens."""
                    now = time.time()
                    with _proxy_state["lock"]:
                        if now - _proxy_state["last_refresh"] < 2:
                            return False
                        _proxy_state["last_refresh"] = now
                    try:
                        rq = _Req(
                            _proxy_state["stream_url"], headers=_proxy_state["headers"]
                        )
                        raw = _read_body(_uopen(rq, timeout=10)).decode(
                            "utf-8", "replace"
                        )
                        burl = _proxy_state["stream_url"].rsplit("/", 1)[0] + "/"
                        fixed = re.sub(
                            r"^(?!https?://)(?!#)(.+)$",
                            lambda m: _urljoin(burl, m.group(1)),
                            raw,
                            flags=re.MULTILINE,
                        )
                        fixed = re.sub(
                            r'URI="(?!https?://)(.*?)"',
                            lambda m: 'URI="' + _urljoin(burl, m.group(1)) + '"',
                            fixed,
                            flags=re.IGNORECASE,
                        )
                        new_map = {}
                        for line in fixed.splitlines():
                            line = line.strip()
                            if (
                                line
                                and not line.startswith("#")
                                and "chunklist_" in line
                            ):
                                km = re.search(r"(chunklist_\d+_\w+)", line)
                                if km:
                                    new_map[km.group(1)] = line
                        for mi in re.finditer(
                            r'URI="(https?://[^"]*chunklist_[^"]*)"',
                            fixed,
                            re.IGNORECASE,
                        ):
                            km = re.search(r"(chunklist_\d+_\w+)", mi.group(1))
                            if km:
                                new_map[km.group(1)] = mi.group(1)
                        with _proxy_state["lock"]:
                            _proxy_state["url_map"].update(new_map)
                            _proxy_state["chunklist_cache"].clear()
                            _proxy_state["seg_cdn_urls"].clear()
                            _proxy_state["latest_seg"].clear()
                        _dbg(
                            "REFRESH OK new_keys={} caches_cleared".format(
                                list(new_map.keys())
                            )
                        )
                        return True
                    except Exception as e:
                        _dbg("REFRESH FAIL {}".format(e))
                        return False

                def _force_stop(reason):
                    _proxy_state["stopping"] = True
                    _dbg("FORCE STOP: {}".format(reason))
                    # skip the global Stop if player moved to another proxy
                    # (sibling playvid). still tear our own proxy down below.
                    try:
                        cur = xbmc.Player().getPlayingFile() or ""
                    except Exception:
                        cur = ""
                    if cur and ":{}/".format(port) not in cur:
                        _dbg(
                            "PlayerControl(Stop) skipped, player on diff proxy {}".format(
                                cur
                            )
                        )
                    else:
                        try:
                            xbmc.executebuiltin("PlayerControl(Stop)")
                            _dbg("PlayerControl(Stop) sent")
                        except Exception as ex2:
                            _dbg("PlayerControl(Stop) FAILED: {}".format(ex2))
                    time.sleep(3)
                    try:
                        srv.shutdown()
                    except Exception as sex:
                        _dbg("shutdown err: {}".format(sex))
                    try:
                        srv.server_close()
                        _dbg("Proxy server shutdown")
                    except Exception as sex:
                        _dbg("close err: {}".format(sex))

                def _bg_reconnect():
                    needs_force_stop = True
                    try:
                        for _attempt in range(15):
                            if _proxy_state.get("stopping"):
                                _dbg("RECONNECT aborted - proxy stopping")
                                needs_force_stop = False
                                return
                            _dbg("RECONNECT attempt={}/15".format(_attempt + 1))
                            if _refresh_session():
                                _dbg("RECONNECT OK attempt={}".format(_attempt + 1))
                                with _proxy_state["lock"]:
                                    _proxy_state["reconnecting"] = False
                                _dbg("WATCHDOG waiting 8s to check ISA")
                                time.sleep(8)
                                if _proxy_state.get("stopping"):
                                    needs_force_stop = False
                                    return
                                gap = time.time() - _proxy_state.get("last_request", 0)
                                _dbg("WATCHDOG gap={:.1f}s".format(gap))
                                if gap > 6:
                                    _dbg("WATCHDOG over threshold, rechecking in 3s")
                                    time.sleep(3)
                                    if _proxy_state.get("stopping"):
                                        needs_force_stop = False
                                        return
                                    gap2 = time.time() - _proxy_state.get(
                                        "last_request", 0
                                    )
                                    _dbg("WATCHDOG recheck gap={:.1f}s".format(gap2))
                                    if gap2 > 6:
                                        needs_force_stop = False
                                        _force_stop(
                                            "ISA silent {:.0f}s after reconnect".format(
                                                gap2
                                            )
                                        )
                                        return
                                    _dbg("WATCHDOG OK on recheck -- ISA recovered")
                                else:
                                    _dbg("WATCHDOG OK -- ISA still active")
                                needs_force_stop = False
                                return
                            time.sleep(2)
                        _dbg("GIVING UP after 15 attempts")
                    except Exception as ex:
                        try:
                            _dbg("RECONNECT THREAD CRASHED: {}".format(ex))
                        except Exception:
                            pass
                    finally:
                        if needs_force_stop and not _proxy_state.get("stopping"):
                            try:
                                _force_stop("reconnect exhausted")
                            except Exception:
                                pass

                def _trigger_reconnect(reason):
                    with _proxy_state["lock"]:
                        if _proxy_state.get("reconnecting") or _proxy_state.get(
                            "stopping"
                        ):
                            return
                        _proxy_state["reconnecting"] = True
                    _dbg("RECONNECT TRIGGERED: {}".format(reason))
                    t2 = threading.Thread(target=_bg_reconnect)
                    t2.daemon = True
                    t2.start()

                def _is_safe_url(target_url):
                    def _canonical_host_port(parsed_url):
                        if parsed_url.scheme not in ("http", "https"):
                            return None
                        if parsed_url.username or parsed_url.password:
                            return None
                        host = parsed_url.hostname
                        if not host:
                            return None
                        port = parsed_url.port
                        if port is None:
                            port = 443 if parsed_url.scheme == "https" else 80
                        return (host.lower(), port)

                    parsed = urllib_parse.urlparse(target_url)
                    req_host_port = _canonical_host_port(parsed)
                    if not req_host_port:
                        return False

                    allowed_hosts = set()
                    with _proxy_state["lock"]:
                        try:
                            base_parsed = urllib_parse.urlparse(
                                _proxy_state["stream_url"]
                            )
                            base_host_port = _canonical_host_port(base_parsed)
                            if base_host_port:
                                allowed_hosts.add(base_host_port)
                        except Exception:
                            pass

                        for collection in ["seg_cdn_urls", "latest_seg", "url_map"]:
                            for _u in _proxy_state.get(collection, {}).values():
                                try:
                                    _p = urllib_parse.urlparse(_u)
                                    _hp = _canonical_host_port(_p)
                                    if _hp:
                                        allowed_hosts.add(_hp)
                                except Exception:
                                    pass
                    return req_host_port in allowed_hosts

                # Localhost proxy: serves master + proxies chunklists with auto-reconnect
                class _H(BaseHTTPRequestHandler):
                    def do_GET(self):
                        if self.path.startswith("/chunklist"):
                            parsed = urllib_parse.urlparse(self.path)
                            params = urllib_parse.parse_qs(parsed.query)
                            req_url = params.get("url", [None])[0]
                            if not req_url:
                                self.send_error(400)
                                return
                            km = re.search(r"(chunklist_\d+_\w+)", req_url)
                            type_key = km.group(1) if km else None
                            cdn_url = (
                                _proxy_state["url_map"].get(type_key)
                                if type_key
                                else None
                            )
                            if not cdn_url:
                                self.send_error(400)
                                return
                            _proxy_state["last_request"] = time.time()
                            _proxy_state["request_count"] = (
                                _proxy_state.get("request_count", 0) + 1
                            )

                            def _fetch_and_absolutize(u):
                                creq = _Req(u, headers=_proxy_state["headers"])
                                resp = _uopen(creq, timeout=10)
                                raw = _read_body(resp).decode("utf-8", "replace")
                                cbase = u.rsplit("/", 1)[0] + "/"
                                raw = re.sub(
                                    r"^(?!https?://)(?!#)(\S+)$",
                                    lambda m: _urljoin(cbase, m.group(1)),
                                    raw,
                                    flags=re.MULTILINE,
                                )
                                raw = re.sub(
                                    r'URI="(?!https?://)([^"]+)"',
                                    lambda m: 'URI="'
                                    + _urljoin(cbase, m.group(1))
                                    + '"',
                                    raw,
                                    flags=re.IGNORECASE,
                                )
                                _cb_remember_playlist_media_urls(
                                    _proxy_state, raw, type_key
                                )
                                raw = re.sub(
                                    r"^(https?://[^\s]+\.m4s[^\s]*)$",
                                    lambda m: "http://127.0.0.1:{}/segment?url={}".format(
                                        port, urllib_parse.quote(m.group(1), safe="")
                                    ),
                                    raw,
                                    flags=re.MULTILINE,
                                )
                                raw = re.sub(
                                    r'URI="(https?://[^"]+\.m4s[^"]*)"',
                                    lambda m: 'URI="http://127.0.0.1:{}/segment?url={}"'.format(
                                        port, urllib_parse.quote(m.group(1), safe="")
                                    ),
                                    raw,
                                    flags=re.IGNORECASE,
                                )
                                return raw.encode("utf-8")

                            try:
                                data = _fetch_and_absolutize(cdn_url)
                                if type_key:
                                    _proxy_state["chunklist_cache"][type_key] = data
                                self.send_response(200)
                                self.send_header(
                                    "Content-Type", "application/vnd.apple.mpegurl"
                                )
                                self.send_header("Content-Length", str(len(data)))
                                self.end_headers()
                                self.wfile.write(data)
                            except Exception as e:
                                if _proxy_state.get("stopping"):
                                    try:
                                        xbmc.executebuiltin("PlayerControl(Stop)")
                                    except Exception:
                                        pass
                                    endlist = b"#EXTM3U\n#EXT-X-ENDLIST\n"
                                    self.send_response(200)
                                    self.send_header(
                                        "Content-Type", "application/vnd.apple.mpegurl"
                                    )
                                    self.send_header(
                                        "Content-Length", str(len(endlist))
                                    )
                                    self.end_headers()
                                    self.wfile.write(endlist)
                                    return
                                _dbg(
                                    "CHUNKLIST FAIL type={} err={}".format(type_key, e)
                                )
                                _trigger_reconnect(
                                    "chunklist fail type={}: {}".format(type_key, e)
                                )
                                if type_key and not _proxy_state.get("stopping"):
                                    new_url = _proxy_state["url_map"].get(type_key)
                                    if new_url and new_url != cdn_url:
                                        try:
                                            data = _fetch_and_absolutize(new_url)
                                            self.send_response(200)
                                            self.send_header(
                                                "Content-Type",
                                                "application/vnd.apple.mpegurl",
                                            )
                                            self.send_header(
                                                "Content-Length", str(len(data))
                                            )
                                            self.end_headers()
                                            self.wfile.write(data)
                                            _dbg(
                                                "SERVED from refreshed URL type={}".format(
                                                    type_key
                                                )
                                            )
                                            return
                                        except Exception:
                                            pass
                                cached = (
                                    _proxy_state["chunklist_cache"].get(type_key)
                                    if type_key
                                    else None
                                )
                                if cached:
                                    _dbg(
                                        "SERVING CACHED playlist type={}".format(
                                            type_key
                                        )
                                    )
                                    self.send_response(200)
                                    self.send_header(
                                        "Content-Type", "application/vnd.apple.mpegurl"
                                    )
                                    self.send_header("Content-Length", str(len(cached)))
                                    self.end_headers()
                                    self.wfile.write(cached)
                                else:
                                    endlist = b"#EXTM3U\n#EXT-X-ENDLIST\n"
                                    self.send_response(200)
                                    self.send_header(
                                        "Content-Type", "application/vnd.apple.mpegurl"
                                    )
                                    self.send_header(
                                        "Content-Length", str(len(endlist))
                                    )
                                    self.end_headers()
                                    self.wfile.write(endlist)
                        elif self.path.startswith("/segment"):
                            parsed = urllib_parse.urlparse(self.path)
                            params = urllib_parse.parse_qs(parsed.query)
                            seg_url = params.get("url", [None])[0]
                            if not seg_url:
                                self.send_error(400)
                                return

                            seg_name = seg_url.rsplit("/", 1)[-1].split("?")[0]
                            resolved_url = _proxy_state["seg_cdn_urls"].get(seg_name)
                            if not resolved_url and _is_safe_url(seg_url):
                                resolved_url = seg_url
                            if not resolved_url:
                                self.send_error(404)
                                return

                            _proxy_state["last_request"] = time.time()
                            _proxy_state["request_count"] = (
                                _proxy_state.get("request_count", 0) + 1
                            )
                            try:
                                sreq = _Req(
                                    resolved_url, headers=_proxy_state["headers"]
                                )
                                sresp = _uopen(sreq, timeout=10)
                                data = sresp.read()
                                ct = sresp.headers.get("Content-Type", "video/mp4")
                                self.send_response(200)
                                self.send_header("Content-Type", ct)
                                self.send_header("Content-Length", str(len(data)))
                                self.end_headers()
                                self.wfile.write(data)
                                return
                            except Exception as e:
                                _dbg("SEG FAIL {} {}".format(seg_name, e))
                                _trigger_reconnect("segment fail: {}".format(seg_name))
                            tm = re.search(r"(video|audio)_(\d+)_llhls", seg_name)
                            if tm:
                                for tk, latest in _proxy_state["latest_seg"].items():
                                    if tm.group(1) in tk and tm.group(2) in tk:
                                        try:
                                            sreq = _Req(
                                                latest, headers=_proxy_state["headers"]
                                            )
                                            sresp = _uopen(sreq, timeout=10)
                                            data = sresp.read()
                                            ct = sresp.headers.get(
                                                "Content-Type", "video/mp4"
                                            )
                                            self.send_response(200)
                                            self.send_header("Content-Type", ct)
                                            self.send_header(
                                                "Content-Length", str(len(data))
                                            )
                                            self.end_headers()
                                            self.wfile.write(data)
                                            _dbg("SEG LATEST OK {}".format(seg_name))
                                            return
                                        except Exception as e3:
                                            _dbg("SEG LATEST FAIL {}".format(e3))
                                            break
                            self.send_error(502)
                            return
                        else:
                            self.send_response(200)
                            self.send_header(
                                "Content-Type", "application/vnd.apple.mpegurl"
                            )
                            self.send_header("Content-Length", str(len(master_bytes)))
                            self.end_headers()
                            self.wfile.write(master_bytes)

                    def do_HEAD(self):
                        self.send_response(200)
                        self.send_header(
                            "Content-Type", "application/vnd.apple.mpegurl"
                        )
                        self.end_headers()

                    def log_message(self, *a):
                        pass

                class _S(ThreadingMixIn, TCPServer):
                    daemon_threads = True
                    allow_reuse_address = True

                srv = _S(("127.0.0.1", port), _H)
                _cb_proxies[port] = {"proxy": srv, "state": _proxy_state}
                t = threading.Thread(target=srv.serve_forever)
                t.daemon = True
                t.start()

                def _monitor_player():
                    """Keep this proxy alive while inputstream is fetching from it."""

                    _dbg("MONITOR: thread started for port={}".format(port))
                    _proxy_state["last_request"] = time.time()
                    try:
                        mon = xbmc.Monitor()
                        confirmed = False
                        for _ in range(60):
                            if mon.abortRequested() or _proxy_state.get("stopping"):
                                _dbg("MONITOR: abort/stop during grace window")
                                break
                            if _proxy_state.get("request_count", 0) > 0:
                                confirmed = True
                                _dbg("MONITOR: first request received, proxy active")
                                break
                            if mon.waitForAbort(0.5):
                                break
                        if not confirmed:
                            _dbg(
                                "MONITOR: no requests in 30s, tearing down idle proxy"
                            )
                        else:
                            _dbg("MONITOR: watching for inactivity")
                            while not mon.abortRequested() and not _proxy_state.get(
                                "stopping"
                            ):
                                if mon.waitForAbort(5):
                                    break
                                idle = time.time() - _proxy_state.get(
                                    "last_request", 0
                                )
                                _dbg("MONITOR: port={} idle={:.0f}s".format(port, idle))
                                if idle > 30:
                                    _dbg(
                                        "MONITOR: port={} idle >30s, tearing down".format(
                                            port
                                        )
                                    )
                                    break
                    except Exception as mex:
                        _dbg("MONITOR THREAD CRASHED: {}".format(mex))
                    _dbg(
                        "MONITOR: teardown entered addr={}".format(
                            getattr(srv, "server_address", "?")
                        )
                    )
                    _proxy_state["stopping"] = True
                    try:
                        srv.shutdown()
                        _dbg("MONITOR: shutdown() OK")
                    except Exception as mex2:
                        _dbg("MONITOR: shutdown err {}".format(mex2))
                    try:
                        srv.server_close()
                        _dbg("MONITOR: proxy shutdown complete")
                    except Exception as mex3:
                        _dbg("MONITOR: close err {}".format(mex3))
                    _cb_proxies.pop(port, None)
                    _dbg("MONITOR: removed port={} from _cb_proxies".format(port))

                _mt = threading.Thread(target=_monitor_player)
                _mt.daemon = True
                _mt.start()

                videourl = "http://127.0.0.1:{}/master.m3u8|Referer={}".format(
                    port, urllib_parse.quote(url)
                )
            except Exception as e:
                utils.kodilog("Chaturbate proxy error: {}".format(e))
                fallback_headers = HTTP_HEADERS_IPAD.copy()
                fallback_headers["Referer"] = url
                videourl = "{0}|{1}".format(
                    m3u8stream, urllib_parse.urlencode(fallback_headers)
                )
        else:
            utils.notify("Oh oh", "Couldn't find a playable webcam link")
            return

    elif playmode == 1:
        if data and m3u8stream and "edge_auth" in data:
            streamserver = "rtmp://{}/live-edge".format(m3u8stream.split("/")[2])
            modelname = data["broadcaster_username"]
            username_full = data["viewer_username"]
            username = "anonymous"
            room_pass = data["room_pass"]
            swfurl = "https://ssl-ccstatic.highwebmedia.com/theatermodeassets/CBV_TS_v1.0.swf"
            edge_auth = data["edge_auth"]
            videourl = (
                "%s app=live-edge swfUrl=%s pageUrl=%s conn=S:%s conn=S:%s conn=S:3.22 conn=S:%s conn=S:%s conn=S:%s playpath=mp4"
                % (
                    streamserver,
                    swfurl,
                    url,
                    username_full,
                    modelname,
                    username,
                    room_pass,
                    edge_auth,
                )
            )
        else:
            utils.notify("Oh oh", "Couldn't find a playable webcam link")
            return

    vp = utils.VideoPlayer(name)
    vp.IA_check = "IA"
    vp.play_from_direct_link(videourl)


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, "Search")
    else:
        title = urllib_parse.quote_plus(keyword)
        url += title
        SList(url)


@site.register()
def topCams(url):
    if addon.getSetting("chaturbate") == "true":
        clean_database(False)
    response, _ = utils.get_html_with_cloudflare_retry(url)
    jsonTop = json.loads(response)["top"]
    for iTop in jsonTop:
        subject = (
            "[COLOR deeppink]Name: [/COLOR]"
            + iTop["room_user"]
            + "[CR]"
            + "[CR][COLOR deeppink]Points: [/COLOR]"
            + str(iTop["points"])
            + "[CR]"
            + "[COLOR deeppink]Watching: [/COLOR]"
            + str(iTop["viewers"])
        )
        site.add_download_link(
            iTop["room_user"],
            bu + iTop["room_user"] + "/",
            "Playvid",
            iTop["image_url"],
            subject,
            noDownload=True,
        )
    utils.eod()


@site.register()
def Tags(url, page=1):
    cat = re.search(r"&g=([^&]*)", url).group(1)
    html, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    jdata = json.loads(html)
    total = jdata["total"]
    for tag in jdata["hashtags"]:
        name = tag["hashtag"]
        count = tag["room_count"]
        img = tag["top_rooms"][0].get("img", "") if tag["top_rooms"] else ""
        tagurl = rapi + "?genders={0}&hashtags={1}&limit=100&offset=0".format(cat, name)
        name += " [COLOR hotpink][" + str(count) + "][/COLOR]"
        site.add_dir(name, tagurl, "List", img, 1)
    if page * 100 < total:
        lastpg = -1 * (-total // 100)
        np_url = url.replace("&page={}".format(page), "&page={}".format(page + 1))
        site.add_dir(
            "Next Page.. (Currently in Page {0} of {1})".format(page, lastpg),
            np_url,
            "Tags",
            site.img_next,
            page=page + 1,
        )
    utils.eod()


@site.register()
def onlineFav(url):
    if addon.getSetting("chaturbate") == "true":
        clean_database(False)

    wmArray = [
        "C9m5N",
        "tfZSl",
        "jQrKO",
        "5XO2a",
        "WXomN",
        "zM6MR",
        "Lb2aB",
        "cIbs3",
        "zM6MR",
        "mnzQo",
        "N6TZA",
    ]
    chaturbate_url = (
        "https://chaturbate.com/affiliates/api/onlinerooms/?format=json&wm="
        + random.choice(wmArray)
    )
    data_chat, _ = utils.get_html_with_cloudflare_retry(chaturbate_url, "")
    model_list = json.loads(data_chat)
    model_lookup = {item["username"]: item for item in model_list}
    conn = sqlite3.connect(utils.favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute(
        "SELECT DISTINCT name, url, image FROM favorites WHERE mode='chaturbate.Playvid'"
    )
    result = c.fetchall()
    c.close()
    for name, url, image in result:
        stripped_name = name.split("[COLOR")[0].strip()
        if stripped_name in model_lookup:
            model = model_lookup[stripped_name]
            image = model["image_url"]
            current_show = ""
            if "current_show" in model:
                if model["current_show"] != "public":
                    current_show = "[COLOR blue] {}[/COLOR]".format(
                        model["current_show"]
                    )
            subject = (
                model["room_subject"]
                if utils.PY3
                else model["room_subject"].encode("utf8")
            )
            location = (
                model["location"] if utils.PY3 else model["location"].encode("utf8")
            )
            subject = (
                utils.cleantext(subject.split(" #")[0])
                + "[CR][CR][COLOR deeppink]Location: [/COLOR]"
                + location
                + "[CR]"
                + "[COLOR deeppink]Duration: [/COLOR]"
                + str(round(model["seconds_online"] / 3600, 1))
                + " hrs[CR]"
                + "[COLOR deeppink]Watching: [/COLOR]"
                + str(model["num_users"])
                + " viewers"
            )
            tags = "[COLOR deeppink]#[/COLOR]" + ", [COLOR deeppink]#[/COLOR]".join(
                model["tags"]
            )
            tags = tags if utils.PY3 else tags.encode("utf8")
            subject += "[CR][CR]" + tags

            id = model["username"]
            contextrecord = (
                utils.addon_sys
                + "?mode=chaturbate.Record&id="
                + urllib_parse.quote_plus(id)
            )
            contextmenu = [
                (
                    "[COLOR violet]Find recordings featuring [/COLOR]{}[COLOR violet] on Cloudbate[/COLOR]".format(
                        id
                    ),
                    "RunPlugin(" + contextrecord + ")",
                )
            ]

            site.add_download_link(
                name + current_show,
                url,
                "Playvid",
                image,
                utils.cleantext(subject),
                noDownload=True,
                fav="del",
                contextm=contextmenu,
            )
    utils.eod()


def login():
    sessionid = addon.getSetting("sessionid")
    if len(sessionid) == 32:
        session_cookie = get_cookie()
        if sessionid not in session_cookie:
            cookie = {
                "solution": {
                    "cookies": [
                        {
                            "name": "sessionid",
                            "domain": ".chaturbate.com",
                            "value": sessionid,
                            "path": "/",
                            "secure": True,
                            "expiry": None,
                            "httpOnly": None,
                        }
                    ],
                    "userAgent": utils.USER_AGENT,
                }
            }
            utils.savecookies(cookie)

    url = "https://chaturbate.com/followed-cams/"
    loginurl = "https://chaturbate.com/auth/login/?next=/followed-cams/"

    loginhtml, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    if "<h1>Chaturbate Login</h1>" not in loginhtml:
        return

    username = utils._get_keyboard(default="", heading="Input your Chaturbate username")
    password = utils._get_keyboard(
        default="", heading="Input your Chaturbate password", hidden=True
    )

    soup = utils.parse_html(loginhtml)
    token_input = soup.find("input", attrs={"name": "csrfmiddlewaretoken"})
    if not token_input:
        return
    csrfmiddlewaretoken = token_input.get("value")
    if not csrfmiddlewaretoken:
        return
    hdr = utils.base_hdrs
    hdr.update({"Referer": "https://chaturbate.com/auth/login/?next=/followed-cams/"})
    postRequest = {
        "next": "/followed-cams/",
        "csrfmiddlewaretoken": csrfmiddlewaretoken,
        "username": username,
        "password": password,
        "rememberme": "on",
    }
    response = utils._postHtml(loginurl, headers=hdr, form_data=postRequest)
    if "<h1>Chaturbate Login</h1>" in response:
        utils.notify(
            "Chaturbate", "Login failed please check your username and password"
        )


@site.register()
def Unfollow(id):
    url = "https://chaturbate.com/follow/unfollow/{}/".format(id)
    html, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    if "<h1>Chaturbate Login</h1>" in html:
        login()
        html, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    soup = utils.parse_html(html)
    token_input = soup.find("input", attrs={"name": "csrfmiddlewaretoken"})
    if not token_input:
        return
    csrfmiddlewaretoken = token_input.get("value")
    if not csrfmiddlewaretoken:
        return
    hdr = utils.base_hdrs
    hdr.update({"Referer": "https://chaturbate.com/"})
    postRequest = {"csrfmiddlewaretoken": csrfmiddlewaretoken}
    response = utils._postHtml(url, headers=hdr, form_data=postRequest)
    if '"following": false' in response:
        utils.notify("Chaturbate", "NOT FOLLOWING [COLOR hotpink]{}[/COLOR]".format(id))
        utils.refresh()


@site.register()
def Follow(id):
    url = "https://chaturbate.com/follow/follow/{}/".format(id)
    html, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    if "<h1>Chaturbate Login</h1>" in html:
        login()
        html, _ = utils.get_html_with_cloudflare_retry(url, site.url)
    soup = utils.parse_html(html)
    token_input = soup.find("input", attrs={"name": "csrfmiddlewaretoken"})
    if not token_input:
        return
    csrfmiddlewaretoken = token_input.get("value")
    if not csrfmiddlewaretoken:
        return
    hdr = utils.base_hdrs
    hdr.update({"Referer": "https://chaturbate.com/"})
    postRequest = {"csrfmiddlewaretoken": csrfmiddlewaretoken}
    response = utils._postHtml(url, headers=hdr, form_data=postRequest)
    if '"following": true' in response:
        utils.notify("Chaturbate", "FOLLOWING [COLOR hotpink]{}[/COLOR]".format(id))
        utils.refresh()


def get_cookie():
    domain = ".chaturbate.com"
    cookiestr = ""
    for cookie in utils.cj:
        if cookie.domain == domain and cookie.name == "sessionid":
            cookiestr = cookie.value
    return cookiestr


@site.register()
def Record(id):
    import xbmcgui

    search_engines = [
        {
            "name": "Cloudbate",
            "url": "https://www.cloudbate.com/search/{0}/",
            "search": "?mode=cloudbate.Search&url={}&keyword={}",
        },
        {
            "name": "iXXX",
            "url": "https://www.ixxx.com/search/{0}/",
            "search": "?mode=awmnet.Search&url={}&keyword={}",
        },
        {
            "name": "CamWhores.tv",
            "url": "https://www.camwhores.tv/search/",
            "search": "?mode=camwhorestv.Search&url={}&keyword={}",
        },
        {
            "name": "CamWhoresBay",
            "url": "https://www.camwhoresbay.com/search/{0}/",
            "search": "?mode=camwhoresbay.Search&url={}&keyword={}",
        },
        {
            "name": "CamGirlFap",
            "url": "https://camgirlfap.com/search/",
            "search": "?mode=camgirlfap.Search&url={}&keyword={}",
        },
        {
            "name": "DrTuber",
            "url": "https://www.drtuber.com/search/videos/",
            "search": "?mode=drtuber.Search&url={}&keyword={}",
        },
    ]
    selection = xbmcgui.Dialog().select(
        "Select site for search", [engine["name"] for engine in search_engines]
    )
    if selection != -1:
        engine = search_engines[selection]
        target_url = engine["url"].format(id)
        contexturl = utils.addon_sys + engine["search"].format(
            urllib_parse.quote_plus(target_url), id
        )
        xbmc.executebuiltin("Container.Update(" + contexturl + ")")
    utils.eod()
