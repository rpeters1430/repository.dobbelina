"""
Cumination
Copyright (C) 2015 Whitecream

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import gzip
import json
import os.path
import random
import re
import sqlite3
import ssl
import string
import sys
import tempfile
import time
from functools import wraps
from math import ceil
from threading import Thread

import six
import StorageServer
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
from resources.lib import cloudflare, random_ua, strings, jsunpack
from resources.lib.http_timeouts import HTTP_TIMEOUT_DEFAULT, HTTP_TIMEOUT_LONG
from resources.lib.basics import (
    addDir,
    addon,
    addon_handle,
    addon_sys,
    cookiePath,
    cum_image,
    cuminationicon,
    eod,
    favoritesdb,
    keys,
    searchDir,
    profileDir,
)
from resources.lib.brotlidecpy import decompress
from resources.lib.url_dispatcher import URL_Dispatcher
from resources.lib.jsonrpc import toggle_debug
from six.moves import (
    html_parser,
    http_cookiejar,
    urllib_error,
    urllib_parse,
    urllib_request,
)

cache_time_setting = addon.getSetting("cache_time")
cache_time = int(cache_time_setting) if cache_time_setting else 4
cache = StorageServer.StorageServer("cumination", cache_time)
url_dispatcher = URL_Dispatcher("utils")

USER_AGENT = random_ua.get_ua()
PY2 = six.PY2
PY3 = six.PY3
TRANSLATEPATH = xbmcvfs.translatePath if PY3 else xbmc.translatePath
LOGINFO = xbmc.LOGINFO if PY3 else xbmc.LOGNOTICE
try:
    _version = xbmcaddon.Addon("xbmc.addon").getAddonInfo("version")
    _match = re.search(r"(\d+\.\d+)", _version)
    KODIVER = float(_match.group(1)) if _match else 19.0
except Exception:
    KODIVER = 19.0

base_hdrs = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Charset": "ISO-8859-1,utf-8;q=0.7,*;q=0.3",
    "Accept-Encoding": "gzip",
    "Accept-Language": "en-US,en;q=0.8",
    "Connection": "keep-alive",
}

DOODSTREAM_DOMAINS = [
    "dood.watch",
    "doodstream.com",
    "dood.to",
    "dood.so",
    "dood.cx",
    "dood.la",
    "dood.ws",
    "dood.sh",
    "doodstream.co",
    "dood.pm",
    "dood.wf",
    "dood.re",
    "dood.yt",
    "dooood.com",
    "dood.stream",
    "ds2play.com",
    "doods.pro",
    "ds2video.com",
    "d0o0d.com",
    "do0od.com",
    "d0000d.com",
    "d000d.com",
    "dood.li",
    "dood.work",
    "dooodster.com",
    "vidply.com",
    "all3do.com",
    "do7go.com",
    "doodcdn.io",
    "doply.net",
    "vide0.net",
    "vvide0.com",
    "d-s.io",
    "dsvplay.com",
    "myvidplay.com",
    "nowplay.to",
    "playmogo.com",
    "playmago.com",
]

progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

urlopen = urllib_request.urlopen
cj = http_cookiejar.LWPCookieJar(TRANSLATEPATH(cookiePath))
Request = urllib_request.Request

handlers = [urllib_request.HTTPBasicAuthHandler(), urllib_request.HTTPHandler()]


def _create_ssl_context():
    """Return a secure TLS client context enforcing TLS 1.2 as the minimum."""
    context = ssl.create_default_context()
    # Preferred path: ssl.TLSVersion available in Python 3.7+ with modern OpenSSL.
    tls_version = getattr(ssl, "TLSVersion", None)
    if tls_version and hasattr(context, "minimum_version"):
        context.minimum_version = tls_version.TLSv1_2
    else:
        # Fallback for older Python/OpenSSL: explicitly disable TLS 1.0 and 1.1
        # via options flags so insecure protocol versions are never negotiated.
        for opt in ("OP_NO_TLSv1", "OP_NO_TLSv1_1"):
            flag = getattr(ssl, opt, None)
            if flag is not None:
                context.options |= flag
    return context


handlers.append(urllib_request.HTTPSHandler(context=_create_ssl_context()))


def kodilog(logvar, level=LOGINFO):
    xbmc.log("@@@@Cumination: " + str(logvar), level)


# ============================================================================
# BeautifulSoup HTML Parsing Helpers
# ============================================================================


def parse_html(html):
    """
    Parse HTML string into BeautifulSoup object.

    Uses lxml parser for speed and robustness. Falls back to html.parser if lxml unavailable.

    Args:
        html (str): HTML content as string

    Returns:
        BeautifulSoup: Parsed HTML document

    Example:
        soup = parse_html(listhtml)
        videos = soup.select('div.video-item')
    """
    if not html:
        from bs4 import BeautifulSoup
        return BeautifulSoup("", "html.parser")
    try:
        from bs4 import BeautifulSoup

        try:
            return BeautifulSoup(html, "lxml")
        except Exception:
            # Fallback to built-in parser if lxml not available
            return BeautifulSoup(html, "html.parser")
    except ImportError:
        kodilog(
            "BeautifulSoup not available, install script.module.beautifulsoup4",
            xbmc.LOGERROR,
        )
        raise ImportError(
            "BeautifulSoup4 is required. Install script.module.beautifulsoup4 addon."
        )


def safe_get_attr(element, attr, fallback_attrs=None, default=""):
    """
    Safely get attribute from BeautifulSoup element with fallback options.

    Args:
        element: BeautifulSoup element
        attr (str): Primary attribute name to get
        fallback_attrs (list): List of fallback attribute names to try
        default (str): Default value if all attributes missing

    Returns:
        str: Attribute value or default

    Example:
        # Try data-src first, fall back to src, default to empty string
        img = safe_get_attr(img_tag, 'data-src', ['src'])
    """
    if not element:
        return default

    # Try primary attribute
    value = element.get(attr)
    if value:
        return value

    # Try fallback attributes
    if fallback_attrs:
        for fallback in fallback_attrs:
            value = element.get(fallback)
            if value:
                return value

    return default


def get_thumbnail(element, default=""):
    """
    Standardized robust thumbnail extraction from BeautifulSoup element.
    Handles data-src, data-original, srcset, data-lazy, etc.
    Filters out obvious placeholders/tracking pixels.
    """
    if not element:
        return default

    # Common attributes used for thumbnails
    attrs = [
        "data-webp",
        "data-src",
        "data-original",
        "original",
        "data-lazy",
        "data-lazy-src",
        "data-thumbnail",
        "data-srcset",
        "srcset",
        "src",
    ]

    for attr in attrs:
        val = element.get(attr)
        if not val:
            continue

        # Handle srcset (take last/highest resolution if multiple)
        if "srcset" in attr and "," in val:
            parts = [p.strip().split(" ")[0] for p in val.split(",")]
            if parts:
                val = parts[-1]

        # Ignore obvious placeholders/tracking pixels/empty strings
        if val and "data:image" not in val and not val.endswith(".gif") and len(val) > 10:
            return val

    # Final fallback to src if all else failed or was filtered
    return element.get("src", default)


def safe_get_text(element, default="", strip=True):
    """
    Safely get text content from BeautifulSoup element.

    Args:
        element: BeautifulSoup element
        default (str): Default value if element is None
        strip (bool): Whether to strip whitespace

    Returns:
        str: Text content or default

    Example:
        duration = safe_get_text(soup.select_one('.duration'))
    """
    if not element:
        return default

    text = element.get_text()
    return text.strip() if strip else text


def soup_videos_list(
    site,
    soup,
    selectors,
    play_mode="Playvid",
    contextm=None,
    base_url=None,
    fanart=None,
    description=None,
):
    """Build a list of videos from BeautifulSoup selections.

    The helper processes BeautifulSoup fragments using declarative selector
    configuration.  Each selector entry can specify CSS queries, attribute
    fallbacks and post-processing flags so migrated sites avoid bespoke
    scraping loops.

    Args:
        site (AdultSite): Active site dispatcher instance.
        soup (BeautifulSoup): Parsed document or fragment to operate on.
        selectors (dict): Configuration describing how to extract data.
        play_mode (str): Mode registered on ``site`` that plays a video.
        contextm (Any): Optional context menu definition passed to
            ``site.add_download_link``.
        base_url (str): Base URL used for ``urljoin`` resolution.  Defaults
            to ``selectors['base_url']`` or ``site.url``.
        fanart (str): Optional fanart passed to ``site.add_download_link``.
        description (str or dict): Static or selector driven description.

    Selector dictionary keys:

    ``items``
        CSS selector (string), list of selectors or callable returning
        iterable of item elements. Required.

    ``url``
        Dict describing how to extract the video page URL. Supports ``attr``
        and ``fallback_attrs`` keys.  URLs are automatically resolved with
        :func:`urllib_parse.urljoin`.

    ``title`` / ``name``
        Dict describing how to extract the display title. ``clean`` defaults
        to ``True`` so the helper automatically runs :func:`cleantext`.

    ``thumbnail`` / ``image``
        Dict describing the thumbnail. Pass ``join=False`` to skip
        :func:`urllib_parse.urljoin` resolution.

    ``duration`` / ``quality`` / ``description``
        Optional dict entries following the same pattern.

    ``pagination`` / ``next``
        Dict describing how to locate pagination links. Supports the same
        selector options plus ``text_matches`` (list of lower-cased search
        terms), ``label``, ``mode``, ``icon``, ``add_dir`` and ``base_url``.

    Returns:
        dict: Metadata including ``items`` added and pagination details.
    """

    def _ensure_iterable(value):
        if value is None:
            return []
        if isinstance(value, (list, tuple)):
            return list(value)
        return [value]

    def _select_element(root, config, *, default_scope="item"):
        if config is None:
            return root
        if isinstance(config, dict):
            scope = config.get("scope", default_scope)
            selectors_list = None
            if "selectors" in config:
                selectors_list = config["selectors"]
            elif "selector" in config:
                selectors_list = config["selector"]
            elif "query" in config:
                selectors_list = config["query"]
            selectors_list = _ensure_iterable(selectors_list)
            if not selectors_list:
                selectors_list = [None]
            base = soup if scope == "soup" else root
            for selector in selectors_list:
                element = None
                if callable(selector):
                    element = selector(root, soup)
                elif isinstance(selector, dict):
                    element = _select_element(root, selector, default_scope=scope)
                elif selector is None or selector == ":self":
                    element = base
                else:
                    if base is not None and hasattr(base, "select_one"):
                        element = base.select_one(selector)
                if element:
                    return element
            if selectors_list:
                return None
            return base
        if callable(config):
            return config(root, soup)
        if isinstance(config, (list, tuple)):
            for selector in config:
                element = _select_element(root, selector, default_scope=default_scope)
                if element:
                    return element
            return root
        if config is None or config == ":self":
            return root
        base = soup if default_scope == "soup" else root
        if base is not None and hasattr(base, "select_one"):
            return base.select_one(config)
        return base

    def _extract_value(item, config, *, default=""):
        if config is None:
            return default
        if callable(config) and not isinstance(config, dict):
            return config(item, soup)
        local_config = config.copy() if isinstance(config, dict) else config
        if isinstance(local_config, dict):
            element = _select_element(item, local_config)
            attr_name = local_config.get("attr")
            fallback_attrs = list(local_config.get("fallback_attrs", []) or [])
            if not attr_name and fallback_attrs:
                attr_name = fallback_attrs.pop(0)
            value = default
            if attr_name and element:
                value = safe_get_attr(
                    element, attr_name, fallback_attrs or None, default=default
                )
            if (not value or value == default) and local_config.get("text"):
                strip = local_config.get("strip", True)
                value = safe_get_text(element, default=default, strip=strip)
            if not value:
                value = local_config.get("default", default)
            if (not value or value == default) and local_config.get(
                "fallback_selectors"
            ):
                fallback_selectors = _ensure_iterable(
                    local_config.get("fallback_selectors")
                )
                for fallback in fallback_selectors:
                    fallback_config = local_config.copy()
                    fallback_config.pop("fallback_selectors", None)
                    fallback_config["selector"] = fallback
                    value = _extract_value(item, fallback_config, default=default)
                    if value and value != default:
                        break
            if local_config.get("clean"):
                value = cleantext(value)
            transform = local_config.get("transform")
            if callable(transform):
                value = transform(value, item)
            return value
        return default

    if soup is None:
        return {"items": 0, "skipped": 0, "pagination": {}}

    result = {
        "items": 0,
        "skipped": 0,
        "pagination": {},
        "next_url": None,
        "next_label": None,
        "next_mode": None,
        "pagination_added": False,
    }

    base_url = base_url or selectors.get("base_url") or getattr(site, "url", "")
    items_conf = selectors.get("items")
    if items_conf is None:
        return result

    if callable(items_conf):
        raw_items = list(items_conf(soup))
    else:
        raw_items = []
        seen_ids = set()
        for selector in _ensure_iterable(items_conf):
            if selector is None:
                continue
            for candidate in soup.select(selector):
                marker = id(candidate)
                if marker in seen_ids:
                    continue
                raw_items.append(candidate)
                seen_ids.add(marker)

    filter_fn = selectors.get("filter")

    url_conf = selectors.get("url") or selectors.get("link")
    title_conf = selectors.get("title") or selectors.get("name")
    image_conf = selectors.get("thumbnail") or selectors.get("image")
    duration_conf = selectors.get("duration")
    quality_conf = selectors.get("quality")
    description_conf = selectors.get("description")
    static_description = ""
    if isinstance(description, dict) or callable(description):
        description_conf = description
    elif isinstance(description, str):
        static_description = description

    for item in raw_items:
        if filter_fn and not filter_fn(item):
            result["skipped"] += 1
            continue

        video_url = _extract_value(item, url_conf, default="") if url_conf else ""
        if not video_url:
            result["skipped"] += 1
            continue
        url_base = base_url
        if isinstance(url_conf, dict) and url_conf.get("base_url"):
            url_base = url_conf["base_url"]
        video_url = urllib_parse.urljoin(url_base or "", video_url)

        local_title_conf = (
            title_conf.copy() if isinstance(title_conf, dict) else title_conf
        )
        if isinstance(local_title_conf, dict):
            local_title_conf.setdefault("clean", True)
        if local_title_conf:
            name = _extract_value(item, local_title_conf, default="")
        else:
            name = cleantext(safe_get_text(item, default=""))

        if not name:
            result["skipped"] += 1
            continue

        thumb = _extract_value(item, image_conf, default="") if image_conf else ""
        if thumb:
            join_thumb = True
            thumb_base = base_url
            if isinstance(image_conf, dict):
                join_thumb = image_conf.get("join", True)
                thumb_base = image_conf.get("base_url", thumb_base)
            if join_thumb:
                thumb = urllib_parse.urljoin(thumb_base or "", thumb)
            
        duration = (
            _extract_value(item, duration_conf, default="") if duration_conf else ""
        )
        quality = _extract_value(item, quality_conf, default="") if quality_conf else ""

        if isinstance(description_conf, dict):
            desc_value = _extract_value(
                item, description_conf, default=static_description
            )
        elif callable(description_conf):
            desc_value = description_conf(item, soup)
        else:
            desc_value = (
                description_conf
                if isinstance(description_conf, str)
                else static_description
            )

        item_contextm = contextm
        if callable(contextm):
            item_contextm = contextm(video_url, name)

        site.add_download_link(
            name,
            video_url,
            play_mode,
            thumb,
            desc=desc_value or "",
            contextm=item_contextm,
            fanart=fanart,
            duration=duration,
            quality=quality,
        )
        result["items"] += 1

    pagination_conf = selectors.get("pagination") or selectors.get("next")
    if pagination_conf:
        pagination_local = pagination_conf.copy()
        if "scope" not in pagination_local:
            pagination_local["scope"] = "soup"
        next_element = _select_element(soup, pagination_local, default_scope="soup")
        if next_element is soup:
            next_element = None

        text_matches = [
            m.lower()
            for m in pagination_conf.get("text_matches", [])
            if isinstance(m, str)
        ]

        attr_name = pagination_conf.get("attr", "href")
        fallback_attrs = list(pagination_conf.get("fallback_attrs", []) or [])
        if not attr_name and fallback_attrs:
            attr_name = fallback_attrs.pop(0)
        attr_fallbacks = fallback_attrs or None

        next_url = ""
        if next_element and attr_name:
            next_url = safe_get_attr(
                next_element, attr_name, attr_fallbacks, default=""
            )

        if not next_url and text_matches:
            tag_name = pagination_conf.get("tag", "a")
            for candidate in soup.find_all(tag_name):
                text = safe_get_text(candidate, default="").lower()
                if any(match in text for match in text_matches):
                    next_element = candidate
                    next_url = (
                        safe_get_attr(candidate, attr_name, attr_fallbacks, default="")
                        if attr_name
                        else ""
                    )
                    if next_url:
                        break

        if next_url:
            next_base = pagination_conf.get("base_url", base_url)
            next_url = urllib_parse.urljoin(next_base or "", next_url)
            label = pagination_conf.get("label", "Next Page")
            mode = pagination_conf.get("mode", "List")
            icon = pagination_conf.get("icon", getattr(site, "img_next", None))
            add_dir = pagination_conf.get("add_dir", True)
            if add_dir:
                site.add_dir(label, next_url, mode, icon)
            result.update(
                {
                    "next_url": next_url,
                    "next_label": label,
                    "next_mode": mode,
                    "pagination_added": bool(add_dir),
                }
            )
            result["pagination"] = {
                "url": next_url,
                "label": label,
                "mode": mode,
                "icon": icon,
                "added": bool(add_dir),
            }

    return result


@url_dispatcher.register()
def clear_cache():
    """
    Clear the cache database.
    """
    msg = i18n("cache_cleared")
    cache.table_name = "cumination"
    cache.cacheDelete("%get%")
    xbmcgui.Dialog().notification("Cumination", msg, cuminationicon, 3000, False)


@url_dispatcher.register()
def clear_cookies():
    msg = i18n("cookies_cleared")
    cj.clear()
    cj.save(cookiePath, ignore_discard=True)
    xbmcgui.Dialog().notification("Cumination", msg, cuminationicon, 3000, False)


def i18n(string_id):
    try:
        return six.ensure_str(addon.getLocalizedString(strings.STRINGS[string_id]))
    except Exception as e:
        kodilog("Failed String Lookup: %s (%s)" % (string_id, e))
        return string_id


if cj is not None:
    if os.path.isfile(TRANSLATEPATH(cookiePath)):
        try:
            cj.load(ignore_discard=True)
        except Exception:
            try:
                xbmcvfs.delete(TRANSLATEPATH(cookiePath))
                pass
            except Exception:
                dialog.ok(i18n("oh_oh"), i18n("cookie_lock"))
                pass
    cookie_handler = urllib_request.HTTPCookieProcessor(cj)
    handlers += [cookie_handler]

opener = urllib_request.build_opener(*handlers)
urllib_request.install_opener(opener)


class StopDownloading(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class NoRedirection(urllib_request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def downloadVideo(url, name):
    def _pbhook(downloaded, filesize, url=None, dp=None, name=""):
        try:
            percent = min(int((downloaded * 100) / filesize), 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(
                downloaded / (time.perf_counter() if PY3 else time.clock() - start)
            )
            if kbps_speed > 0:
                eta = (filesize - downloaded) / kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = "%.02f MB of %.02f MB" % (currently_downloaded, total)
            e = "Speed: %.02f Kb/s " % kbps_speed
            e += "ETA: %02d:%02d" % divmod(eta, 60)
            dp.update(percent, "{0}[CR]{1}[CR]{2}".format(name[:50], mbs, e))
        except Exception:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            dp.close()
            raise StopDownloading("Stopped Downloading")

    def getResponse(url, headers2, size):
        try:
            if size > 0:
                size = int(size)
                headers2["Range"] = "bytes=%d-" % size

            req = Request(url, headers=headers2)

            resp = urlopen(req, timeout=HTTP_TIMEOUT_DEFAULT)
            return resp
        except Exception:
            return None

    def doDownload(url, dest, dp, name):
        headers = {}
        if "|" in url:
            url, uheaders = url.split("|")
            headers = dict(urllib_parse.parse_qsl(uheaders))

        if "User-Agent" not in list(headers):
            headers.update({"User-Agent": USER_AGENT})

        resp = getResponse(url, headers, 0)

        if not resp:
            dialog.ok(
                "Cumination", "{0}[CR]{1}".format(i18n("dnld_fail"), i18n("no_resp"))
            )
            return False
        try:
            content = int(resp.headers["Content-Length"])
        except Exception:
            content = 0
        try:
            resumable = "bytes" in resp.headers["Accept-Ranges"].lower()
        except Exception:
            resumable = False
        if resumable:
            six.print_("Download is resumable")

        if content < 1:
            dialog.ok(
                "Cumination", "{0}[CR]{1}".format(i18n("unkn_size"), i18n("no_dnld"))
            )
            return False

        size = 8192
        mb = content / (1024 * 1024)

        if content < size:
            size = content

        total = 0
        errors = 0
        count = 0
        resume = 0
        sleep = 0

        six.print_("{0} : {1}MB {2} ".format(i18n("file_size"), mb, dest))
        f = xbmcvfs.File(dest, "w")

        chunk = None
        chunks = []

        while True:
            downloaded = total
            for c in chunks:
                downloaded += len(c)
            percent = min(100 * downloaded / content, 100)

            _pbhook(downloaded, content, url, dp, name)

            chunk = None
            error = False

            try:
                chunk = resp.read(size)
                if not chunk:
                    if percent < 99:
                        error = True
                    else:
                        while len(chunks) > 0:
                            c = chunks.pop(0)
                            f.write(c)
                            del c
                        f.close()
                        return True

            except Exception as e:
                six.print_(str(e))
                error = True
                sleep = 10
                errno = 0

                if hasattr(e, "errno"):
                    errno = e.errno

                if (
                    errno == 10035
                ):  # 'A non-blocking socket operation could not be completed immediately'
                    pass

                if (
                    errno == 10054
                ):  # 'An existing connection was forcibly closed by the remote host'
                    errors = 10  # force resume
                    sleep = 30

                if errno == 11001:  # 'getaddrinfo failed'
                    errors = 10  # force resume
                    sleep = 30

            if chunk:
                errors = 0
                chunks.append(chunk)
                if len(chunks) > 5:
                    c = chunks.pop(0)
                    f.write(c)
                    total += len(c)
                    del c

            if error:
                errors += 1
                count += 1
                xbmc.sleep(sleep * 1000)

            if (resumable and errors > 0) or errors >= 10:
                if (not resumable and resume >= 50) or resume >= 500:
                    # Give up!
                    return False

                resume += 1
                errors = 0
                if resumable:
                    chunks = []
                    # create new response
                    resp = getResponse(url, headers, total)
                else:
                    # use existing response
                    pass

    def clean_filename(s):
        if not s:
            return ""
        badchars = "\\/:*?\"<>|'"
        for c in badchars:
            s = s.replace(c, "")
        return s.strip()

    download_path = addon.getSetting("download_path")
    if download_path == "":
        try:
            download_path = dialog.browse(0, i18n("dnld_path"), "", "", False, False)
            addon.setSetting(id="download_path", value=download_path)
            if not xbmcvfs.exists(download_path):
                xbmcvfs.mkdir(download_path)
        except Exception:
            pass
    if download_path != "":
        dp = xbmcgui.DialogProgress()
        name = re.sub(r"\[COLOR.+?\/COLOR\]", "", name).strip()
        dp.create(i18n("cum_dnld"), name[:50])
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = (
            xbmc.makeLegalFilename(tmp_file)
            if PY2
            else xbmcvfs.makeLegalFilename(tmp_file)
        )
        start = time.perf_counter() if PY3 else time.clock()
        try:
            downloaded = doDownload(url, tmp_file, dp, name)
            if downloaded:
                if PY2:
                    vidfile = xbmc.makeLegalFilename(
                        download_path + clean_filename(name) + ".mp4"
                    )
                else:
                    vidfile = xbmcvfs.makeLegalFilename(
                        download_path + clean_filename(name) + ".mp4"
                    )
                try:
                    xbmcvfs.rename(tmp_file, vidfile)
                    return vidfile
                except Exception:
                    return tmp_file
            else:
                raise StopDownloading(i18n("stop_dnld"))
        except Exception:
            while xbmcvfs.exists(tmp_file):
                try:
                    xbmcvfs.delete(tmp_file)
                    break
                except Exception:
                    pass
        finally:
            dp.close()


def notify(header=None, msg="", duration=5000, icon=None):
    if header is None:
        header = "Cumination"
    if icon == "thumb":
        icon = xbmc.getInfoImage("ListItem.Thumb")
    if not icon or not isinstance(icon, str) or not icon.startswith("http"):
        icon = cuminationicon
    dialog.notification(header, msg, icon, duration, False)


@url_dispatcher.register()
def setview():
    skin = xbmc.getSkinDir().lower()
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    viewtype = str(win.getFocusId())
    addon.setSetting("setview", ";".join([skin, viewtype]))
    addon.setSetting("customview", "true")
    viewName = xbmc.getInfoLabel("Container.Viewmode")
    notify(i18n("dflt_view_set"), "{0} {1}".format(i18n("dflt_set"), viewName))
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def refresh():
    xbmc.executebuiltin("Container.Refresh")


def playvid(videourl, name, download=None, subtitle=None, IA_check="check"):
    progress.close()
    videourl = videourl.replace("&amp;", "&")
    if download == 1:
        downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        subject = xbmc.getInfoLabel("ListItem.Plot")
        listitem = xbmcgui.ListItem(name)
        listitem.setArt(
            {"thumb": iconimage, "icon": "DefaultVideo.png", "poster": iconimage}
        )
        if KODIVER > 19.8:
            vtag = listitem.getVideoInfoTag()
            vtag.setTitle(name)
            vtag.setGenres(["Porn"])
            vtag.setPlot(subject)
            vtag.setPlotOutline(subject)
        else:
            listitem.setInfo(
                "video",
                {
                    "Title": name,
                    "Genre": "Porn",
                    "plot": subject,
                    "plotoutline": subject,
                },
            )

        if IA_check != "skip":
            videourl, listitem = inputstream_check(videourl, listitem, IA_check)
        else:
            # When skipping IA_check, we should still set ContentLookup(False) 
            # for some sites that block HEAD requests (like hotleak)
            listitem.setContentLookup(False)

        if subtitle:
            if isinstance(subtitle, list):
                listitem.setSubtitles(subtitle)
            else:
                listitem.setSubtitles([subtitle])

        listitem.setProperty("script.trakt.exclude", "1")

        if int(sys.argv[1]) == -1:
            xbmc.Player().play(videourl, listitem)
        else:
            listitem.setPath(str(videourl))
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem)


def inputstream_check(url, listitem, IA_check):
    supported_endings = [
        [".hls", "application/vnd.apple.mpegstream_url"],
        [".mpd", "application/dash+xml"],
        [".ism", "application/vnd.ms-sstr+xml"],
    ]

    m3u8_use_ia = bool(IA_check == "IA" or addon.getSetting("m3u8_use_ia") == "true")
    if m3u8_use_ia:
        supported_endings.append([".m3u8", "application/x-mpegURL"])
    adaptive_type = None
    for ending in supported_endings:
        if ending[0] in url:
            if ending[0] == ".m3u8":
                adaptive_type = "hls"
            else:
                adaptive_type = ending[0][1:]
            mime_type = ending[1]

    if adaptive_type:
        from inputstreamhelper import Helper

        is_helper = Helper(adaptive_type)
        if not is_helper.check_inputstream():
            return url, listitem

        IA = "inputstream" if six.PY3 else "inputstreamaddon"
        listitem.setProperty(IA, "inputstream.adaptive")

        if "|" in url:
            url, strhdr = url.split("|")
            listitem.setProperty("inputstream.adaptive.stream_headers", strhdr)
            # Also set common_headers for Kodi 21+ to ensure headers are applied to init segments
            if KODIVER > 19.8:
                listitem.setProperty("inputstream.adaptive.common_headers", strhdr)
            # For Kodi 20-21, also set manifest_headers for compatibility
            if KODIVER > 19.8 and KODIVER <= 21.8:
                listitem.setProperty("inputstream.adaptive.manifest_headers", strhdr)
                listitem.setProperty("inputstream.adaptive.stream_params", strhdr)

        if KODIVER < 20.8:
            listitem.setProperty("inputstream.adaptive.manifest_type", adaptive_type)
        listitem.setMimeType(mime_type)
        listitem.setContentLookup(False)

    return url, listitem


@url_dispatcher.register()
def PlayStream(name, url):
    item = xbmcgui.ListItem(name, path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return


def getHtml(
    url,
    referer="",
    headers=None,
    NoCookie=None,
    data=None,
    error="return",
    timeout=HTTP_TIMEOUT_DEFAULT,
    ignore_ssl=False,
):
    if ignore_ssl:
        return _getHtml(
            url,
            referer,
            headers,
            NoCookie,
            data,
            error,
            timeout,
            ignore_ssl=True,
        )
    return cache.cacheFunction(
        _getHtml,
        url,
        referer,
        headers,
        NoCookie,
        data,
        error,
        timeout,
    )


def _getHtml(
    url,
    referer="",
    headers=None,
    NoCookie=None,
    data=None,
    error="return",
    timeout=HTTP_TIMEOUT_DEFAULT,
    ignore_ssl=False,
):
    url = urllib_parse.quote(url, r":/%?+&=")

    if data:
        if not isinstance(data, six.string_types):
            data = urllib_parse.urlencode(data)
        data = data if PY2 else six.b(data)
    if headers is None:
        headers = base_hdrs
    if "User-Agent" not in headers.keys():
        headers.update({"User-Agent": USER_AGENT})

    req = Request(url, data, headers)
    if len(referer) > 1:
        req.add_header("Referer", referer)
    if data:
        req.add_header("Content-Length", len(data))

    try:
        req_domain = urllib_parse.urlparse(url).netloc.lower()
        cf_cookie_names = [
            c.name
            for c in cj
            if c.domain.lstrip(".") in req_domain or req_domain.endswith(c.domain.lstrip("."))
        ]
        if cf_cookie_names:
            kodilog(
                "[CF-DIAG] direct request to {} sending stored cookies: {} "
                "(a stale cf_clearance here that FlareSolverr obtained on a "
                "different IP is the classic cause of solve-then-loop)".format(
                    url, cf_cookie_names
                )
            )
    except Exception as e:
        kodilog("[CF-DIAG] cookie diagnostic check failed: {}".format(e), xbmc.LOGDEBUG)

    response = None
    try:
        if ignore_ssl and PY3:
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urlopen(req, timeout=timeout, context=ctx)
        elif ignore_ssl and PY2:
            import ssl
            ctx = ssl._create_unverified_context()
            response = urlopen(req, timeout=timeout, context=ctx)
        else:
            response = urlopen(req, timeout=timeout)
    except urllib_error.HTTPError as e:
        kodilog("getHtml HTTPError: {}".format(str(e)), xbmc.LOGDEBUG)
        if error is True:
            response = e
        else:
            if e.info().get("Content-Encoding", "").lower() == "gzip":
                buf = six.BytesIO(e.read())
                f = gzip.GzipFile(fileobj=buf)
                result = f.read()
                f.close()
            else:
                result = e.read()
            result = (
                result.decode("latin-1", errors="ignore")
                if PY3
                else result.encode("utf-8")
            )
            if "cloudflare" in e.info().get("Server", "").lower():
                cf_ray = e.info().get("cf-ray", "") or e.info().get("CF-RAY", "")
                cf_mitigated = e.info().get("cf-mitigated", "")
                kodilog(
                    "[CF-DIAG] Cloudflare response for {} -> HTTP {} cf-ray={} "
                    "cf-mitigated={}".format(url, e.code, cf_ray or "n/a", cf_mitigated or "n/a")
                )
                if e.code == 403 and not e.info().get("cf-mitigated", False):
                    # Retry with an explicit modern TLS context for problematic servers.
                    kodilog(
                        "[CF-DIAG] {} -> 403 without cf-mitigated header, retrying once "
                        "with explicit TLS context (NOT going through FlareSolverr on "
                        "this path)".format(url)
                    )
                    ctx = _create_ssl_context()
                    handle = [urllib_request.HTTPSHandler(context=ctx)]
                    opener = urllib_request.build_opener(*handle)
                    try:
                        response = opener.open(req, timeout=timeout)
                        kodilog(
                            "[CF-DIAG] TLS-context retry for {} succeeded with HTTP {}".format(
                                url, response.getcode()
                            )
                        )
                    except urllib_error.HTTPError as e:
                        if e.info().get("Content-Encoding", "").lower() == "gzip":
                            buf = six.BytesIO(e.read())
                            f = gzip.GzipFile(fileobj=buf)
                            result = f.read()
                            f.close()
                        else:
                            result = e.read()
                        result = (
                            result.decode("latin-1", errors="ignore")
                            if PY3
                            else result.encode("utf-8")
                        )
                        kodilog(
                            "[CF-DIAG] TLS-context retry for {} also failed with HTTP {} "
                            "cf-ray={}".format(
                                url, e.code, e.info().get("cf-ray", "n/a")
                            ),
                            xbmc.LOGWARNING,
                        )
                        if addon.getSetting("fs_enable") == "true" or os.environ.get("FLARESOLVERR_URL"):
                            try:
                                return flaresolve(url, referer)
                            except Exception as fs_err:
                                kodilog("[CF-DIAG] FlareSolverr fallback error: {}".format(fs_err))
                        notify(i18n("oh_oh"), i18n("site_down"))
                        if "return" in error:
                            return ""
                        raise
                elif any(x == e.code for x in [403, 429, 503]) and any(
                    x in result
                    for x in [
                        "__cf_chl_f_tk",
                        "__cf_chl_jschl_tk__=",
                        "/cdn-cgi/challenge-platform/",
                    ]
                ):
                    if addon.getSetting("fs_enable") == "true":
                        notify(
                            "FlareSolverr", "Cloudflare detected, solving challenge..."
                        )
                        _note_flaresolverr_trigger(url, "js-challenge-markers-in-403-body")
                        kodilog(
                            "Cloudflare protection detected on {}, using FlareSolverr".format(
                                url
                            )
                        )
                        try:
                            return flaresolve(url, referer)
                        except RuntimeError as fs_error:
                            # FlareSolverr failed with a clear error message
                            kodilog(
                                "[CF-DIAG] FlareSolverr failed to solve {}: {}".format(
                                    url, str(fs_error)
                                ),
                                xbmc.LOGWARNING,
                            )
                            notify("FlareSolverr Failed", str(fs_error), duration=8000)
                            raise
                        except Exception as fs_error:
                            # Unexpected error from FlareSolverr
                            kodilog("FlareSolverr error: {}".format(str(fs_error)))
                            notify(
                                "FlareSolverr Error",
                                "Failed to bypass Cloudflare. Check Kodi log.",
                                duration=6000,
                            )
                            raise
                    else:
                        notify(
                            i18n("oh_oh"),
                            "Cloudflare protection detected. Enable FlareSolverr in addon settings.",
                            duration=6000,
                        )
                        raise
            elif 400 < e.code < 500:
                if not e.code == 403:
                    notify(i18n("oh_oh"), i18n("not_exist"))
                return ""
            else:
                notify(i18n("oh_oh"), i18n("site_down"))
                return ""
    except urllib_error.URLError as e:
        kodilog("getHtml URLError: {}".format(str(e)), xbmc.LOGDEBUG)
        if "return" in error:
            notify(i18n("oh_oh"), i18n("slow_site"))
            xbmc.log(str(e), xbmc.LOGDEBUG)
            return ""
        else:
            raise
    except Exception as e:
        kodilog("getHtml unexpected error: {}".format(str(e)), xbmc.LOGDEBUG)
        if "SSL23_GET_SERVER_HELLO" in str(e):
            notify(i18n("oh_oh"), i18n("python_old"))
            return ""
        else:
            notify(i18n("oh_oh"), i18n("site_down"))
            return ""
        return None

    if not response:
        return ""

    cencoding = response.info().get("Content-Encoding", "")
    if cencoding.lower() == "gzip":
        buf = six.BytesIO(response.read())
        f = gzip.GzipFile(fileobj=buf)
        result = f.read()
        f.close()
    else:
        result = response.read()

    if cencoding.lower() == "br":
        result = decompress(result)

    encoding = None
    content_type = response.headers.get("content-type", "")
    if "charset=" in content_type:
        encoding = content_type.split("charset=")[-1]

    if encoding is None:
        epattern = (
            r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"'
        )
        epattern = epattern.encode("utf8") if PY3 else epattern
        r = re.search(epattern, result, re.IGNORECASE)
        if r:
            encoding = r.group(1).decode("utf8") if PY3 else r.group(1)
        else:
            epattern = r"""<meta\s+charset=["']?([^"'>]+)"""
            epattern = epattern.encode("utf8") if PY3 else epattern
            r = re.search(epattern, result, re.IGNORECASE)
            if r:
                encoding = r.group(1).decode("utf8") if PY3 else r.group(1)

    if encoding is not None:
        result = result.decode(encoding.lower(), errors="ignore")
        result = result.encode("utf8") if PY2 else result
    else:
        result = (
            result.decode("latin-1", errors="ignore") if PY3 else result.encode("utf-8")
        )

    if not NoCookie:
        # Cope with problematic timestamp values on RPi on OpenElec 4.2.1
        try:
            cj.save(cookiePath, ignore_discard=True)
        except Exception as e:
            kodilog("Cookie save error: " + str(e), xbmc.LOGDEBUG)
    response.close()

    if "sucuri_cloudproxy_js" in result:
        headers["Cookie"] = get_sucuri_cookie(result)
        result = getHtml(url, referer, headers=headers)
    return result


# Per-domain diagnostics for the "solves the challenge then loops" symptom.
# If FlareSolverr's outbound IP differs from this device's, the cf_clearance
# cookie FlareSolverr obtains is often rejected on this device's own direct
# requests, forcing a fresh FlareSolverr solve on every single page load.
# These counters/timestamps exist purely to surface that pattern in the log.
_cf_domain_trigger_counts = {}
_CF_LOOP_WARNING_THRESHOLD = 2
_CF_LOOP_WINDOW_SECONDS = 600


def _note_flaresolverr_trigger(url, reason):
    """Log + track how often FlareSolverr is invoked per domain to surface loops."""
    try:
        domain = urllib_parse.urlparse(url).netloc.lower()
    except Exception:
        domain = url

    now = time.time()
    entry = _cf_domain_trigger_counts.get(domain)
    if entry and (now - entry["first_seen"]) <= _CF_LOOP_WINDOW_SECONDS:
        entry["count"] += 1
    else:
        entry = {"count": 1, "first_seen": now}
    _cf_domain_trigger_counts[domain] = entry

    kodilog(
        "[CF-DIAG] FlareSolverr triggered for domain={} reason={} "
        "(trigger #{} in last {}s)".format(
            domain, reason, entry["count"], _CF_LOOP_WINDOW_SECONDS
        )
    )

    if entry["count"] >= _CF_LOOP_WARNING_THRESHOLD:
        kodilog(
            "[CF-DIAG] LOOP SUSPECTED on domain={}: FlareSolverr has been invoked "
            "{} times within {}s. This usually means FlareSolverr's outbound IP "
            "differs from this device's outbound IP, so the cf_clearance cookie "
            "FlareSolverr obtains is being rejected on this device's direct "
            "requests, forcing a re-solve every time. Compare the cf-ray colo "
            "codes logged for direct vs FlareSolverr responses to confirm.".format(
                domain, entry["count"], _CF_LOOP_WINDOW_SECONDS
            ),
            xbmc.LOGWARNING,
        )


def flaresolve(url, referer):
    """
    Use FlareSolverr to bypass Cloudflare protection.

    Args:
        url: The URL to fetch
        referer: The referer URL (currently unused)

    Returns:
        HTML content of the page

    Raises:
        RuntimeError: If FlareSolverr is not configured or fails to solve
    """
    from resources.lib.flaresolverr import FlareSolverrManager

    fs_host = addon.getSetting("fs_host")
    if not fs_host:
        fs_host = "http://127.0.0.1:8191/v1"

    start_time = time.time()
    kodilog("[CF-DIAG] flaresolve() starting for {} via FlareSolverr host {}".format(url, fs_host))

    flaresolverr = None
    try:
        flaresolverr = FlareSolverrManager(fs_host)
        kodilog(
            "[CF-DIAG] FlareSolverr manager ready after {:.2f}s, sending stateless request for {}".format(
                time.time() - start_time, url
            )
        )
        # FlareSolverrManager handles API errors, retries, and local cookies.
        response = flaresolverr.request(url)

        elapsed = time.time() - start_time
        cf_ray = ""
        try:
            cf_ray = response.headers.get("cf-ray", "") if response.headers else ""
        except Exception:
            cf_ray = ""
        kodilog(
            "[CF-DIAG] FlareSolverr response for {} after {:.2f}s: HTTP {} "
            "final_url={} cf-ray={} body_len={}".format(
                url,
                elapsed,
                response.status_code,
                response.url,
                cf_ray or "n/a",
                len(response.text or ""),
            )
        )

        if response.status_code != 200:
            raise RuntimeError(
                "FlareSolverr solved challenge but got HTTP {} from website".format(
                    response.status_code
                )
            )

        listhtml = response.text
        if not listhtml:
            raise RuntimeError("FlareSolverr returned empty response")

        if is_cloudflare_challenge_page(listhtml):
            kodilog(
                "[CF-DIAG] WARNING: content returned by FlareSolverr for {} still "
                "matches Cloudflare challenge markers - the challenge was NOT "
                "actually solved (Turnstile/managed challenge FlareSolverr can't "
                "pass, or maxTimeout too low).".format(url),
                xbmc.LOGWARNING,
            )

        # Save cookies from FlareSolverr for future requests
        if hasattr(response, "raw_json") and response.raw_json:
            solution = (response.raw_json or {}).get("solution") or {}
            cookie_names = [
                "{}@{}".format(c.get("name"), c.get("domain"))
                for c in (solution.get("cookies") or [])
                if isinstance(c, dict)
            ]
            kodilog(
                "[CF-DIAG] FlareSolverr returned {} cookie(s) for {}: {} | userAgent={}".format(
                    len(cookie_names), url, cookie_names, solution.get("userAgent", "n/a")
                )
            )
            savecookies(response.raw_json)

        kodilog("FlareSolverr successfully bypassed Cloudflare for: {}".format(url))
        return listhtml

    except RuntimeError:
        # Re-raise RuntimeError with original message
        raise
    except Exception as e:
        # Wrap any other exception in RuntimeError with helpful message
        raise RuntimeError(
            "FlareSolverr error for {}: {}. "
            "Check if FlareSolverr is running at {}".format(url, str(e), fs_host)
        )
    finally:
        if flaresolverr:
            flaresolverr.close(destroy_session=True)


_CLOUDFLARE_CHALLENGE_MARKERS = (
    "cf-browser-verification",
    "__cf_chl",
    "just a moment...",
    "checking your browser before accessing",
    "attention required! | cloudflare",
    "why do i have to complete a captcha",
    "cloudflare-ray",
)


def is_cloudflare_challenge_page(content):
    """Return True if the response content looks like a Cloudflare challenge page."""

    if not content:
        return False
    if isinstance(content, bytes):
        try:
            content = content.decode("utf-8", errors="ignore")
        except UnicodeDecodeError:
            return False
    lowered = content.lower()
    return any(marker in lowered for marker in _CLOUDFLARE_CHALLENGE_MARKERS)


def get_html_with_cloudflare_retry(
    url,
    referer="",
    headers=None,
    NoCookie=None,
    data=None,
    error="return",
    retry_on_empty=False,
):
    """Fetch HTML and retry with FlareSolverr if Cloudflare blocks the request.

    Note: Custom headers (aside from ``Referer``) are not forwarded to
    FlareSolverr during the retry, and empty-response retries are only
    attempted when FlareSolverr support is enabled in the add-on settings.
    """

    direct_start = time.time()
    html = getHtml(
        url,
        referer,
        headers=headers,
        NoCookie=NoCookie,
        data=data,
        error=error,
    )
    kodilog(
        "[CF-DIAG] direct request for {} took {:.2f}s, body_len={}, "
        "looks_like_challenge={}".format(
            url,
            time.time() - direct_start,
            len(html or ""),
            is_cloudflare_challenge_page(html),
        )
    )

    fs_enabled = addon.getSetting("fs_enable") == "true"
    used_fs = False

    if is_cloudflare_challenge_page(html):
        if not fs_enabled:
            kodilog(
                "[CF-DIAG] Cloudflare challenge detected on {} but fs_enable is "
                "off; returning challenge page as-is.".format(url)
            )
            return html, False
        kodilog(
            "Cloudflare challenge detected on {}, retrying with FlareSolverr".format(
                url
            )
        )
        _note_flaresolverr_trigger(url, "direct-request-returned-challenge-page")
        html = flaresolve(url, referer)
        used_fs = True

    if retry_on_empty and not html and fs_enabled and not used_fs:
        kodilog(
            "Empty response received from {}, retrying with FlareSolverr".format(url)
        )
        _note_flaresolverr_trigger(url, "empty-direct-response")
        html = flaresolve(url, referer)
        used_fs = True

    return html, used_fs


def savecookies(flarejson):
    global USER_AGENT
    cj_cf = cj
    if not isinstance(flarejson, dict):
        return
    solution = flarejson.get("solution") or {}
    if not isinstance(solution, dict):
        return
    cookies = solution.get("cookies") or []
    if not isinstance(cookies, list):
        return

    for cookie in cookies:
        if not isinstance(cookie, dict):
            continue
        name = cookie.get("name")
        value = cookie.get("value")
        if not name or value is None:
            continue
        domain = cookie.get("domain") or ""
        path = cookie.get("path") or "/"
        c = http_cookiejar.Cookie(
            version=0,
            name=name,
            value=value,
            port=None,
            port_specified=False,
            domain=domain,
            domain_specified=bool(domain),
            domain_initial_dot=domain.startswith("."),
            path=path,
            path_specified=True,
            secure=bool(cookie.get("secure")),
            expires=cookie.get("expiry"),
            discard=True,
            comment=None,
            comment_url=None,
            rest={"HttpOnly": bool(cookie.get("httpOnly"))},
            rfc2109=False,
        )

        cj_cf.set_cookie(c)
    cj_cf.save(cookiePath, ignore_discard=True)
    UA = flarejson["solution"]["userAgent"]
    kodilog(
        "[CF-DIAG] savecookies: stored {} cookie(s) from FlareSolverr, "
        "USER_AGENT now '{}' (was '{}')".format(len(cookies), UA, USER_AGENT)
    )
    random_ua.set_ua(UA)
    USER_AGENT = UA


def get_cookies_string(domain):
    """
    Get cookies for a domain as a string compatible with Kodi's URL format.
    """
    if not domain:
        return ""

    if domain.startswith("http"):
        domain = urllib_parse.urlparse(domain).netloc

    # Remove 'www.' prefix for broader matching
    clean_domain = domain[4:] if domain.startswith("www.") else domain
    
    cookiestr = ""
    for cookie in cj:
        # Match domain exactly or as a parent domain (e.g. .site.com matches site.com)
        c_domain = cookie.domain.lstrip(".")
        if clean_domain.endswith(c_domain) or c_domain.endswith(clean_domain):
            cookiestr += "{}={}; ".format(cookie.name, cookie.value)

    return cookiestr.rstrip("; ")


def get_kodi_url(url, referer=None):
    """
    Append User-Agent, Referer, and Cookies to a URL for Kodi's internal downloader.
    Format: URL|User-Agent=UA&Referer=REF&Cookie=COOKIES
    """
    if not url:
        return url

    # Remove existing pipe if present to avoid double-encoding issues
    if "|" in url:
        url = url.split("|")[0]

    params = []

    if referer:
        params.append("Referer={}".format(urllib_parse.quote(referer)))

    # Use current USER_AGENT (updated by FlareSolverr)
    params.append("User-Agent={}".format(urllib_parse.quote(USER_AGENT)))

    domain = urllib_parse.urlparse(url).netloc
    if domain:
        cookies = get_cookies_string(domain)
        if cookies:
            params.append("Cookie={}".format(urllib_parse.quote(cookies)))

    return "{}|{}".format(url, "&".join(params))


def get_sucuri_cookie(html):
    # SECURITY FIX: Disabled unsafe exec()/eval() code execution
    # The previous implementation converted JavaScript to Python and executed it with exec/eval,
    # which is a critical security vulnerability as it executes untrusted code from websites.
    #
    # TODO: Implement safe Sucuri bypass using one of these approaches:
    # 1. Use FlareSolverr (already integrated in this codebase)
    # 2. Use a sandboxed JavaScript runtime (js2py, PyMiniRacer)
    # 3. Parse the cookie generation logic without code execution
    #
    # For now, raise an error to indicate Sucuri protection cannot be bypassed automatically.
    raise NotImplementedError(
        "Sucuri WAF protection detected. "
        "Automatic bypass has been disabled for security reasons. "
        "Please configure FlareSolverr in addon settings to access Sucuri-protected sites."
    )


def postHtml(
    url, form_data=None, headers=None, json_data=None, compression=True, NoCookie=None
):
    """Cached wrapper around :func:`_postHtml` with safe default arguments.

    Using ``None`` as the default prevents callers from accidentally sharing
    mutable dictionaries between invocations which could lead to leaked
    headers, form payloads, or JSON bodies.  The previous implementation used
    ``{}`` which is instantiated only once at function definition time.
    """

    return cache.cacheFunction(
        _postHtml,
        url,
        {} if form_data is None else form_data,
        {} if headers is None else headers,
        {} if json_data is None else json_data,
        compression,
        NoCookie,
    )


def _postHtml(
    url, form_data=None, headers=None, json_data=None, compression=True, NoCookie=None
):
    if form_data is None:
        form_data = {}
    if headers is None:
        headers = {}
    if json_data is None:
        json_data = {}

    if form_data:
        form_data = urllib_parse.urlencode(form_data)
        form_data = form_data if PY2 else six.b(form_data)
        req = urllib_request.Request(url, form_data)
    elif json_data:
        json_data = json.dumps(json_data)
        json_data = json_data.encode("utf8") if PY3 else json_data
        req = urllib_request.Request(url, json_data)
        req.add_header("Content-Type", "application/json")
    else:
        req = urllib_request.Request(url)
        req.get_method = lambda: "POST"
    if "User-Agent" not in headers.keys():
        req.add_header("User-Agent", USER_AGENT)
    for k, v in list(headers.items()):
        req.add_header(k, v)
    if compression:
        req.add_header("Accept-Encoding", "gzip")

    try:
        response = urllib_request.urlopen(req, timeout=HTTP_TIMEOUT_DEFAULT)
    except urllib_error.HTTPError as e:
        if e.info().get("Content-Encoding", "").lower() == "gzip":
            buf = six.BytesIO(e.read())
            f = gzip.GzipFile(fileobj=buf)
            result = f.read()
            f.close()
        else:
            result = e.read()
        result = (
            result.decode("latin-1", errors="ignore") if PY3 else result.encode("utf-8")
        )
        if e.code == 503 and "cf-browser-verification" in result:
            result = cloudflare.solve(url, cj, USER_AGENT)
        elif e.code == 403 and "cf-alert-error" in result:
            # Retry with an explicit modern TLS context for problematic servers.
            ctx = _create_ssl_context()
            handle = [urllib_request.HTTPSHandler(context=ctx)]
            opener = urllib_request.build_opener(*handle)
            try:
                response = opener.open(req, timeout=HTTP_TIMEOUT_DEFAULT)
            except urllib_error.HTTPError as e:
                if e.info().get("Content-Encoding", "").lower() == "gzip":
                    buf = six.BytesIO(e.read())
                    f = gzip.GzipFile(fileobj=buf)
                    result = f.read()
                    f.close()
                else:
                    result = e.read()
                result = (
                    result.decode("latin-1", errors="ignore")
                    if PY3
                    else result.encode("utf-8")
                )
                if e.code == 403 and "cf-alert-error" in result:
                    notify(i18n("oh_oh"), i18n("site_down"))
                    raise
        elif 400 < e.code < 500:
            if not e.code == 403:
                notify(i18n("oh_oh"), i18n("not_exist"))
            raise
        else:
            notify(i18n("oh_oh"), i18n("site_down"))
            raise
    except urllib_error.URLError as e:
        notify(i18n("oh_oh"), i18n("slow_site"))
        xbmc.log(str(e), xbmc.LOGDEBUG)
        raise

    if response.info().get("Content-Encoding", "").lower() == "gzip":
        buf = six.BytesIO(response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        f.close()
    else:
        data = response.read()

    encoding = None

    content_type = response.headers.get("content-type", "")
    if "charset=" in content_type:
        encoding = content_type.split("charset=")[-1]

    if encoding is None:
        epattern = (
            r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"'
        )
        epattern = epattern.encode("utf8") if PY3 else epattern
        r = re.search(epattern, data, re.IGNORECASE)
        if r:
            encoding = r.group(1).decode("utf8") if PY3 else r.group(1)

    if encoding is not None:
        data = data.decode(encoding.lower(), errors="ignore")
        data = data.encode("utf8") if PY2 else data
    else:
        data = data.decode("ascii", errors="ignore") if PY3 else data.encode("utf8")

    if not NoCookie:
        cj.save(cookiePath, ignore_discard=True)

    response.close()
    return data


def checkUrl(url, headers=None):
    if headers is None:
        headers = {}
    if "User-Agent" not in headers.keys():
        headers.update({"User-Agent": USER_AGENT})
    req = Request(url, headers=headers)
    req.get_method = lambda: "HEAD"
    try:
        response = urlopen(req, timeout=HTTP_TIMEOUT_LONG)
        code = response.code
    except urllib_error.HTTPError as e:
        code = e.code
    return code == 200


def getHtml2(url):
    return cache.cacheFunction(_getHtml2, url)


def _getHtml2(url):
    req = Request(url)
    response = urlopen(req, timeout=HTTP_TIMEOUT_LONG)
    data = response.read()
    response.close()
    data = data.decode("latin-1") if PY3 else data
    return data


def getVideoLink(url, referer="", headers=None, data=None):
    if not headers:
        headers = base_hdrs

    if "User-Agent" not in headers:
        headers.update({"User-Agent": base_hdrs.get("User-Agent")})

    req2 = Request(url, data=data, headers=headers)

    if referer:
        req2.add_header("Referer", referer)

    opener = urllib_request.build_opener(NoRedirection())

    try:
        response = opener.open(req2, timeout=HTTP_TIMEOUT_DEFAULT)
    except urllib_error.HTTPError as e:
        response = e

    return response.headers.get("location") or url


def parse_query(query):
    toint = ["page", "download", "favmode", "channel", "section"]
    q = {"mode": "main.INDEX"}
    if query.startswith("?"):
        query = query[1:]
    queries = urllib_parse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try:
                    q[key] = int(queries[key][0])
                except Exception:
                    q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q


def cleantext(text):
    text = text.strip()
    text = re.sub(
        r"\\u([0-9A-Fa-f]{4})", lambda x: six.unichr(int(x.group(1), 16)), text
    )
    try:
        text = text.encode("utf-8", "ignore").decode("utf-8")
    except Exception as e:
        kodilog("Encoding error: " + str(e), xbmc.LOGDEBUG)
    text = six.ensure_str(text)
    if PY3:
        import html

        for _ in range(2):
            unescaped = html.unescape(text)
            if unescaped == text:
                break
            text = unescaped
    else:
        h = html_parser.HTMLParser()
        for _ in range(2):
            unescaped = h.unescape(text.decode("utf8")).encode("utf8")
            if unescaped == text:
                break
            text = unescaped
    text = text.replace("\xa0", " ")
    return text.strip()


def cleanhtml(raw_html):
    cleanr = re.compile("<.*?>")
    cleantext = re.sub(cleanr, "", raw_html)
    return cleantext


def get_vidhost(url):
    """
    Trim the url to get the video hoster
    :return vidhost
    """
    normalized_url = url
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+\.-]*://", url):
        normalized_url = f"//{url.lstrip('/')}"

    parsed_url = urllib_parse.urlparse(normalized_url)
    hostname = parsed_url.hostname
    if not hostname:
        return ""

    parts = hostname.split(".")

    # Handle IPv4 addresses directly
    if len(parts) == 4 and all(part.isdigit() for part in parts):
        return hostname

    if len(parts) >= 3 and len(parts[-1]) == 2 and len(parts[-2]) <= 3:
        # Handle common country code TLDs such as co.uk, com.au, etc.
        return ".".join(parts[-3:])
    if len(parts) >= 2:
        return "{}.{}".format(parts[-2], parts[-1])
    return hostname


def get_language(lang_code):
    languages = {
        "aa": "Afar",
        "ab": "Abkhazian",
        "af": "Afrikaans",
        "am": "Amharic",
        "ar": "Arabic",
        "as": "Assamese",
        "ay": "Aymara",
        "az": "Azerbaijani",
        "ba": "Bashkir",
        "be": "Byelorussian",
        "bg": "Bulgarian",
        "bh": "Bihari",
        "bi": "Bislama",
        "bn": "Bengali",
        "bo": "Tibetan",
        "br": "Breton",
        "ca": "Catalan",
        "co": "Corsican",
        "cs": "Czech",
        "cy": "Welch",
        "da": "Danish",
        "de": "German",
        "dz": "Bhutani",
        "el": "Greek",
        "en": "English",
        "eo": "Esperanto",
        "es": "Spanish",
        "et": "Estonian",
        "eu": "Basque",
        "fa": "Persian",
        "fi": "Finnish",
        "fj": "Fiji",
        "fo": "Faeroese",
        "fr": "French",
        "fy": "Frisian",
        "ga": "Irish",
        "gd": "Scots Gaelic",
        "gl": "Galician",
        "gn": "Guarani",
        "gu": "Gujarati",
        "ha": "Hausa",
        "hi": "Hindi",
        "he": "Hebrew",
        "hr": "Croatian",
        "hu": "Hungarian",
        "hy": "Armenian",
        "ia": "Interlingua",
        "id": "Indonesian",
        "ie": "Interlingue",
        "ik": "Inupiak",
        "in": "former Indonesian",
        "is": "Icelandic",
        "it": "Italian",
        "iu": "Inuktitut (Eskimo)",
        "iw": "former Hebrew",
        "ja": "Japanese",
        "ji": "former Yiddish",
        "jw": "Javanese",
        "ka": "Georgian",
        "kk": "Kazakh",
        "kl": "Greenlandic",
        "km": "Cambodian",
        "kn": "Kannada",
        "ko": "Korean",
        "ks": "Kashmiri",
        "ku": "Kurdish",
        "ky": "Kirghiz",
        "la": "Latin",
        "ln": "Lingala",
        "lo": "Laothian",
        "lt": "Lithuanian",
        "lv": "Latvian,  Lettish",
        "mg": "Malagasy",
        "mi": "Maori",
        "mk": "Macedonian",
        "ml": "Malayalam",
        "mn": "Mongolian",
        "mo": "Moldavian",
        "mr": "Marathi",
        "ms": "Malay",
        "mt": "Maltese",
        "my": "Burmese",
        "na": "Nauru",
        "ne": "Nepali",
        "nl": "Dutch",
        "no": "Norwegian",
        "oc": "Occitan",
        "om": "(Afan) Oromo",
        "or": "Oriya",
        "pa": "Punjabi",
        "pl": "Polish",
        "ps": "Pashto,  Pushto",
        "pt": "Portuguese",
        "qu": "Quechua",
        "rm": "Rhaeto-Romance",
        "rn": "Kirundi",
        "ro": "Romanian",
        "ru": "Russian",
        "rw": "Kinyarwanda",
        "sa": "Sanskrit",
        "sd": "Sindhi",
        "sg": "Sangro",
        "sh": "Serbo-Croatian",
        "si": "Singhalese",
        "sk": "Slovak",
        "sl": "Slovenian",
        "sm": "Samoan",
        "sn": "Shona",
        "so": "Somali",
        "sq": "Albanian",
        "sr": "Serbian",
        "ss": "Siswati",
        "st": "Sesotho",
        "su": "Sudanese",
        "sv": "Swedish",
        "sw": "Swahili",
        "ta": "Tamil",
        "te": "Tegulu",
        "tg": "Tajik",
        "th": "Thai",
        "ti": "Tigrinya",
        "tk": "Turkmen",
        "tl": "Tagalog",
        "tn": "Setswana",
        "to": "Tonga",
        "tr": "Turkish",
        "ts": "Tsonga",
        "tt": "Tatar",
        "tw": "Twi",
        "ug": "Uigur",
        "uk": "Ukrainian",
        "ur": "Urdu",
        "uz": "Uzbek",
        "vi": "Vietnamese",
        "vo": "Volapuk",
        "wo": "Wolof",
        "xh": "Xhosa",
        "yi": "Yiddish",
        "yo": "Yoruba",
        "za": "Zhuang",
        "zh": "Chinese",
        "zu": "Zulu",
    }

    return languages.get(lang_code.lower(), lang_code)


def get_country(country_code):
    countries = {
        "af": "Afghanistan",
        "al": "Albania",
        "dz": "Algeria",
        "as": "American Samoa",
        "ad": "Andorra",
        "ao": "Angola",
        "ai": "Anguilla",
        "ag": "Antigua & Barbuda",
        "ar": "Argentina",
        "am": "Armenia",
        "aw": "Aruba",
        "au": "Australia",
        "at": "Austria",
        "az": "Azerbaijan",
        "bs": "Bahamas",
        "bh": "Bahrain",
        "bd": "Bangladesh",
        "bb": "Barbados",
        "by": "Belarus",
        "be": "Belgium",
        "bz": "Belize",
        "bj": "Benin",
        "bm": "Bermuda",
        "bt": "Bhutan",
        "bo": "Bolivia",
        "ba": "Bosnia & Herzegovina",
        "bw": "Botswana",
        "bv": "Bouvet Island",
        "br": "Brazil",
        "bn": "Brunei Darussalam",
        "bg": "Bulgaria",
        "bf": "Burkina Faso",
        "bi": "Burundi",
        "kh": "Cambodia",
        "cm": "Cameroon",
        "ca": "Canada",
        "cv": "Cape Verde",
        "ky": "Cayman Islands",
        "cf": "Central African Republic",
        "td": "Chad",
        "cl": "Chile",
        "cn": "China",
        "co": "Colombia",
        "km": "Comoros",
        "cg": "Congo",
        "cd": "Congo,  the Democratic Republic of the",
        "ck": "Cook Islands",
        "cr": "Costa Rica",
        "ci": "Cote D'Ivoire",
        "hr": "Croatia",
        "cu": "Cuba",
        "cw": "Curacao",
        "cy": "Cyprus",
        "cz": "Czech Republic",
        "dk": "Denmark",
        "dj": "Djibouti",
        "dm": "Dominica",
        "do": "Dominican Republic",
        "ec": "Ecuador",
        "eg": "Egypt",
        "sv": "El Salvador",
        "gq": "Equatorial Guinea",
        "er": "Eritrea",
        "ee": "Estonia",
        "et": "Ethiopia",
        "fk": "Falkland Islands (Malvinas)",
        "fo": "Faroe Islands",
        "fj": "Fiji",
        "fi": "Finland",
        "fr": "France",
        "gf": "French Guiana",
        "pf": "French Polynesia",
        "ga": "Gabon",
        "gm": "Gambia",
        "ge": "Georgia",
        "de": "Germany",
        "gh": "Ghana",
        "gi": "Gibraltar",
        "gr": "Greece",
        "gl": "Greenland",
        "gd": "Grenada",
        "gp": "Guadeloupe",
        "gu": "Guam",
        "gt": "Guatemala",
        "gn": "Guinea",
        "gw": "Guinea-Bissau",
        "gy": "Guyana",
        "ht": "Haiti",
        "va": "Holy See (Vatican City)",
        "hn": "Honduras",
        "hk": "Hong Kong",
        "hu": "Hungary",
        "is": "Iceland",
        "in": "India",
        "id": "Indonesia",
        "ir": "Iran",
        "iq": "Iraq",
        "ie": "Ireland",
        "il": "Israel",
        "it": "Italy",
        "jm": "Jamaica",
        "jp": "Japan",
        "je": "Jersey",
        "jo": "Jordan",
        "kz": "Kazakhstan",
        "ke": "Kenya",
        "ki": "Kiribati",
        "kp": "Korea,  Democratic People's Republic of",
        "kr": "Korea,  Republic of",
        "kw": "Kuwait",
        "kg": "Kyrgyzstan",
        "la": "Lao",
        "lv": "Latvia",
        "lb": "Lebanon",
        "ls": "Lesotho",
        "lr": "Liberia",
        "ly": "Libyan Arab Jamahiriya",
        "li": "Liechtenstein",
        "lt": "Lithuania",
        "lu": "Luxembourg",
        "mo": "Macao",
        "mk": "Macedonia",
        "mg": "Madagascar",
        "mw": "Malawi",
        "my": "Malaysia",
        "mv": "Maldives",
        "ml": "Mali",
        "mt": "Malta",
        "mh": "Marshall Islands",
        "mq": "Martinique",
        "mr": "Mauritania",
        "mu": "Mauritius",
        "mx": "Mexico",
        "fm": "Micronesia",
        "md": "Moldova",
        "mc": "Monaco",
        "mn": "Mongolia",
        "me": "Montenegro",
        "ms": "Montserrat",
        "ma": "Morocco",
        "mz": "Mozambique",
        "mm": "Myanmar",
        "na": "Namibia",
        "nr": "Nauru",
        "np": "Nepal",
        "nl": "Netherlands",
        "an": "Netherlands Antilles",
        "nc": "New Caledonia",
        "nz": "New Zealand",
        "ni": "Nicaragua",
        "ne": "Niger",
        "ng": "Nigeria",
        "nu": "Niue",
        "nf": "Norfolk Island",
        "mp": "Northern Mariana Islands",
        "no": "Norway",
        "om": "Oman",
        "pk": "Pakistan",
        "pw": "Palau",
        "ps": "Palestine",
        "pa": "Panama",
        "pg": "Papua New Guinea",
        "py": "Paraguay",
        "pe": "Peru",
        "ph": "Philippines",
        "pn": "Pitcairn",
        "pl": "Poland",
        "pt": "Portugal",
        "pr": "Puerto Rico",
        "qa": "Qatar",
        "re": "Reunion",
        "ro": "Romania",
        "ru": "Russian Federation",
        "rw": "Rwanda",
        "bl": "Saint Barths",
        "sh": "Saint Helena",
        "kn": "Saint Kitts and Nevis",
        "lc": "Saint Lucia",
        "pm": "Saint Pierre & Miquelon",
        "vc": "Saint Vincent & the Grenadines",
        "ws": "Samoa",
        "sm": "San Marino",
        "st": "Sao Tome & Principe",
        "sa": "Saudi Arabia",
        "sn": "Senegal",
        "rs": "Serbia",
        "sc": "Seychelles",
        "sl": "Sierra Leone",
        "sg": "Singapore",
        "sk": "Slovakia",
        "si": "Slovenia",
        "sb": "Solomon Islands",
        "so": "Somalia",
        "za": "South Africa",
        "es": "Spain",
        "lk": "Sri Lanka",
        "sd": "Sudan",
        "sr": "Suriname",
        "sj": "Svalbard & Jan Mayen",
        "sz": "Swaziland",
        "se": "Sweden",
        "ch": "Switzerland",
        "sy": "Syrian Arab Republic",
        "tw": "Taiwan",
        "tj": "Tajikistan",
        "tz": "Tanzania",
        "th": "Thailand",
        "tl": "Timor-Leste",
        "tg": "Togo",
        "tk": "Tokelau",
        "to": "Tonga",
        "tt": "Trinidad & Tobago",
        "tn": "Tunisia",
        "tr": "Turkey",
        "tm": "Turkmenistan",
        "tc": "Turks & Caicos",
        "tv": "Tuvalu",
        "ug": "Uganda",
        "ua": "Ukraine",
        "ae": "United Arab Emirates",
        "gb": "United Kingdom",
        "us": "United States",
        "um": "United States Minor Outlying Islands",
        "uy": "Uruguay",
        "uz": "Uzbekistan",
        "vu": "Vanuatu",
        "ve": "Venezuela",
        "vn": "Viet Nam",
        "vg": "Virgin Islands,  British",
        "vi": "Virgin Islands,  U.S.",
        "wf": "Wallis & Futuna",
        "eh": "Western Sahara",
        "ye": "Yemen",
        "zm": "Zambia",
        "zw": "Zimbabwe",
    }

    return countries.get(country_code.lower(), country_code)


def _get_keyboard(default="", heading="", hidden=False):
    """shows a keyboard and returns a value"""
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText().encode("utf8") if PY2 else keyboard.getText()
    return default


def streamdefence(html):
    if "<iframe" not in html:
        decoded = html
        for _ in range(2):
            match = re.findall(r'\("([^"]+)', decoded, re.DOTALL | re.IGNORECASE)[0]
            decoded = base64.b64decode(match.encode("ascii"))
            decoded = base64.b64decode(decoded).decode("ascii")
        match = re.search(r'var\s[^"=]+="([^"]+)', decoded)
        if match:
            decoded = base64.b64decode(match.group(1).encode("ascii")).decode("ascii")
            return decoded
    return html


@url_dispatcher.register()
def setSorted():
    addon.setSetting("keywords_sorted", "true")
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def setUnsorted():
    addon.setSetting("keywords_sorted", "false")
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def oneSearch(url, page, channel):
    vq = _get_keyboard(heading=i18n("srch_for"))
    if not vq:
        return False, 0
    keyword = urllib_parse.quote_plus(vq)
    searchcmd = (
        sys.argv[0]
        + "?url="
        + urllib_parse.quote_plus(url)
        + "&mode="
        + str(channel)
        + "&keyword="
        + keyword
    )
    xbmc.executebuiltin("Container.Update(" + searchcmd + ")")


@url_dispatcher.register()
def newSearch(url=None, channel=None, keyword=None):
    vq = _get_keyboard(default=keyword, heading=i18n("srch_for"))
    if not vq:
        return False, 0
    if not keyword:
        addKeyword(vq)
    elif keyword != vq:
        updateKeyword(keyword, vq)
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def copySearch(url=None, channel=None, keyword=None):
    vq = _get_keyboard(default=keyword, heading=i18n("srch_for"))
    if not vq:
        return False, 0
    if not keyword:
        addKeyword(vq)
    elif keyword != vq:
        addKeyword(vq)
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def clearSearch():
    delallKeyword()
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def alphabeticalSearch(url, channel, keyword=None):
    if keyword:
        searchDir(url, channel, page=None, alphabet=keyword)
    else:
        key_list = keys()
        for c, count in sorted(key_list.items()):
            name = "[COLOR deeppink]{}[/COLOR] [COLOR lightpink]({})[/COLOR]".format(
                c, count
            )
            addDir(
                name,
                url,
                "utils.alphabeticalSearch",
                cum_image("cum-search.png"),
                "",
                channel,
                keyword=c,
            )
        eod()


def addKeyword(keyword):
    if check_if_keyword_exists(keyword):
        notify(i18n("error"), i18n("keyword_exists"))
        return
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO keywords VALUES (?)", (urllib_parse.quote_plus(keyword),))
    conn.commit()
    conn.close()


def updateKeyword(keyword, new_keyword):
    if check_if_keyword_exists(new_keyword):
        notify(i18n("error"), i18n("keyword_exists"))
        return
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute(
        "UPDATE keywords SET keyword=? WHERE keyword=?",
        (urllib_parse.quote_plus(new_keyword), urllib_parse.quote_plus(keyword)),
    )
    conn.commit()
    conn.close()


@url_dispatcher.register()
def delallKeyword():
    yes = dialog.yesno(
        i18n("warning"), "{0}[CR]{1}?".format(i18n("clear_kwds"), i18n("continue"))
    )  # , nolabel='No', yeslabel='Yes')
    if yes:
        conn = sqlite3.connect(favoritesdb)
        c = conn.cursor()
        c.execute("DELETE FROM keywords;")
        conn.commit()
        conn.close()


@url_dispatcher.register()
def delKeyword(keyword):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute(
        "DELETE FROM keywords WHERE keyword = ?", (urllib_parse.quote_plus(keyword),)
    )
    conn.commit()
    conn.close()
    xbmc.executebuiltin("Container.Refresh")


@url_dispatcher.register()
def backup_keywords():
    path = dialog.browseSingle(0, i18n("bkup_dir"), "")
    progress.create(i18n("backing_up"), i18n("init"))
    if not path:
        return
    import datetime

    progress.update(25, i18n("read_db"))
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("SELECT * FROM keywords")
    keywords = [{"keyword": keyword} for (keyword,) in c.fetchall()]
    if not keywords:
        progress.close()
        notify(i18n("words_empty"), i18n("no_words"))
        return
    conn.close()
    time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_content = {
        "meta": {"type": "cumination-keywords", "version": 1, "datetime": time},
        "data": keywords,
    }
    if progress.iscanceled():
        progress.close()
        return
    progress.update(75, i18n("write_bkup"))
    filename = "cumination-keywords_" + time + ".bak"
    filepath = os.path.join(path, filename)
    compressbackup = addon.getSetting("compressbackup") == "true"
    if compressbackup:
        try:
            if PY3:
                with gzip.open(filepath, "wt", encoding="utf-8") as fav_file:
                    json.dump(backup_content, fav_file)
            else:
                with gzip.open(filepath, "wb") as fav_file:
                    json.dump(backup_content, fav_file)
        except IOError:
            progress.close()
            notify(i18n("invalid_path"), i18n("write_permission"))
            return
    else:
        try:
            if PY3:
                with open(filepath, "wt", encoding="utf-8") as fav_file:
                    json.dump(backup_content, fav_file)
            else:
                with open(filepath, "wb") as fav_file:
                    json.dump(backup_content, fav_file)
        except IOError:
            progress.close()
            notify(i18n("invalid_path"), i18n("write_permission"))
            return
    progress.close()
    dialog.ok(
        i18n("bkup_complete"), "{0} {1}".format(i18n("bkup_file"), filepath)
    )


def check_if_keyword_exists(keyword):
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute(
        "SELECT * FROM keywords WHERE keyword = ?", (urllib_parse.quote_plus(keyword),)
    )
    row = c.fetchone()
    conn.close()
    if row:
        return True
    return False


@url_dispatcher.register()
def restore_keywords():
    path = dialog.browseSingle(1, i18n("slct_file"), "")
    if not path:
        return

    compressbackup = addon.getSetting("compressbackup") == "true"
    if compressbackup:
        try:
            if PY3:
                with gzip.open(path, "rt", encoding="utf-8") as fav_file:
                    backup_content = json.load(fav_file)
            else:
                with gzip.open(path, "rb") as fav_file:
                    backup_content = json.load(fav_file)

        except (ValueError, IOError):
            notify(i18n("error"), i18n("invalid_bkup"))
            return
        if backup_content["meta"]["type"] not in (
            "cumination-keywords",
            "uwc-keywords",
        ):
            notify(i18n("error"), i18n("invalid_bkup"))
            return
    else:
        try:
            if PY3:
                with open(path, "rt", encoding="utf-8") as fav_file:
                    backup_content = json.load(fav_file)
            else:
                with open(path, "rb") as fav_file:
                    backup_content = json.load(fav_file)

        except (ValueError, IOError):
            notify(i18n("error"), i18n("invalid_bkup"))
            return
        if backup_content["meta"]["type"] not in (
            "cumination-keywords",
            "uwc-keywords",
        ):
            notify(i18n("error"), i18n("invalid_bkup"))
            return
    keywords = backup_content["data"]
    if not keywords:
        notify(i18n("error"), i18n("empty_bkup"))
    added = 0
    skipped = 0
    for keyword in keywords:
        keyw = keyword["keyword"]
        if check_if_keyword_exists(keyw):
            skipped += 1
        else:
            addKeyword(keyw)
            added += 1
    xbmc.executebuiltin("Container.Refresh")
    dialog.ok(
        i18n("rstr_cmpl"),
        "{0}[CR]{1}: {2}[CR]{3}: {4}".format(
            i18n("rstr_msg"), i18n("added"), added, i18n("skipped"), skipped
        ),
    )


@url_dispatcher.register()
def openSettings():
    addon.openSettings()


def textBox(heading, announce):
    class TextBox:
        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW,))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()

        def setControls(self):
            try:
                self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
                self.win.getControl(self.CONTROL_TEXTBOX).setText(str(announce))
            except RuntimeError:
                xbmc.executebuiltin("Dialog.Close(%d)" % self.WINDOW)
            return

    TextBox()
    while xbmc.getCondVisibility("Window.IsVisible(10147)"):
        xbmc.sleep(500)


def selector(
    dialog_name,
    select_from,
    setting_valid=False,
    sort_by=None,
    reverse=False,
    show_on_one=False,
):
    """
    Shows a dialog where the user can choose from the values provided
    Returns the value of the selected key, or None if no selection was made

    Usage:
        dialog_name = title of the dialog shown
        select_from = a list or a dictionary which contains the options

        optional arguments
        setting_valid (False) = sets if the passed addon setting id should be considered
                         if the addon setting is enabled, the dialog won't be shown and the first element
                         will be selected automatically
        sort_by (None) = in case of dictionaries the keys will be sorted according this value
                  in case of a list, the list will be ordered
        reverse (False) = sets if order should be reversed
    """
    if isinstance(select_from, dict):
        keys = sorted(list(select_from.keys()), key=sort_by, reverse=reverse)
        values = [select_from[x] for x in keys]
    else:
        keys = sorted(select_from, key=sort_by, reverse=reverse)
        values = None
    if not keys:
        return None
    if (setting_valid and int(addon.getSetting(setting_valid)) != 4) or (
        len(keys) == 1 and not show_on_one
    ):
        selected = 0
    else:
        selected = dialog.select(dialog_name, keys)
    if selected == -1:
        return None
    return values[selected] if values else keys[selected]


def prefquality(video_list, sort_by=None, reverse=False):
    maxquality = int(addon.getSetting("qualityask"))
    if maxquality == 4:
        return selector(i18n("pick_qual"), video_list, sort_by=sort_by, reverse=reverse)

    vidurl = None
    if isinstance(video_list, dict):
        qualities = [2160, 1080, 720, 576]
        quality = qualities[maxquality]
        for key in video_list.copy():
            if key.lower().endswith("p60"):
                video_list[key.replace("p60", "")] = video_list[key]
                video_list.pop(key)
            else:
                if key.lower() == "4k":
                    video_list["2160"] = video_list[key]
                    video_list.pop(key)

        parsed_video_list = []
        for key, value in list(video_list.items()):
            digits = "".join([y for y in key if y.isdigit()])
            parsed_video_list.append((int(digits) if digits else -1, value))
        
        parsed_video_list = sorted(parsed_video_list, reverse=True)

        for video in parsed_video_list:
            if quality >= video[0]:
                vidurl = video[1]
                break
            else:
                if str(quality) in str(video[0]):
                    vidurl = video[1]
                    break
        if not vidurl and parsed_video_list:
            vidurl = parsed_video_list[-1][1]
    else:
        keys = sorted(video_list, key=sort_by, reverse=reverse)
        if not keys:
            return None
        vidurl = keys[0]

    return vidurl


class VideoPlayer:
    def __init__(
        self,
        name,
        download=False,
        regex=r"""(?:src|SRC|href|HREF)=\s*["']([^'"]+)""",
        direct_regex=r"""(?:<source|<video).*?src=(?:"|')([^"']+)[^>]*>""",
        IA_check="check",
    ):
        self.regex = regex
        self.direct_regex = direct_regex
        self.name = name
        self.download = download
        self.progress = progress
        self.progress.create(i18n("plyng_vid"), "[CR]{0}[CR]".format(i18n("srch_vid")))
        self.bypass_string = addon.getSetting("filter_hosters") or None
        self.IA_check = IA_check

        import resolveurl

        self.resolveurl = resolveurl
        xxx_plugins_path = (
            "special://home/addons/script.module.resolveurl.xxx/resources/plugins/"
        )
        if xbmcvfs.exists(xxx_plugins_path):
            self.resolveurl.add_plugin_dirs(TRANSLATEPATH(xxx_plugins_path))

    def _cancellable(f):
        @wraps(f)
        def wrapped(inst, *args, **kwargs):
            if inst.progress.iscanceled():
                inst.progress.close()
                return
            return f(inst, *args, **kwargs)

        return wrapped

    @_cancellable
    def _clean_urls(self, url_list):
        filtered_words = ["google"]
        filtered_ends = [".js", ".css", "/premium.html", ".jpg", ".gif", ".png", ".ico"]
        added = set()
        new_list = []
        for source in url_list:
            to_break = False
            if source._url in added or not source:
                continue
            for word in filtered_words:
                if word in source._url or to_break:
                    to_break = True
                    break
            for end in filtered_ends:
                if source._url.endswith(end) or to_break:
                    to_break = True
                    break
            else:
                source.title = source._domain.split(".")[0]
                added.add(source._url)
                new_list.append(source)
        return new_list

    def bypass_hosters(self, video_list):
        if not self.bypass_string:
            return video_list

        bypass_list = self.bypass_string.split(";")
        original_videos = video_list.copy()
        video_list = [
            video
            for video in video_list
            if not any(hoster.lower() in video.lower() for hoster in bypass_list)
        ]

        if not video_list:
            video_list = original_videos

        return video_list

    def bypass_hosters_single(self, videourl):
        if not self.bypass_string:
            return False

        bypass_list = self.bypass_string.split(";")
        if any(x.lower() in videourl.lower() for x in bypass_list):
            return True
        return False

    def play_from_site_link(self, url, referrer=""):
        self.progress.update(25, "[CR]{0}[CR]".format(i18n("load_vpage")))
        html = getHtml(url, referrer)
        self.play_from_html(html, url)

    @_cancellable
    def play_from_html(self, html, url=None):
        if not html:
            self.progress.close()
            notify(i18n("oh_oh"), i18n("not_found"))
            return
        self.progress.update(40, "[CR]{0}[CR]".format(i18n("srch_host")))
        solved_suburls = self._check_suburls(html, url)
        self.progress.update(60, "[CR]{0}[CR]".format(i18n("srch_host")))
        direct_links = None
        if self.direct_regex:
            direct_links = re.compile(
                self.direct_regex, re.DOTALL | re.IGNORECASE
            ).findall(html)
            if direct_links:
                selected = (
                    urllib_parse.urljoin(url, direct_links[0])
                    if direct_links[0].startswith("/")
                    else direct_links[0]
                )
                self.progress.update(50, "[CR]{0}[CR]".format(i18n("play_dlink")))
                self.play_from_direct_link(selected)
            elif not self.regex:
                notify(i18n("oh_oh"), i18n("not_found"))
        if self.regex and not direct_links:
            scraped_sources = self.resolveurl.scrape_supported(html, self.regex)
            scraped_sources = scraped_sources if scraped_sources else []
            scraped_sources.extend(solved_suburls)
            self.play_from_link_list(scraped_sources)
        if not self.direct_regex and not self.regex:
            raise ValueError(i18n("no_regex"))

    @_cancellable
    def play_from_kt_player(self, html, url=None, follow_redirects=False):
        license = re.search(r"license_code:\s*'(\$\d+)", html, re.DOTALL | re.IGNORECASE)
        if license:
            license = license.group(1)

        match = re.compile(r"video(?:_|_alt_)url\d?:\s*'([^']+)[^;]+?video(?:_|_alt_)url\d?_text:\s*'([^']+)", re.DOTALL | re.IGNORECASE).findall(html)
        if not match:
            match = re.compile(r"video(?:_|_alt_)url\d?: '([^']+)'.+?postfix\s*:\s*'([^']+)'", re.DOTALL | re.IGNORECASE).findall(html)

        sources = {qual: videourl for videourl, qual in match}

        # Filter out qualities that require login if others are available
        available_sources = {k: v for k, v in sources.items() if "?login" not in v}
        if available_sources:
            sources = available_sources

        if len(sources.keys()) == 1:
            videourl = list(sources.values())[0]
        else:
            try:
                videourl = prefquality(sources, sort_by=lambda x: 2160 if x == '4k' else int(x.split('p')[0]), reverse=True)
            except Exception:
                videourl = selector('Select quality', sources, reverse=True)

        if not videourl:
            self.progress.close()
            return
        if '?login' in videourl:
            self.progress.close()
            notify(i18n('oh_oh'), i18n('Login required for this quality.'))
            return
        if videourl.startswith('function/0/'):
            if not license:
                self.progress.close()
                notify(i18n('oh_oh'), 'Unable to play video: License code not found')
                return
            from resources.lib.decrypters.kvsplayer import kvs_decode
            videourl = kvs_decode(videourl, license)

        if follow_redirects:
            videourl = getVideoLink(videourl, url)

        videourl += '|User-Agent={0}'.format(USER_AGENT)
        if url:
            videourl += '&Referer={0}'.format(url)

        if not videourl:
            self.progress.close()
            return
        self.play_from_direct_link(videourl)

    @_cancellable
    def play_from_link_list(self, links):
        use_universal = addon.getSetting("universal_resolvers") == "true"
        links = self.bypass_hosters(links)
        sources = self._clean_urls(
            [
                self.resolveurl.HostedMediaFile(
                    x, title=x.split("/")[2], include_universal=use_universal
                )
                for x in links
            ]
        )
        if not sources:
            notify(i18n("oh_oh"), i18n("not_found"))
            return
        self._select_source(sources)

    @_cancellable
    def _select_source(self, sources):
        if not len(sources) > 1 or addon.getSetting("dontask") == "true":
            source = sources[0]
        else:
            source = self.resolveurl.choose_source(sources)
        if source:
            self.play_from_link_to_resolve(source)

    @_cancellable
    def play_from_link_to_resolve(self, source):
        if isinstance(source, six.string_types):
            self.play_from_link_list([source])
            return
        self.progress.update(
            80,
            "[CR]{0}[CR]{1} {2}".format(
                i18n("to_smr"), i18n("play_from"), source.title
            ),
        )
        try:
            # Check if this is a DoodStream mirror that might need FlareSolverr support
            if any(domain in source._url.lower() for domain in DOODSTREAM_DOMAINS):
                kodilog("Using custom DoodStream resolver for: {}".format(source._url))
                link = self._solve_doodstream(source._url)
            else:
                link = source.resolve()
        except self.resolveurl.resolver.ResolverError:
            link = False  # ResolveURL returns False in some cases when resolving fails
        if not link:
            notify(i18n("rslv_fail"), "{0} {1}".format(source.title, i18n("not_rslv")))
        else:
            playvid(link, self.name, self.download, IA_check=self.IA_check)

    @_cancellable
    def play_from_direct_link(self, direct_link):
        self.progress.update(90, "[CR]{0}[CR]".format(i18n("play_dlink")))
        playvid(direct_link, self.name, self.download, IA_check=self.IA_check)

    @_cancellable
    def _check_suburls(self, html, referrer_url):
        if not html:
            return []
        sdurl = re.compile(
            r"""streamdefence\.com/view.php\?ref=([^"']+)""", re.DOTALL | re.IGNORECASE
        ).findall(html)
        sdurl_world = re.compile(
            r""".strdef\.world/([^"']+)""", re.DOTALL | re.IGNORECASE
        ).findall(html)
        fcurl = re.compile(
            r"filecrypt\.cc/Container/([^\.]+)\.html", re.DOTALL | re.IGNORECASE
        ).findall(html)
        shortixurl = re.compile(
            r"1155xmv\.com/\?u=(\w+)", re.DOTALL | re.IGNORECASE
        ).findall(html)
        klurl = re.compile(
            r"(https://www.keeplinks.org/[^/]+/[0-9a-fA-f]+)", re.DOTALL | re.IGNORECASE
        ).findall(html)
        hornyhill = re.compile(
            r"(https?://hornyhill\.com/player/jwplayer/index\.php/\d+)", re.DOTALL | re.IGNORECASE
        ).findall(html)
        links = []
        if sdurl or sdurl_world or fcurl or shortixurl or klurl or hornyhill:
            self.progress.update(50, "[CR]{0}[CR]".format(i18n("fnd_sbsite")))
        if sdurl:
            links.extend(self._solve_streamdefence(sdurl, referrer_url, False))
        elif sdurl_world:
            links.extend(self._solve_streamdefence(sdurl_world, referrer_url, True))
        elif fcurl:
            links.extend(self._solve_filecrypt(fcurl, referrer_url))
        elif shortixurl:
            links.extend(self._solve_shortix(shortixurl, referrer_url))
        elif klurl:
            links.extend(self._solve_keeplinks(klurl, referrer_url))
        elif hornyhill:
            links.extend(self._solve_hornyhill(hornyhill, referrer_url))
        return links

    @_cancellable
    def _solve_streamdefence(self, sdurls, url, world=False):
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_strdfn")))
        sdpages = ""
        for sd_url in sdurls:
            if not world:
                sdurl = "http://www.streamdefence.com/view.php?ref=" + sd_url
            else:
                sdurl = "https://www.strdef.world/" + sd_url
            sdsrc = getHtml(sdurl, url if url else sdurl)
            sdpage = streamdefence(sdsrc)
            sdpages += sdpage
        sources = set(
            re.compile(r'<iframe.+?src="([^"]+)', re.DOTALL | re.IGNORECASE).findall(
                sdpages
            )
        )
        return sources

    @_cancellable
    def _solve_filecrypt(self, fc_urls, url):
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_fcrypt")))
        sites = set()
        for fc_url in fc_urls:
            fcurl = "http://filecrypt.cc/Container/" + fc_url + ".html"
            fcsrc = getHtml(fcurl, url if url else fcurl, base_hdrs)
            fcmatch = re.compile(
                r"openLink.?'([\w\-]*)',", re.DOTALL | re.IGNORECASE
            ).findall(fcsrc)
            for fclink in fcmatch:
                fcpage = "http://filecrypt.cc/Link/" + fclink + ".html"
                fcpagesrc = getHtml(fcpage, fcurl)
                fclink2 = re.search("""top.location.href='([^']+)""", fcpagesrc)
                if fclink2:
                    try:
                        fcurl2 = getVideoLink(fclink2.group(1), fcpage)
                        sites.add(fcurl2)
                    except Exception:
                        pass
        return sites

    @_cancellable
    def _solve_shortix(self, shortixurls, url):
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_shortix")))
        sources = set()
        for shortix in shortixurls:
            shortixurl = "https://1155xmv.com/?u=" + shortix
            shortixsrc = getHtml(shortixurl, url if url else shortixurl)
            sources.add(
                re.compile('src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(
                    shortixsrc
                )[0]
            )
        return sources

    @_cancellable
    def _solve_keeplinks(self, klurls, url):
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_kl")))
        sources = []
        klurls = set(klurls)
        for klurl in klurls:
            headers = {"Cookie": "flag[{0}]=1".format(klurl.split("/")[-1])}
            klsrc = getHtml(klurl, klurl, headers=headers)
            srcs = re.compile(
                'class="numlive.+?href="([^"\r]+)', re.DOTALL | re.IGNORECASE
            ).findall(klsrc)
            sources.extend(srcs)
        return sources

    @_cancellable
    def _solve_hornyhill(self, urls, referrer_url):
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_vpage")))
        sources = []
        for url in urls:
            try:
                html = getHtml(url, referrer_url or url)
                m3u8_urls = re.findall(r"https?://[^\"'\s<>]+\.m3u8[^\"'\s<>]*", html)
                mp4_urls = re.findall(r"https?://[^\"'\s<>]+\.mp4[^\"'\s<>]*", html)
                for stream_url in m3u8_urls + mp4_urls:
                    if stream_url not in sources:
                        sources.append(stream_url)
                # Extract the source video page URL from the JWPlayer error handler
                # e.g. console.log('Retrying to scrape playing links from source:https://...')
                source_pages = re.findall(
                    r"scrape playing links from source:(https?://[^'\"\s]+)", html
                )
                for source_page in source_pages:
                    try:
                        source_html, _ = get_html_with_cloudflare_retry(source_page, url)
                        page_sources = re.findall(
                            r"<source[^>]+src=[\"'](https?://[^\"']+)[\"']", source_html
                        )
                        page_mp4 = re.findall(
                            r"https?://[^\"'\s<>]+\.mp4[^\"'\s<>]*", source_html
                        )
                        page_m3u8 = re.findall(
                            r"https?://[^\"'\s<>]+\.m3u8[^\"'\s<>]*", source_html
                        )
                        for stream_url in page_sources + page_mp4 + page_m3u8:
                            if stream_url not in sources:
                                sources.append(stream_url)
                    except Exception:
                        pass
            except Exception:
                pass
        return sources

    @_cancellable
    def _solve_doodstream(self, url):
        """Custom DoodStream resolver with FlareSolverr support via getHtml."""
        self.progress.update(55, "[CR]{0}[CR]".format(i18n("load_vpage")))
        
        # Ensure we have a /e/ URL for embedding
        url = url.replace("/d/", "/e/")
            
        html = getHtml(url)
        if not html:
            return None
            
        # Check for packed scripts and unpack them
        packed_match = re.compile(
            r"(eval\s*\(function\(p,a,c,k,e,d\).+?)(?:\s*<\/script>|$)", 
            re.DOTALL | re.IGNORECASE
        ).findall(html)
        
        unpacked_html = html
        if packed_match:
            for packed in packed_match:
                try:
                    unpacked_html += "\n" + jsunpack.unpack(packed)
                except Exception:
                    pass

        # Try to find direct jwplayer file first (especially for nowplay.to)
        jw_match = re.search(
            r"""file\s*:\s*["']([^'"]+\.(?:m3u8|mp4)[^'"]*)""",
            unpacked_html,
            re.DOTALL | re.IGNORECASE,
        )
        if jw_match:
            final_url = jw_match.group(1)
            if final_url.startswith("//"):
                final_url = "https:" + final_url
            elif final_url.startswith("/"):
                final_url = urllib_parse.urljoin(url, final_url)
            
            domain = urllib_parse.urlparse(url).netloc
            cookies = get_cookies_string(domain)
            cookie_str = "&Cookie={}".format(urllib_parse.quote(cookies)) if cookies else ""
            return "{}|Referer={}&User-Agent={}{}".format(final_url, urllib_parse.quote(url), urllib_parse.quote(USER_AGENT), cookie_str)

        # Extract token and pass_url_chunk
        match = re.search(
            r"""dsplayer\.hotkeys\s*\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]+)['"]""",
            unpacked_html,
            re.DOTALL | re.IGNORECASE,
        )
        if not match:
            # Fallback for older patterns
            match = re.search(
                r"""dsplayer\.hotkeys[^'"]+['"]([^'"]+).+?function\s*makePlay.+?return[^?]+([^'"]+)""",
                unpacked_html,
                re.DOTALL,
            )
            if not match:
                return None
            
        pass_url_chunk = match.group(1)
        token = match.group(2)
        
        # Construct the second URL
        parsed = urllib_parse.urlparse(url)
        base_url = "{}://{}".format(parsed.scheme, parsed.netloc)
        pass_url = urllib_parse.urljoin(base_url, pass_url_chunk)
        
        # Fetch the second part
        pass_html = getHtml(pass_url, url)
        if not pass_html:
            return None
            
        # Decode and construct final link
        # DoodStream uses a simple append of random characters
        t = string.ascii_letters + string.digits
        final_url = pass_html + "".join([random.choice(t) for _ in range(10)]) + token + str(int(time.time() * 1000))
            
        # Add headers for Kodi player
        # Use current user agent as FlareSolverr might have updated it
        domain = urllib_parse.urlparse(url).netloc
        cookies = get_cookies_string(domain)
        cookie_str = "&Cookie={}".format(urllib_parse.quote(cookies)) if cookies else ""
        
        return "{}|Referer={}&User-Agent={}{}".format(final_url, urllib_parse.quote(url), urllib_parse.quote(USER_AGENT), cookie_str)


def showimage(url):
    xbmc.executebuiltin("ShowPicture({0})".format(url))


def playvideo(
    videosource,
    name,
    download=None,
    url=None,
    regex=r"""(?:src|SRC|href|HREF)=\s*["']([^'"]+)""",
):
    """Deprecated function, use VideoPlayer class.
    Exists for compatiblity with old site plug-ins."""
    vp = VideoPlayer(name, download, regex)
    vp.play_from_html(videosource)


def PLAYVIDEO(
    url, name, download=None, regex=r"""(?:src|SRC|href|HREF)=\s*["']([^'"]+)"""
):
    """Deprecated function, use VideoPlayer class.
    Exists for compatiblity with old site plug-ins."""
    vp = VideoPlayer(name, download, regex)
    vp.play_from_site_link(url, url)


def next_page(
    site,
    list_mode,
    html,
    re_npurl,
    re_npnr=None,
    re_lpnr=None,
    videos_per_page=None,
    contextm=None,
    baseurl=None,
):
    match = re.compile(re_npurl, re.DOTALL | re.IGNORECASE).findall(html)
    if match:
        npurl = fix_url(match[0], site.url, baseurl).replace("&amp;", "&")
        np = ""
        npnr = 0
        if re_npnr:
            match = re.compile(re_npnr, re.DOTALL | re.IGNORECASE).findall(html)
            if match:
                npnr = match[0].replace(",", "")
                np = npnr
        lp = ""
        lpnr = 0
        if re_lpnr:
            match = re.compile(re_lpnr, re.DOTALL | re.IGNORECASE).findall(html)
            lpnr = match[0].replace(",", "") if match else "0"
            if videos_per_page:
                lpnr = int(ceil(int(lpnr) / int(videos_per_page)))
            lp = "/" + str(lpnr) if match else ""
        if np:
            np = "(" + np
            lp = lp + ")"

        cm = None
        if contextm:
            cm_page = (
                addon_sys
                + "?mode="
                + str(contextm)
                + "&list_mode="
                + list_mode
                + "&url="
                + urllib_parse.quote_plus(npurl)
                + "&np="
                + str(npnr)
                + "&lp="
                + str(lpnr)
            )
            cm = [("[COLOR violet]Goto Page #[/COLOR]", "RunPlugin(" + cm_page + ")")]
        site.add_dir("Next Page {}{}".format(np, lp), npurl, list_mode, contextm=cm)


def fix_url(url, siteurl=None, baseurl=None):
    if siteurl:
        baseurl = baseurl if baseurl else siteurl[:-1]
        if url.startswith("//"):
            url = siteurl.split(":")[0] + ":" + url
        elif url.startswith("?"):
            url = baseurl + url
        elif url.startswith("/"):
            url = siteurl[:-1] + url
        elif "/" not in url:
            url = baseurl + url
        elif not url.startswith("http"):
            url = siteurl + url
    return url


def videos_list(
    site,
    playvid,
    html,
    delimiter,
    re_videopage,
    re_name=None,
    re_img=None,
    re_quality=None,
    re_duration=None,
    contextm=None,
    skip=None,
    thumbnails=None,
):
    """Legacy regex driven listing helper.

    .. deprecated:: 1.1.167
       New migrations should prefer :func:`soup_videos_list`, which offers
       resilient BeautifulSoup parsing while keeping pagination metadata in a
       consistent format.
    """
    if thumbnails:
        th = Thumbnails(site.name)

    videolist = re.split(delimiter, html)
    if videolist:
        videolist.pop(0)
        for video in videolist:
            if skip and skip in video:
                continue
            match = re.search(re_videopage, video, flags=re.DOTALL | re.IGNORECASE)
            if match:
                videopage = fix_url(match.group(1), site.url)
            else:
                continue
            name = ""
            if re_name:
                match = re.search(re_name, video, flags=re.DOTALL | re.IGNORECASE)
                if match:
                    name = cleantext(match.group(1))
            img = ""
            if re_img:
                match = re.search(re_img, video, flags=re.DOTALL | re.IGNORECASE)
                if match:
                    img = fix_url(match.group(1).replace("&amp;", "&"), site.url)
                    if thumbnails:
                        img = th.cache_img(img) if thumbnails == "cache" else th.fix_img(img)
            quality = ""
            if re_quality:
                match = re.search(re_quality, video, flags=re.DOTALL | re.IGNORECASE)
                if match:
                    quality = match.group(1) if match.groups() else match.group(0)
            duration = ""
            if re_duration:
                match = re.search(re_duration, video, flags=re.DOTALL | re.IGNORECASE)
                if match:
                    duration = match.group(1)
            cm = ""
            if contextm:
                if isinstance(contextm, six.string_types):
                    cm_related = (
                        addon_sys
                        + "?mode="
                        + str(contextm)
                        + "&url="
                        + urllib_parse.quote_plus(videopage)
                    )
                    cm = [
                        (
                            "[COLOR violet]Related videos[/COLOR]",
                            "RunPlugin(" + cm_related + ")",
                        )
                    ]
                else:
                    cm = [
                        (
                            x[0],
                            x[1].replace(
                                "&url=", "&url=" + urllib_parse.quote_plus(videopage)
                            ),
                        )
                        for x in contextm
                    ]
            site.add_download_link(
                name,
                videopage,
                playvid,
                img,
                name,
                quality=quality,
                duration=duration,
                contextm=cm,
            )


def _bencode(text):
    return six.ensure_str(base64.b64encode(six.ensure_binary(text)))


def _bdecode(text, binary=False):
    r = base64.b64decode(text)
    return r if binary else six.ensure_str(r)


def get_packed_data(html):
    packed_data = ""
    for match in re.finditer(
        r"""(eval\s*\(function\(p,a,c,k,e,.*?)</script>""", html, re.DOTALL | re.I
    ):
        r = match.group(1)
        t = re.findall(r"(eval\s*\(function\(p,a,c,k,e,)", r, re.DOTALL | re.IGNORECASE)
        if len(t) == 1:
            if jsunpack.detect(r):
                packed_data += jsunpack.unpack(r)
        else:
            t = r.split("eval")
            t = ["eval" + x for x in t if x]
            for r in t:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
    return packed_data


class LookupInfo:
    def __init__(
        self, siteurl, url, default_mode, lookup_list, starthtml=None, stophtml=None
    ):
        self.siteurl = siteurl
        self.url = url
        self.default_mode = default_mode
        self.lookup_list = lookup_list
        self.starthtml = starthtml
        self.stophtml = stophtml

    def url_constructor(self, url):
        # Default url_constructor - can be overridden in derived classes
        return "http:" + url if url.startswith("//") else self.siteurl + url

    def getinfo(self, headers=None):
        if headers is None:
            headers = base_hdrs
        try:
            listhtml = getHtml(self.url, headers=headers)
            if self.starthtml:
                listhtml = listhtml.split(self.starthtml)[-1]
            if self.stophtml:
                listhtml = listhtml.split(self.stophtml)[0]
        except Exception:
            return None

        infodict = {}

        item_names = [item_name for item_name, _, _ in self.lookup_list]

        for item_name, pattern, mode in self.lookup_list:
            if isinstance(pattern, list):
                match = re.compile(pattern[0], re.DOTALL | re.IGNORECASE).findall(
                    listhtml
                )
                if match:
                    matchhtml = match[0]
                    pattern = pattern[1]
                    matches = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(
                        matchhtml
                    )
            else:
                matches = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(
                    listhtml
                )

            if matches:
                for url, name in matches:
                    name = "{} - {}".format(item_name, name.strip())
                    if not mode:
                        mode = self.default_mode
                    infodict[name] = (self.url_constructor(url), mode)

        if infodict:
            selected_item = selector("Choose item", infodict, show_on_one=True)
            if not selected_item:
                return
            contexturl = (
                addon_sys
                + "?mode="
                + selected_item[1]
                + "&url="
                + urllib_parse.quote_plus(selected_item[0])
            )
            xbmc.executebuiltin("Container.Update(" + contexturl + ")")
        else:
            if len(item_names) > 1:
                item_names_str = ", ".join(item_names[:-1]) + " or " + item_names[-1]
            else:
                item_names_str = item_names[0]
            notify("Notify", "No {} found for this video".format(item_names_str))
        return


class logger:
    log_message_prefix = "[{} ({})]: ".format(
        addon.getAddonInfo("name"), addon.getAddonInfo("version")
    )

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        message = logger.log_message_prefix + str(message)
        xbmc.log(message, level)

    @staticmethod
    def info(message):
        logger.log(message, xbmc.LOGINFO if PY3 else xbmc.LOGNOTICE)

    @staticmethod
    def error(message):
        logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def debug(*messages):
        for message in messages:
            logger.log(message, xbmc.LOGDEBUG)

    @staticmethod
    def warning(message):
        logger.log(message, xbmc.LOGWARNING)


@url_dispatcher.register()
def ToggleDebug():
    result = toggle_debug()
    return result


class Thumbnails:
    # Download thumbnails to local cache and correct the extensions of WEBP images that were renamed to JPG, which cannot be displayed in KODI 21
    def __init__(self, site):
        self.path = os.path.join(profileDir, "thumbnails", site)
        if not os.path.exists(self.path):
            os.makedirs(self.path)
        self.cache_time = 480
        self.clean()

    def clean(self):
        current_time = time.time()
        for filename in os.listdir(self.path):
            file_path = os.path.join(self.path, filename)
            file_modified = os.path.getmtime(file_path)
            if current_time - file_modified > self.cache_time * 60:
                os.remove(file_path)

    def download_image(self, img, img_path):
        try:
            response = urlopen(Request(img, headers=base_hdrs))
            try:
                with open(img_path, "wb") as f:
                    f.write(response.read())
            except IOError as e:
                kodilog("Failed to write image to {}: {}".format(img_path, e))
        except urllib_error.URLError as e:
            kodilog("Failed to download image {}: {}".format(img, e))

    def fix_img(self, img):
        if KODIVER < 21:
            return img
        thumbnail = urllib_parse.quote(urllib_parse.urlparse(img).path, safe="")
        img_path = os.path.join(self.path, thumbnail).replace(".jpg", ".webp")
        if os.path.exists(img_path):
            return img_path
        Thread(target=self.download_image, args=(img, img_path), daemon=True).start()
        return img_path

    def cache_img(self, img):
        thumbnail = urllib_parse.quote(urllib_parse.urlparse(img).path, safe="")
        img_path = os.path.join(self.path, thumbnail)
        if os.path.exists(img_path):
            return img_path
        Thread(target=self.download_image, args=(img, img_path), daemon=True).start()
        return img_path


def resolve_nhplayer(embed_url, referer_url):
    import hashlib
    import base64
    import json
    import re
    from six.moves import urllib_parse

    # Fetch embed page
    embed_html = getHtml(embed_url, referer_url)
    if not embed_html:
        kodilog("resolve_nhplayer: failed to fetch embed page")
        return None

    soup = parse_html(embed_html)
    if not soup:
        kodilog("resolve_nhplayer: failed to parse embed page HTML")
        return None

    li = soup.select_one(".servers ul li[data-id]")
    if not li:
        li = soup.select_one("[data-id*='player.php']")

    if not li:
        kodilog("resolve_nhplayer: player.php data-id not found")
        return None

    player_path = li["data-id"]
    if player_path.startswith("/"):
        player_url = "https://nhplayer.com" + player_path
    elif not player_path.startswith("http"):
        player_url = "https://nhplayer.com/" + player_path
    else:
        player_url = player_path

    # Fetch player page
    player_html = getHtml(player_url, embed_url)
    if not player_html:
        kodilog("resolve_nhplayer: failed to fetch player page")
        return None

    soup_player = parse_html(player_html)
    if not soup_player:
        kodilog("resolve_nhplayer: failed to parse player page HTML")
        return None

    pV_match = re.search(r'window\._pV\s*=\s*(\{.*?\});', player_html)
    if not pV_match:
        kodilog("resolve_nhplayer: window._pV block not found")
        return None

    try:
        vid = re.search(r'vid\s*:\s*["\']([^"\']+)["\']', pV_match.group(1)).group(1)
        ct = re.search(r'ct\s*:\s*["\']([^"\']+)["\']', pV_match.group(1)).group(1)
        pid = re.search(r'pid\s*:\s*["\']([^"\']+)["\']', pV_match.group(1)).group(1)
        st = re.search(r'st\s*:\s*["\']([^"\']+)["\']', pV_match.group(1)).group(1)
    except Exception as e:
        kodilog("resolve_nhplayer: failed to parse window._pV values: {}".format(e))
        return None

    js_script = soup_player.select_one("script[src*='player-core-v2.php']")
    if not js_script:
        kodilog("resolve_nhplayer: player-core-v2.php script tag not found")
        return None

    js_url = js_script["src"]
    if js_url.startswith("/"):
        js_url = "https://nhplayer.com" + js_url
    elif not js_url.startswith("http"):
        js_url = "https://nhplayer.com/" + js_url

    js_content = getHtml(js_url, player_url)
    if not js_content:
        kodilog("resolve_nhplayer: failed to fetch player core JS")
        return None

    ids = re.findall(r"getElementById\(['\"]([^'\"]+)['\"]\)", js_content)
    if len(ids) < 5:
        kodilog("resolve_nhplayer: failed to find challenge IDs in JS")
        return None

    try:
        p1_attr = re.search(r'p1\s*=\s*\w+.*?getAttribute\([\'"]([^\'"]+)[\'"]\)', js_content).group(1)
        p3_attr = re.search(r'p3\s*=\s*\w+.*?getAttribute\([\'"]([^\'"]+)[\'"]\)', js_content).group(1)
        ts_attr = re.search(r'ts\s*=\s*\w+.*?getAttribute\([\'"]([^\'"]+)[\'"]\)', js_content).group(1)
    except Exception as e:
        kodilog("resolve_nhplayer: failed to parse challenge attributes in JS: {}".format(e))
        return None

    e1 = soup_player.find(id=ids[0])
    e2 = soup_player.find(id=ids[1])
    e3 = soup_player.find(id=ids[2])
    e4 = soup_player.find(id=ids[3])
    e5 = soup_player.find(id=ids[4])

    if not (e1 and e2 and e3 and e4 and e5):
        kodilog("resolve_nhplayer: failed to find challenge elements in DOM")
        return None

    p1 = e1.get(p1_attr, "")
    p2 = e2.get("value", "")
    p3 = e3.get(p3_attr, "")
    p4 = e4.string or e4.get_text(strip=True)
    ts = e5.get(ts_attr, "")

    challenge = p1 + p2 + p3 + p4 + ts
    pow_solution = None
    for n in range(10000000):
        h = hashlib.sha256((challenge + hex(n)[2:]).encode('utf-8')).digest()
        if h[0] == 0 and h[1] == 0:
            pow_solution = hex(n)[2:]
            break

    if not pow_solution:
        kodilog("resolve_nhplayer: failed to solve Proof of Work")
        return None

    tokens = re.findall(r"var\s+_[a-zA-Z0-9]+\s*=\s*['\"]([^'\"]+)['\"]", js_content)
    if len(tokens) < 2:
        kodilog("resolve_nhplayer: failed to find challenge tokens in JS")
        return None
    sc = tokens[0]
    rid = tokens[1]

    fp_data = {
        "t": 2050,
        "mm": [],
        "tm": [],
        "cl": [],
        "kp": [],
        "sc": [],
        "i": 0,
        "mc": 0,
        "tc": 0,
        "cc": 0,
        "kc": 0,
        "b": {
            "w": "ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)",
            "v": "Google Inc. (Google)",
            "sw": 1280,
            "sh": 720,
            "aw": 1280,
            "ah": 720,
            "cd": 24,
            "pd": 24,
            "tz": 480,
            "hc": 8,
            "dm": 8,
            "pl": "Win32",
            "lang": "en-US",
            "langs": "en-US",
            "dpr": 1,
            "ww": 1280,
            "wh": 720,
            "touch": False,
            "pdf": True,
            "fonts": 0
        }
    }
    fp = base64.b64encode(json.dumps(fp_data).encode('utf-8')).decode('utf-8')

    params = {
        "vid": vid,
        "c": ct,
        "p1": p1,
        "p2": p2,
        "p3": p3,
        "p4": p4,
        "t": ts,
        "sc": sc,
        "rid": rid,
        "fp": fp,
        "df": "",
        "pow": pow_solution,
        "pid": pid,
        "st": st
    }

    api_url = "https://nhplayer.com/get-video-url-v2.php?" + urllib_parse.urlencode(params)
    headers = {
        "X-Requested-With": "XMLHttpRequest",
        "Referer": player_url,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    res = getHtml(api_url, player_url, headers=headers)
    if not res:
        kodilog("resolve_nhplayer: empty response from get-video-url API")
        return None
    try:
        res_json = json.loads(res)
        return res_json.get("url")
    except Exception as e:
        kodilog("resolve_nhplayer: failed to parse API response JSON: {}".format(e))
        return None
