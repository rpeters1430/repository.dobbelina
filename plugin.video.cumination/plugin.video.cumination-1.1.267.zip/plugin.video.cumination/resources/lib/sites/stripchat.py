"""
Cumination
Copyright (C) 2017 Whitecream, hdgdl, Team Cumination
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import sqlite3
import json
import re

from resources.lib import utils
from six.moves import urllib_parse
from resources.lib.adultsite import AdultSite

site = AdultSite(
    "stripchat",
    "[COLOR hotpink]stripchat.com[/COLOR]",
    "https://stripchat.com/",
    "stripchat.png",
    "stripchat",
    True,
)


def _normalize_model_image_url(url):
    if not isinstance(url, str) or not url:
        return ""
    normalized = url.strip()
    if normalized.startswith("//"):
        return "https:" + normalized
    if normalized.startswith("/"):
        return "https://stripchat.com" + normalized
    if normalized.startswith("http"):
        return normalized
    return ""


def _live_preview_url(url, snapshot_ts=None):
    normalized = _normalize_model_image_url(url)
    if not normalized:
        return ""
    # Stripchat preview endpoints support a higher-quality variant by removing
    # the "-thumb-small" suffix; also add snapshot timestamp to avoid stale cache.
    if normalized.endswith("-thumb-small"):
        normalized = normalized.replace("-thumb-small", "")
    if snapshot_ts and "strpst.com/previews/" in normalized:
        sep = "&" if "?" in normalized else "?"
        normalized = "{}{}t={}".format(normalized, sep, snapshot_ts)
    return normalized


def _model_screenshot(model):
    if not isinstance(model, dict):
        return ""
    snapshot_ts = model.get("snapshotTimestamp") or model.get("popularSnapshotTimestamp")
    image_fields = (
        "previewUrlThumbBig",
        "previewUrlThumbLarge",
        "previewUrlThumbSmall",
        "preview",
        "previewUrl",
        "snapshotUrl",
    )
    for field in image_fields:
        img = _live_preview_url(model.get(field), snapshot_ts)
        if img:
            return img

    model_id = model.get("id")
    if snapshot_ts and model_id:
        return "https://img.strpst.com/thumbs/{0}/{1}_webp".format(
            snapshot_ts, model_id
        )
    return ""


@site.register(default_mode=True)
def Main():
    female = utils.addon.getSetting("chatfemale") == "true"
    male = utils.addon.getSetting("chatmale") == "true"
    couple = utils.addon.getSetting("chatcouple") == "true"
    trans = utils.addon.getSetting("chattrans") == "true"
    site.add_dir(
        "[COLOR red]Refresh Stripchat images[/COLOR]",
        "",
        "clean_database",
        "",
        Folder=False,
    )

    bu = "https://stripchat.com/api/front/models?limit=80&parentTag=autoTagNew&sortBy=trending&offset=0&primaryTag="
    if female:
        site.add_dir(
            "[COLOR hotpink]Female HD[/COLOR]",
            "{0}girls&broadcastHD=true".format(bu),
            "List",
            "",
            "",
        )
        site.add_dir(
            "[COLOR hotpink]Female[/COLOR]", "{0}girls".format(bu), "List", "", ""
        )
    if couple:
        site.add_dir(
            "[COLOR hotpink]Couples HD[/COLOR]",
            "{0}couples&broadcastHD=true".format(bu),
            "List",
            "",
            "",
        )
        site.add_dir(
            "[COLOR hotpink]Couples[/COLOR]", "{0}couples".format(bu), "List", "", ""
        )
        site.add_dir(
            "[COLOR hotpink]Couples (Site)[/COLOR]",
            "https://stripchat.com/couples",
            "List2",
            "",
            "",
        )
    if male:
        site.add_dir(
            "[COLOR hotpink]Male HD[/COLOR]",
            "{0}men&broadcastHD=true".format(bu),
            "List",
            "",
            "",
        )
        site.add_dir("[COLOR hotpink]Male[/COLOR]", "{0}men".format(bu), "List", "", "")
    if trans:
        site.add_dir(
            "[COLOR hotpink]Transsexual HD[/COLOR]",
            "{0}trans&broadcastHD=true".format(bu),
            "List",
            "",
            "",
        )
        site.add_dir(
            "[COLOR hotpink]Transsexual[/COLOR]", "{0}trans".format(bu), "List", "", ""
        )
    utils.eod()


@site.register()
def List(url, page=1):
    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)

    # utils._getHtml will automatically use FlareSolverr if Cloudflare is detected
    try:
        utils.kodilog("Stripchat: Fetching model list from API")
        response, _ = utils.get_html_with_cloudflare_retry(
            url,
            referer=site.url,
            retry_on_empty=True,
        )
        if not response:
            utils.kodilog("Stripchat: Empty response from API")
            utils.notify("Error", "Could not load Stripchat models")
            return None
        data = json.loads(response)
        model_list = data["models"]
        utils.kodilog(
            "Stripchat: Successfully loaded {} models".format(len(model_list))
        )
    except Exception as e:
        utils.kodilog("Stripchat: Error loading model list: {}".format(str(e)))
        utils.notify("Error", "Could not load Stripchat models")
        return None

    for model in model_list:
        name = utils.cleanhtml(model["username"])
        videourl = model["hlsPlaylist"]
        img = _model_screenshot(model)
        fanart = img
        subject = model.get("groupShowTopic")
        if subject:
            subject += "[CR]"
        if model.get("country"):
            subject += "[COLOR deeppink]Location: [/COLOR]{0}[CR]".format(
                utils.get_country(model.get("country"))
            )
        if model.get("languages"):
            langs = [utils.get_language(x) for x in model.get("languages")]
            subject += "[COLOR deeppink]Languages: [/COLOR]{0}[CR]".format(
                ", ".join(langs)
            )
        if model.get("broadcastGender"):
            subject += "[COLOR deeppink]Gender: [/COLOR]{0}[CR]".format(
                model.get("broadcastGender")
            )
        if model.get("viewersCount"):
            subject += "[COLOR deeppink]Watching: [/COLOR]{0}[CR][CR]".format(
                model.get("viewersCount")
            )
        if model.get("tags"):
            subject += "[COLOR deeppink]#[/COLOR]"
            tags = [t for t in model.get("tags") if "tag" not in t.lower()]
            subject += "[COLOR deeppink] #[/COLOR]".join(tags)
        site.add_download_link(
            name, videourl, "Playvid", img, subject, noDownload=True, fanart=fanart
        )

    total_items = data.get("filteredCount", 0)
    nextp = (page * 80) < total_items
    if nextp:
        next = (page * 80) + 1
        lastpg = -1 * (-total_items // 80)
        page += 1
        nurl = re.sub(r"offset=\d+", "offset={0}".format(next), url)
        site.add_dir(
            "Next Page.. (Currently in Page {0} of {1})".format(page - 1, lastpg),
            nurl,
            "List",
            site.img_next,
            page,
        )

    utils.eod()


@site.register(clean_mode=True)
def clean_database(showdialog=True):
    conn = sqlite3.connect(utils.TRANSLATEPATH("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute(
                "SELECT id, cachedurl FROM texture WHERE url LIKE ?;",
                ("%" + ".strpst.com" + "%",),
            )
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture = ?;", (row[0],))
                try:
                    os.remove(utils.TRANSLATEPATH("special://thumbnails/" + row[1]))
                except Exception as e:
                    utils.kodilog(
                        "@@@@Cumination: Silent failure in stripchat: " + str(e)
                    )
            conn.execute(
                "DELETE FROM texture WHERE url LIKE ?;", ("%" + ".strpst.com" + "%",)
            )
            if showdialog:
                utils.notify("Finished", "Stripchat images cleared")
    except Exception as e:
        utils.kodilog("@@@@Cumination: Silent failure in stripchat: " + str(e))


@site.register()
def Playvid(url, name):
    vp = utils.VideoPlayer(name, IA_check="IA")
    vp.progress.update(25, "[CR]Loading video page[CR]")

    def _load_model_details(model_name):
        headers = {
            "User-Agent": utils.USER_AGENT,
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://stripchat.com",
            "Referer": "https://stripchat.com/{0}".format(model_name),
        }
        endpoints = [
            "https://stripchat.com/api/external/v4/widget/?limit=1&modelsList={0}",
            "https://stripchat.com/api/front/models?limit=1&modelsList={0}&offset=0",
        ]
        for endpoint in endpoints:
            try:
                utils.kodilog(
                    "Stripchat: Trying endpoint: {}".format(endpoint.format(model_name))
                )
                response, _ = utils.get_html_with_cloudflare_retry(
                    endpoint.format(model_name),
                    site.url,
                    headers=headers,
                    retry_on_empty=True,
                )
                if not response:
                    utils.kodilog("Stripchat: Empty response from endpoint")
                    continue
                payload = json.loads(response)
                models = payload.get("models") if isinstance(payload, dict) else None
                if models and len(models) > 0:
                    # Validate that the returned model matches the requested one
                    for model in models:
                        if model.get("username", "").lower() == model_name.lower():
                            utils.kodilog(
                                "Stripchat: Successfully loaded model details for {}".format(
                                    model_name
                                )
                            )
                            return model

                    utils.kodilog(
                        "Stripchat: API returned models but none matched {}".format(
                            model_name
                        )
                    )
                    if models:
                        utils.kodilog(
                            "Stripchat: First returned model was: {}".format(
                                models[0].get("username")
                            )
                        )
                else:
                    utils.kodilog("Stripchat: No models in response")
            except json.JSONDecodeError as e:
                utils.kodilog("Stripchat: JSON decode error: {}".format(str(e)))
                continue
            except Exception as e:
                utils.kodilog(
                    "Stripchat: Error loading model details: {}".format(str(e))
                )
                continue
        return None

    def _pick_stream(model_data, fallback_url):
        candidates = []
        stream_info = model_data.get("stream") if model_data else None
        is_online_flag = None
        manifest_probe_cache = {}

        # Treat online flags as advisory only; keep stream candidates if present.
        if model_data:
            is_online_values = [
                model_data.get("isOnline"),
                model_data.get("isBroadcasting"),
            ]
            explicit_values = [v for v in is_online_values if isinstance(v, bool)]
            if explicit_values:
                is_online_flag = any(explicit_values)
                if not is_online_flag:
                    utils.kodilog(
                        "Stripchat: Model {} reported offline by API".format(name)
                    )

        if isinstance(stream_info, dict):
            # Explicit urls map (new API structure)
            urls_map = stream_info.get("urls") or stream_info.get("files") or {}
            hls_map = urls_map.get("hls") if isinstance(urls_map, dict) else {}
            if isinstance(hls_map, dict):
                for quality, data in hls_map.items():
                    quality_label = str(quality).lower()
                    if isinstance(data, dict):
                        for key in ("absolute", "https", "url", "src"):
                            stream_url = data.get(key)
                            if isinstance(stream_url, str) and stream_url.startswith(
                                "http"
                            ):
                                utils.kodilog(
                                    "Stripchat: Found stream candidate: {} - {}".format(
                                        quality_label, stream_url[:80]
                                    )
                                )
                                candidates.append((quality_label, stream_url))
                                break
                    elif isinstance(data, str) and data.startswith("http"):
                        utils.kodilog(
                            "Stripchat: Found stream candidate: {} - {}".format(
                                quality_label, data[:80]
                            )
                        )
                        candidates.append((quality_label, data))
            # Some responses keep direct URL on stream['url']
            stream_url = stream_info.get("url")
            if isinstance(stream_url, str) and stream_url.startswith("http"):
                utils.kodilog(
                    "Stripchat: Found direct stream URL: {}".format(stream_url[:80])
                )
                candidates.append(("direct", stream_url))
        # Legacy field on model root
        if model_data and isinstance(model_data.get("hlsPlaylist"), str):
            hls_url = model_data["hlsPlaylist"]
            utils.kodilog("Stripchat: Found hlsPlaylist: {}".format(hls_url[:80]))
            candidates.append(("playlist", hls_url))
        if isinstance(fallback_url, str) and fallback_url.startswith("http"):
            utils.kodilog("Stripchat: Using fallback URL: {}".format(fallback_url[:80]))
            candidates.append(("fallback", fallback_url))

        # Some list URLs are pinned to low variants like "<id>_240p.m3u8".
        # Try to promote those to "<id>.m3u8" (often "source"/best stream) when valid.
        def _promote_variant_to_source_url(stream_url):
            if not isinstance(stream_url, str) or ".m3u8" not in stream_url:
                return None
            match = re.search(r"/master/(\d+)_\d{3,4}p\.m3u8($|\?)", stream_url)
            if not match:
                return None

            source_url = stream_url.replace(
                "/master/{}_".format(match.group(1)),
                "/master/{}.".format(match.group(1)),
            )
            source_url = re.sub(
                r"/master/(\d+)\.\d{3,4}p\.m3u8",
                r"/master/\1.m3u8",
                source_url,
            )
            if source_url == stream_url:
                return None

            try:
                probe_headers = {
                    "User-Agent": utils.USER_AGENT,
                    "Origin": "https://stripchat.com",
                    "Referer": "https://stripchat.com/{0}".format(name),
                    "Accept": "application/x-mpegURL,application/vnd.apple.mpegurl,*/*",
                }
                probe_data = utils._getHtml(
                    source_url,
                    "https://stripchat.com/{0}".format(name),
                    headers=probe_headers,
                )
                if isinstance(probe_data, str) and "#EXTM3U" in probe_data:
                    utils.kodilog(
                        "Stripchat: Promoted variant stream to source playlist: {}".format(
                            source_url[:80]
                        )
                    )
                    return source_url
            except Exception as e:
                utils.kodilog(
                    "Stripchat: Source playlist probe failed for {}: {}".format(
                        source_url[:80], str(e)
                    )
                )
            return None

        def _fetch_manifest_text(manifest_url):
            if not isinstance(manifest_url, str) or ".m3u8" not in manifest_url:
                return ""
            if manifest_url in manifest_probe_cache:
                return manifest_probe_cache[manifest_url]
            try:
                headers = {
                    "User-Agent": utils.USER_AGENT,
                    "Origin": "https://stripchat.com",
                    "Referer": "https://stripchat.com/{0}".format(name),
                    "Accept": "application/x-mpegURL,application/vnd.apple.mpegurl,*/*",
                }
                text = utils._getHtml(
                    manifest_url,
                    "https://stripchat.com/{0}".format(name),
                    headers=headers,
                )
            except Exception as e:
                utils.kodilog(
                    "Stripchat: Manifest probe failed for {}: {}".format(
                        manifest_url[:80], str(e)
                    )
                )
                text = ""
            manifest_probe_cache[manifest_url] = text if isinstance(text, str) else ""
            return manifest_probe_cache[manifest_url]

        def _is_ad_or_stub_manifest(manifest_text):
            if not isinstance(manifest_text, str) or "#EXTM3U" not in manifest_text:
                return False
            lower = manifest_text.lower()
            if "#ext-x-mouflon-advert" in lower:
                return True
            if "/cpa/v2/" in lower:
                return True
            # Treat short VOD endlists as non-live/ad stubs for cam playback.
            if "#ext-x-playlist-type:vod" in lower and "#ext-x-endlist" in lower:
                return True
            return False

        def _candidate_is_ad_path(candidate_url):
            master_text = _fetch_manifest_text(candidate_url)
            if not master_text or "#EXTM3U" not in master_text:
                return False

            # If this manifest itself is an ad/stub, reject immediately.
            if _is_ad_or_stub_manifest(master_text):
                return True

            # If this is a master playlist, inspect child playlists as well.
            child_urls = [
                line.strip()
                for line in master_text.splitlines()
                if line.strip() and not line.startswith("#")
            ]
            for child_url in child_urls[:2]:
                child_text = _fetch_manifest_text(child_url)
                if _is_ad_or_stub_manifest(child_text):
                    return True
            return False

        promoted = []
        for _, candidate_url in list(candidates):
            source_url = _promote_variant_to_source_url(candidate_url)
            if source_url:
                promoted.append(("source-derived", source_url))
        candidates.extend(promoted)

        if not candidates:
            utils.kodilog("Stripchat: No stream candidates found")
            return None, is_online_flag

        def quality_score(label, stream_url):
            if not label:
                label = ""
            score = -1
            label = label.lower()
            if "source" in label:
                score = max(score, 10000)
            match = re.search(r"(\d{3,4})p", label)
            if match:
                try:
                    score = max(score, int(match.group(1)))
                except ValueError:
                    pass

            # Fallback: infer quality from URL pattern when labels are generic.
            if isinstance(stream_url, str):
                if re.search(r"/master/\d+\.m3u8($|\?)", stream_url):
                    score = max(score, 9000)
                url_quality = re.search(r"_(\d{3,4})p\.m3u8($|\?)", stream_url)
                if url_quality:
                    try:
                        score = max(score, int(url_quality.group(1)))
                    except ValueError:
                        pass
            return score

        # sort candidates: highest score first, keep stable order otherwise
        candidates_sorted = sorted(
            candidates,
            key=lambda item: (
                -1 if _candidate_is_ad_path(item[1]) else 0,
                quality_score(item[0], item[1]),
                1 if "doppiocdn.com" in item[1] else 0,
            ),
            reverse=True,
        )
        selected_url = candidates_sorted[0][1]
        selected_label = candidates_sorted[0][0]
        utils.kodilog(
            "Stripchat: Selected stream: {} - {}".format(
                selected_label, selected_url[:80]
            )
        )

        # Don't try to parse master playlists - just use the selected URL directly
        # The master playlist URL is already the correct stream to use
        # Parsing it and selecting variants often picks the wrong quality or causes auth failures
        utils.kodilog(
            "Stripchat: Using selected stream URL directly without master playlist parsing"
        )

        return selected_url, is_online_flag

    # Load current model details
    utils.kodilog("Stripchat: Loading details for model: {}".format(name))
    model_data = _load_model_details(name)

    if not model_data:
        vp.progress.close()
        utils.kodilog("Stripchat: Failed to load model details")
        utils.notify("Stripchat", "Model not found or offline")
        return

    # Pick best stream URL
    stream_url, is_online_flag = _pick_stream(model_data, url)
    if not stream_url:
        vp.progress.close()
        utils.kodilog("Stripchat: No stream URL available")
        if is_online_flag is False:
            utils.notify("Stripchat", "Model is offline")
        else:
            utils.notify("Stripchat", "Unable to locate stream URL")
        return

    # Validate stream URL
    if not stream_url.startswith("http"):
        vp.progress.close()
        utils.kodilog("Stripchat: Invalid stream URL: {}".format(stream_url))
        utils.notify("Stripchat", "Invalid stream URL")
        return

    utils.kodilog("Stripchat: Final stream URL: {}".format(stream_url[:100]))
    vp.progress.update(85, "[CR]Found Stream[CR]")

    # Verify inputstream.adaptive is available for HLS streams
    # The check_inputstream() call will offer to install if missing
    try:
        from inputstreamhelper import Helper

        is_helper = Helper("hls")
        vp.progress.update(90, "[CR]Checking inputstream.adaptive[CR]")
        if not is_helper.check_inputstream():
            vp.progress.close()
            utils.kodilog(
                "Stripchat: inputstream.adaptive check failed - HLS streams require it"
            )
            utils.notify(
                "Stripchat",
                "inputstream.adaptive is required. Please install it from Kodi settings.",
                duration=8000,
            )
            return
    except Exception as e:
        utils.kodilog("Stripchat: Error checking inputstream: {}".format(str(e)))
        # Continue anyway - let utils.playvid handle it

    # Build headers for HLS stream
    ua = urllib_parse.quote(utils.USER_AGENT, safe="")
    origin_enc = urllib_parse.quote("https://stripchat.com", safe="")
    referer_enc = urllib_parse.quote("https://stripchat.com/{0}".format(name), safe="")
    accept_enc = urllib_parse.quote("application/x-mpegURL", safe="")
    accept_lang = urllib_parse.quote("en-US,en;q=0.9", safe="")
    ia_headers = (
        "User-Agent={0}&Origin={1}&Referer={2}&Accept={3}&Accept-Language={4}".format(
            ua, origin_enc, referer_enc, accept_enc, accept_lang
        )
    )

    utils.kodilog("Stripchat: Starting playback")
    vp.play_from_direct_link(stream_url + "|" + ia_headers)


@site.register()
def List2(url):
    site.add_download_link(
        "[COLOR red][B]Refresh[/B][/COLOR]",
        url,
        "utils.refresh",
        "",
        "",
        noDownload=True,
    )
    if utils.addon.getSetting("online_only") == "true":
        url = url + "/?online_only=1"
        site.add_download_link(
            "[COLOR red][B]Show all models[/B][/COLOR]",
            url,
            "online",
            "",
            "",
            noDownload=True,
        )
    else:
        site.add_download_link(
            "[COLOR red][B]Show only models online[/B][/COLOR]",
            url,
            "online",
            "",
            "",
            noDownload=True,
        )

    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)

    headers = {"X-Requested-With": "XMLHttpRequest"}
    data = utils._getHtml(url, site.url, headers=headers)

    # BeautifulSoup migration
    soup = utils.parse_html(data)
    if not soup:
        utils.eod()
        return

    # Check for window.LOADABLE_DATA first (modern client-side rendering)
    scripts = soup.find_all("script")
    found_models = False
    for script in scripts:
        script_text = script.string or ""
        if "window.LOADABLE_DATA" in script_text:
            try:
                # Extract JSON from window.LOADABLE_DATA = {...};
                json_match = re.search(
                    r"window\.LOADABLE_DATA\s*=\s*({.*?});", script_text
                )
                if json_match:
                    payload = json.loads(json_match.group(1))
                    model_list = []

                    # Dig through the nested structure
                    # It's usually in payload['categoryTagPage']['models'] or payload['models']
                    if "models" in payload:
                        model_list = payload["models"]
                    elif (
                        "categoryTagPage" in payload
                        and "models" in payload["categoryTagPage"]
                    ):
                        model_list = payload["categoryTagPage"]["models"]

                    if model_list:
                        found_models = True
                        for model in model_list:
                            name = utils.cleanhtml(model["username"])
                            videourl = model.get("hlsPlaylist")
                            img = _model_screenshot(model)
                            # Handle offline/profile links
                            if model.get("status") == "off":
                                name = "[COLOR hotpink][Offline][/COLOR] " + name
                                videourl = "  "

                            site.add_download_link(
                                name,
                                videourl,
                                "Playvid",
                                img,
                                "",
                                fanart=img,
                            )
                        break
            except Exception as e:
                utils.kodilog(
                    "Stripchat List2: Error parsing LOADABLE_DATA: {}".format(str(e))
                )

    if not found_models:
        # Fallback to traditional HTML parsing
        # Find the top_ranks or top_others section
        section = soup.find(class_="top_ranks") or soup.find(class_="top_others")
        if section:
            # Find all model entries with top_thumb class
            models = section.find_all(class_="top_thumb")
            for model in models:
                try:
                    link = model.find("a", href=True)
                    if not link:
                        continue
                    model_url = utils.safe_get_attr(link, "href", default="")

                    img_tag = model.find("img")
                    img = utils.safe_get_attr(img_tag, "src", ["data-src"], "")
                    if img and not img.startswith("http"):
                        img = "https:" + img

                    name_tag = model.find(class_="mn_lc")
                    name = utils.safe_get_text(name_tag, default="Unknown")

                    if "profile" in model_url:
                        name = "[COLOR hotpink][Offline][/COLOR] " + name
                        model_url = "  "
                    elif model_url.startswith("/"):
                        model_url = model_url[1:]

                    site.add_download_link(
                        name,
                        model_url,
                        "Playvid",
                        img,
                        "",
                        fanart=img,
                    )
                except Exception as e:
                    utils.kodilog(
                        "Stripchat List2: Error parsing model entry: {}".format(str(e))
                    )
                    continue

    utils.eod()


@site.register()
def List3(url):
    site.add_download_link(
        "[COLOR red][B]Refresh[/B][/COLOR]",
        url,
        "utils.refresh",
        "",
        "",
        noDownload=True,
    )
    if utils.addon.getSetting("online_only") == "true":
        url = url + "/?online_only=1"
        site.add_download_link(
            "[COLOR red][B]Show all models[/B][/COLOR]",
            url,
            "online",
            "",
            "",
            noDownload=True,
        )
    else:
        site.add_download_link(
            "[COLOR red][B]Show only models online[/B][/COLOR]",
            url,
            "online",
            "",
            "",
            noDownload=True,
        )

    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)

    headers = {"X-Requested-With": "XMLHttpRequest"}
    data = utils._getHtml(url, site.url, headers=headers)

    # BeautifulSoup migration
    soup = utils.parse_html(data)
    if not soup:
        utils.eod()
        return

    # Check for window.LOADABLE_DATA first (modern client-side rendering)
    scripts = soup.find_all("script")
    found_models = False
    for script in scripts:
        script_text = script.string or ""
        if "window.LOADABLE_DATA" in script_text:
            try:
                # Extract JSON from window.LOADABLE_DATA = {...};
                json_match = re.search(
                    r"window\.LOADABLE_DATA\s*=\s*({.*?});", script_text
                )
                if json_match:
                    payload = json.loads(json_match.group(1))
                    model_list = []

                    if "models" in payload:
                        model_list = payload["models"]
                    elif (
                        "categoryTagPage" in payload
                        and "models" in payload["categoryTagPage"]
                    ):
                        model_list = payload["categoryTagPage"]["models"]

                    if model_list:
                        found_models = True
                        for model in model_list:
                            name = utils.cleanhtml(model["username"])
                            videourl = model.get("hlsPlaylist")
                            img = _model_screenshot(model)
                            # Handle offline/profile links
                            if model.get("status") == "off":
                                name = "[COLOR hotpink][Offline][/COLOR] " + name
                                videourl = "  "

                            site.add_download_link(
                                name,
                                videourl,
                                "Playvid",
                                img,
                                "",
                                fanart=img,
                            )
                        break
            except Exception as e:
                utils.kodilog(
                    "Stripchat List3: Error parsing LOADABLE_DATA: {}".format(str(e))
                )

    if not found_models:
        # Fallback to traditional HTML parsing
        # Find the top_ranks section
        section = soup.find(class_="top_ranks")
        if section:
            # Find all model entries with top_thumb class
            models = section.find_all(class_="top_thumb")
            for model in models:
                try:
                    link = model.find("a", href=True)
                    if not link:
                        continue
                    model_url = utils.safe_get_attr(link, "href", default="")

                    img_tag = model.find("img")
                    img = utils.safe_get_attr(img_tag, "src", ["data-src"], "")
                    if img and not img.startswith("http"):
                        img = "https:" + img

                    name_tag = model.find(class_="mn_lc")
                    name = utils.safe_get_text(name_tag, default="Unknown")

                    if "profile" in model_url:
                        name = "[COLOR hotpink][Offline][/COLOR] " + name
                        model_url = "  "
                    elif model_url.startswith("/"):
                        model_url = model_url[1:]

                    site.add_download_link(
                        name,
                        model_url,
                        "Playvid",
                        img,
                        "",
                        fanart=img,
                    )
                except Exception as e:
                    utils.kodilog(
                        "Stripchat List3: Error parsing model entry: {}".format(str(e))
                    )
                    continue

    utils.eod()


@site.register()
def online(url):
    if utils.addon.getSetting("online_only") == "true":
        utils.addon.setSetting("online_only", "false")
    else:
        utils.addon.setSetting("online_only", "true")
    utils.refresh()
