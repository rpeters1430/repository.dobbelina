'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from resources.lib import utils
from resources.lib.decrypters.kvsplayer import kvs_decode
from resources.lib.adultsite import AdultSite
from urllib.parse import quote

site = AdultSite('ikisoda', '[COLOR hotpink]Ikisoda[/COLOR]', 'https://ikisoda.com/', 'ikisoda.png', 'ikisoda', category="JAV & Asian")

addon = utils.addon
perPage = 30

@site.register(default_mode=True)
def Main():
    global perPage
    perPage_setting = utils.addon.getSetting('ikisodaper_page')
    if perPage_setting and perPage_setting.strip() != "":
        perPage = int(perPage_setting)
    else:
        perPage = 30
        utils.addon.setSetting("ikisodaper_page", str(perPage))
    perPage = getPerPage()
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'categories/?items_per_page=120', 'List1', site.img_cat)
    site.add_dir('[COLOR hotpink]Models[/COLOR]', site.url + 'jav-models/?&models_per_page={}&sort_by=video_viewed_count&type=actress'.format(perPage), 'List2', site.img_cat)
  
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + 'search/', 'Search', site.img_search)
    List(site.url)


@site.register()
def List(url):
    perPage = getPerPage()

    if '?' in url:
        url += '&videos_per_page={}&sort_by=post_date'.format(perPage)
    else:
        url += '?videos_per_page={}&sort_by=post_date'.format(perPage)    # sort_by=post_date for newers, sort_by=custom1 for popular

    listhtml = utils.getHtml(url)
    pattern = re.compile(
        r'<a class="is-item-link is-item-link-video" href="([^"]+)".*?'          # href
        r'data-original="([^"]+)".*?'                                            # image
        r'<div class="is-item-duration[^"]*">([^<]+)</div>.*?'                   # duration
        r'<div class="is-item-title[^"]*">\s*(.*?)\s*</div>.*?'                  # title
        r'<div class="is-info-views">.*?<span>([^<]+)</span>.*?'                 # views
        r'<div class="is-info-rating[^"]*">.*?<span>([^<]+)</span>',             # rating
        re.DOTALL
    )
    matches = pattern.findall(listhtml)
    for videopage, img, duration, name, views, rating in matches:
        name = utils.cleantext(name)
        videopage = site.url[:-1] + videopage if videopage.startswith('/') else videopage
        site.add_download_link("{name} [COLOR yellow]({duration})[/COLOR][COLOR hotpink] [{views} views, {rating} rating][/COLOR]".format(name=name, duration=duration, views=views, rating=rating), videopage, 'Playvid', img, name)

    site.add_download_link(
        'Current models per page: [COLOR fuchsia][B]{}[/B][/COLOR] - [COLOR red][B]Change[/B][/COLOR]'.format(perPage),
        url,
        'ChangePerPage',
        '',
        '',
        noDownload=True
    )

    np = re.search(
        r'<li\s+class="next".*?<a\s+href="([^"]+)"',
        listhtml,
        re.DOTALL | re.IGNORECASE
    )

    if np:
        np = np.group(1)
        np = np.replace('\t', '').replace('\n', '').replace(' ', '')

        if np.startswith("/"):
            np = site.url[:-1] + np

        nextpage = re.search(r'/(\d+)/', np)
        if nextpage:
            nextpage = nextpage.group(1)
        else:
            nextpage = "?"

        site.add_dir(
            "Next Page... ({nextpage})".format(nextpage=nextpage),
            np,
            "List",
            site.img_next
        )

    utils.eod()


@site.register()
def List1(url):
    perPage = getPerPage()
    html = utils.getHtml(url)

    pattern = re.compile(
        r'is-item item" href="([^"]+)".*?'                            # href
        r'<img[^>]+src="([^"]+)".*?'                                  # image
        r'<div class="is-item-title[^"]*">\s*(.*?)\s*</div>.*?'       # title
        r'<div class="is-count-videos[^"]*">\s*([^<]+)\s*</div>',     # count videos
        re.DOTALL
    )

    matches = pattern.findall(html)
    for href, img, title, count in matches:
        label = (
            "[COLOR gold]{title}[/COLOR]  "
            "[COLOR cyan]{count}[/COLOR]"
        ).format(title=title, count=count)
        site.add_dir("{label}".format(label=label), href + '?items_per_page={perPage}'.format(perPage=perPage), 'List', site.img_cat)
    np = re.compile(r'href="([^"]+)">Next<', re.DOTALL | re.IGNORECASE).search(html)
    if np:
        np = np.group(1)
        nextpage = re.search(r'page/(\d+)', np).group(1)
        site.add_dir('Next Page... ({0})'.format(nextpage), np, 'List', site.img_next)
    utils.eod()


@site.register()
def List2(url):
    perPage = getPerPage()
    html = utils.getHtml(url)
    pattern = re.compile(
        r'<div class="is-item b6m-model">.*?'                             # container model
        r'<a[^>]+href="([^"]+)"[^>]*>.*?'                                 # href
        r'data-original="([^"]+)".*?'                                     # image
        r'<div class="is-item-title[^"]*">.*?(?:<span>#\d+</span>\s*)?([^<]+?)\s*</div>.*?'  # name
        r'is-info-count-videos">\s*([^<]+)\s*</div>.*?'                   # count videos
        r'is-info-views">.*?<span>([^<]+)</span>.*?'                      # views
        r'is-info-rating[^"]*">.*?<span>([^<]+)</span>'                   # rating
        , re.DOTALL
    )

    matches = pattern.findall(html)
    for href, img, title, count, views, rating in matches:
        label = (
            "[COLOR gold]{title}[/COLOR]  "
            "[COLOR cyan]{count}[/COLOR]"
            "[COLOR yellow] ({views} views)[/COLOR]"
            "[COLOR hotpink] [{rating} rating][/COLOR]"
        ).format(title=title, count=count, views=views, rating=rating)

        site.add_dir("{label}".format(label=label), href + '?items_per_page={perPage}'.format(perPage=perPage), 'List', quote(img, safe=':/'))

    np = re.search(
        r'<li\s+class="next".*?<a\s+href="([^"]+)"',
        html,
        re.DOTALL | re.IGNORECASE
    )

    if np:
        np = np.group(1)
        np = np.replace('\t', '').replace('\n', '').replace(' ', '')

        if np.startswith("/"):
            np = site.url[:-1] + np

        nextpage = re.search(r'/(\d+)/', np)
        if nextpage:
            nextpage = nextpage.group(1)
        else:
            nextpage = "?"

        site.add_dir(
            "Next Page... ({nextpage})".format(nextpage=nextpage),
            np,
            "List2",
            site.img_next
        )
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        url += keyword.replace(' ', '+')
        List(url)


@site.register()
def Playvid(url, name, download=None):
    utils.kodilog('porntn Playvid: ' + url)
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    html = utils.getHtml(url, site.url)
    sources = {}
    license = re.compile(r"license_code:\s*'([^']+)", re.DOTALL | re.IGNORECASE).findall(html)[0]
    patterns = [r"video_url:\s*'([^']+)[^;]+?video_url_text:\s*'([^']+)",
                r"video_alt_url:\s*'([^']+)[^;]+?video_alt_url_text:\s*'([^']+)",
                r"video_alt_url2:\s*'([^']+)[^;]+?video_alt_url2_text:\s*'([^']+)",
                r"video_url:\s*'([^']+)',\s*postfix:\s*'\.mp4',\s*(preview)"]
    for pattern in patterns:
        items = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(html)
        for surl, qual in items:
            qual = '00' if qual == 'preview' else qual
            qual = qual.replace(' HD', '')
            surl = kvs_decode(surl, license)
            sources[qual] = surl
    videourl = utils.selector('Select quality', sources, setting_valid='qualityask', sort_by=lambda x: 1081 if x == '4k' else int(x[:-1]), reverse=True)

    if not videourl:
        vp.progress.close()
        return
    vp.play_from_direct_link(videourl + '|referer=' + url)


@site.register()
def ChangePerPage(url=None, name=None):
    vq = utils._get_keyboard(heading=utils.i18n('srch_for'))
    if not vq or not vq.isdigit():
        return False
        
    utils.addon.setSetting("ikisodaper_page", str(vq))
    utils.refresh()
    return True

def getPerPage():
    perPage_setting = utils.addon.getSetting('ikisodaper_page')
    if perPage_setting and perPage_setting.strip() != "":
        return int(perPage_setting)
    return 30
