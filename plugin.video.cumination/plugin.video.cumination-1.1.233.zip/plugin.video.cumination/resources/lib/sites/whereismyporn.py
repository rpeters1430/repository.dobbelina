"""
Cumination
Copyright (C) 2023 Team Cumination

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite(
    "wimp",
    "[COLOR hotpink]WhereIsMyPorn[/COLOR]",
    "https://whereismyporn.com/",
    "",
    "wimp",
)

addon = utils.addon


@site.register(default_mode=True)
def Main():
    site.add_dir(
        "[COLOR hotpink]Movies[/COLOR]",
        site.url + "archives/tag/movie",
        "List",
        site.img_cat,
    )
    site.add_dir(
        "[COLOR hotpink]Search[/COLOR]", site.url + "?s=", "Search", site.img_search
    )
    List(site.url + "page/1")


@site.register()
def List(url):
    listhtml = utils.getHtml(url)
    soup = utils.parse_html(listhtml)
    for post in soup.select(".post"):
        link = post.select_one(".entry-title a[href]") or post.select_one("a[href]")
        videopage = utils.safe_get_attr(link, "href", default="")
        if not videopage:
            continue
        name = utils.cleantext(utils.safe_get_text(link, default=""))
        img_tag = post.select_one("img")
        img = utils.safe_get_attr(img_tag, "src", ["data-src", "data-original"])
        site.add_download_link(name, videopage, "Playvid", img, name)

    next_link = soup.select_one("a.next.page-numbers[href], a.next[href]")
    if next_link:
        np = utils.safe_get_attr(next_link, "href", default="")
        nextpage = ""
        match = re.search(r"page/(\d+)", np)
        if match:
            nextpage = match.group(1)
        site.add_dir("Next Page... ({0})".format(nextpage), np, "List", site.img_next)
    utils.eod()


@site.register()
def Search(url, keyword=None):
    if not keyword:
        site.search_dir(url, "Search")
    else:
        url += keyword.replace(" ", "+")
        List(url)


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.play_from_site_link(url, url)
